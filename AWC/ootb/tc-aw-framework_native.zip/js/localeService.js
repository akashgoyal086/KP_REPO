// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * @module js/localeService
 */
define( [ 'app', 'js/logService' ], function( app, logSvc ) {
    'use strict';

    /**
     * @memberof module:js/localeService
     * @private
     */
    var _countryCode = null;

    /**
     * @memberof module:js/localeService
     * @private
     */
    var _languageCode = 'en';

    /**
     * Map used to associate a given resource to an AngularJS 'promise' used to manage asynchronous access to an
     * instance of the resource's object.
     *
     * @memberof module:js/localeService
     * @private
     */
    var _mapResource2Defer = {};

    /**
     * Map used to associate a given resource to an already loaded text bundle.
     *
     * @memberof module:js/localeService
     * @private
     */
    var _mapResource2TextBundle = {};

    /**
     * Cached reference to the current $q service.
     *
     * @memberof module:js/localeService
     * @private
     */
    var _$q = null;

    /**
     * Cached reference to the current $http service.
     *
     * @memberof module:js/localeService
     * @private
     */
    var _$http = null;

    /**
     * Initializes user language and country code variables for this service.
     * <P>
     * Note: We handle some special cases to where we want just the language code without the region code (a.k.a.
     * country code).
     *
     * @param {Object} localeInfo -
     *
     * <pre>
     * localeInfo = {
     *     locale: locale,
     *     is12HrFormat: is12HrFormat,
     *     sessionDateTimeFormat: sessionDateTimeFormat,
     *     sessionDateFormat: sessionDateFormat,
     *     sessionTimeFormat: sessionTimeFormat
     * };
     * </pre>
     */
    var _setLocaleInfo = function( localeInfo ) {
        var locale = localeInfo.locale;

        _languageCode = localeInfo.locale;

        if( locale.length > 2 ) {
            _languageCode = locale.substring( 0, 2 );

            if( _languageCode === 'de' || _languageCode === 'en' || _languageCode === 'es' || //
            _languageCode === 'fr' || _languageCode === 'it' ) {
                locale = _languageCode;
            }

            locale = locale.replace( "-", "_" );
            var regionNdx = locale.indexOf( '_' );
            if( regionNdx > 0 ) {
                _languageCode = _languageCode.substring( 0, regionNdx );
            }
        }

        _countryCode = "_" + locale;

        if( _countryCode.indexOf( "en" ) > -1 ) {
            _countryCode = "";
        }

        /**
         * Reset the map of text bundles since the new local will have it's own text bundles.
         */
        _mapResource2TextBundle = {};
        _mapResource2Defer = {};

        app.eventBus.publishSoa( 'locale.changed', localeInfo );
    };

    /**
     * Use default locale to start with.
     */
    _setLocaleInfo( app.localeInfo );

    /**
     * Setup to listen to changes in local
     *
     * @param localeInfo
     */
    app.eventBus.subscribeSoa( 'dateTime.sessionChanged', function( localeInfo ) {
        _setLocaleInfo( localeInfo );
    } );

    var exports = {};

    /**
     * @memberof module:js/localeService
     *
     * @param {String} resource - Name of the country-neutral (i.e. w/o country-code or extension) I18n resource to
     *            load.
     *
     * @return {@linkcode module:angular~Promise} the resolved localized string will be passed to.
     */
    exports.getTextPromise = function( resource ) {
        var resourceFinal = resource;

        if( !resourceFinal ) {
            resourceFinal = app.getBaseUrlPath() + '/i18n/BaseMessages';
        }

        if( _$http ) {
            var defer = _mapResource2Defer[resourceFinal];

            if( !defer ) {
                defer = _$q.defer();

                _mapResource2Defer[resourceFinal] = defer;

                _$http.get( resourceFinal + _countryCode + '.json' ).then(
                    function( res ) {
                        _mapResource2TextBundle[resourceFinal] = res.data;
                        defer.resolve( res.data );
                    },
                    function( reason ) {
                        logSvc.warn( 'localeService.getTextPromise: Failed to load text resource: ' + resourceFinal + //
                        '\n' + 'locale attempted: ' + _countryCode + '\n' + //
                        'Reason given: ' + reason.data );
                        _$http.get( resourceFinal + '.json' ).then(
                            function( res ) {
                                defer.resolve( res.data );
                            },
                            function( reason2 ) {
                                logSvc.error( 'localeService.getTextPromise: Failed to load text resource: ' +
                                    resourceFinal + '\n' + //
                                    'locale attempted: (default)' + '\n' + //
                                    'Reason given: ' + reason2.data );
                            } );
                    } );
            }

            return defer.promise;
        }

        logSvc.warn( 'localeService.getTextPromise: Failed to load text resource: ' + resourceFinal + '\n' + //
        'Reason given: ' + 'HTTP Service is not valid.' );

        return null;
    };

    /**
     * @memberof module:js/localeService
     *
     * @return {String} The i18n code for the current user language *without* any country or region code.
     */
    exports.getLanguageCode = function() {
        return _languageCode;
    };

    /**
     * @memberof module:js/localeService
     *
     * @return {String} Cached textBundle resource (or NULL if the bundle has not been cached yet).
     */
    exports.getLoadedText = function( resource ) {
        var resourceFinal = resource;

        if( !resourceFinal ) {
            resourceFinal = app.getBaseUrlPath() + '/i18n/BaseMessages';
        }

        return _mapResource2TextBundle[resourceFinal];
    };

    /**
     * Registeres an instance of 'localeService'with the application module's service factory.
     *
     * @member localeService
     * @memberof NgServices
     *
     * @param {$q} $q - AngularJS $q service.
     * @param {$http} $http - AngularJS $http service.
     *
     * @returns {Object} Reference to this module's API.
     */
    app.factory( 'localeService', [ '$q', '$http', function( $q, $http ) {
        _$q = $q;
        _$http = $http;
        return exports;
    } ] );

    return exports;
} );
