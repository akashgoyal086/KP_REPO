//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define
 */

/**
 * @module js/GatewayModule
 */
define([ 'jquerymobile', 'jquerymousewheel', 'js/tile-edit' ], function(jquerymobile, muiJqueryMousewheel,
        tileEditModule) {
    'use strict';

    var exports = {};

    /**
     * Reference to the loaded {@link module:js/title-edit} module's API.
     */
    exports.tileEditModule = tileEditModule;

    return exports;

    // End RequireJS Define
});