//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define
 */

/**
 * @module js/NgPropertyValidator
 */
define( [ 'app', 'angular', 'js/NgValidationService' ], function( app, ngModule ) {
    'use strict';

    /**
     * Define local variables for commonly used key-codes.
     */
    var _kcSpace = 32;

    /**
     * Definition for the (aw-validator) directive used to validate a UI property.
     *
     * @param ValidationService
     *
     * @member aw-validator
     * @memberof NgAttributeDirectives
     *
     * @returns {Void}
     */
    app.directive( 'awValidator', [
        'ValidationService',
        function( ValidationService ) {
            return {
                restrict: "A",
                require: '?ngModel',
                link: function( $scope, $element, attrs, ngModelCtrl ) {
                    if( !ngModelCtrl ) {
                        return;
                    }

                    if( attrs.awValidator === "INTEGER" || attrs.awValidator === "DOUBLE" ||
                        attrs.awValidator === "INTEGERARRAY" || attrs.awValidator === "DOUBLEARRAY" ||
                        attrs.awValidator === "DATE" || attrs.awValidator === "TIME" ) {

                        /**
                         * Add the validation 'machinery' to the set of 'parsers' on the ng-model controller.
                         *
                         * @param value
                         *
                         * @returns {Void}
                         */
                        ngModelCtrl.$parsers.push( function( value ) {
                            var valueFinal = value;

                            if( ngModule.isUndefined( valueFinal ) ) {
                                valueFinal = '';
                            }

                            var clean = valueFinal;

                            if( attrs.awValidator === "INTEGER" || attrs.awValidator === "INTEGERARRAY" ) {
                                clean = ValidationService.checkInteger( $scope, ngModelCtrl, valueFinal );
                            } else if( attrs.awValidator === "DOUBLE" || attrs.awValidator === "DOUBLEARRAY" ) {
                                clean = ValidationService.checkDouble( $scope, ngModelCtrl, valueFinal );
                            } else if( attrs.awValidator === "DATE" ) {
                                clean = ValidationService.checkDate( $scope, valueFinal, true );
                            } else if( attrs.awValidator === "TIME" ) {
                                clean = ValidationService.checkTime( $scope, valueFinal, true );
                            }

                            return clean;
                        } );

                        if( attrs.awValidator === "INTEGER" || attrs.awValidator === "DOUBLE" ||
                            attrs.awValidator === "INTEGERARRAY" || attrs.awValidator === "DOUBLEARRAY" ) {
                            /**
                             * Set up to ignore any 'space' key being pressed while in the field.
                             *
                             * @param event
                             *
                             * @returns {Void}
                             */
                            $element.bind( 'keypress', function( event ) {
                                if( event.keyCode === _kcSpace ) {
                                    // ignore space key
                                    event.preventDefault();
                                }
                            } );
                        }
                    }
                }
            };
        } ] );
    // End RequireJS Define
} );
