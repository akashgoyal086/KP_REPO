//@<COPYRIGHT>@
//==================================================
//Copyright 2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 window,
 startEdit,
 editTileClick,
 stopEdit
 */

/**
 * Note: Some of the above are actually local functions that are defined after they are being referenced. They are
 * include here just to minimize JSLint warnings.
 */

/**
 * tile editing... set "data-tileSizes" attr in html per tile if data-tileSizes are not specified, all sizes defined in
 * possibleSizes array will be allowed. e.g., for a tile that should only be half-size or small: class="tile"
 * data-tileSizes='["half", "small"]'
 * <P>
 * note: the size names do not match the class names initial tile size is still controlled by the tile class; in future,
 * might be nice to align this with the size name. I.e, data-tileSizes=... currentSize="huge"... function self executes
 * on load.
 *
 * @module js/tile-edit
 */
define( [ 'jquery', 'js/start-menu', 'js/tile-drag', 'js/iconService', 'js/logService' ], //
    function ( $, startMenuModule, tileDragModule, iconService, logSvc ) {
        'use strict';

        var exports = {};

        /** TRUE if the tile are currently editable */
        exports.editMode = false;

        /** Initialize gateway */
        exports.init = function () {
            var setupTiles = function () {
                // call the metroUI setup
                startMenuModule.StartMenu();

                // attach our edit events to tiles
                exports.TileEdit();
            };

            if( window.$.isReady ) {
                setupTiles();
            } else {
                // this case shouldn't happen, but it does... sometimes in IE...
                window.$( setupTiles );
            }
        };

        // call this to expose tile editing module
        exports.TileEdit = function () {
            var plugin = this;
            var $tiles, $editTile, tileResized, tileUnpinned, possibleSizes, possibleIcons;

            // initialize the tile edit feature on the gateway
            var initEdit = function () {

                // define the supported sizes and their corresponding style
                possibleSizes = {
                    small: "small",
                    wide: "double",
                    large: "double double-vertical"
                };

                // define the possible icons for the resize
                possibleIcons = {
                    small: "expand",
                    wide: "collapse",
                    large: "shrink"
                };

                // find all tiles
                $tiles = $( ".tile" );

                // place long-click timer (750ms) on each tile for mouse and touch events
                $tiles.on( "tap", function ( event ) {
                        if( !exports.editMode ) {
                            // relying on jqm feature detection here - note that mouse clicks
                            // from touch-enabled devices fall into this block
                            if( $.mobile.support.touch ) {
                                // calling click() from tap for touch devices
                                // should use event.originalEvent.type instead?
                                // mouse click will trigger this itself so not calling to avoid firing click twice
                                this.click();
                            }
                        }
                    } ).on( "taphold", function ( event ) {
                        if( !$( this ).hasClass( "tile-edit" ) ) {
                            startEdit( $( this ), event );
                        }
                    } )
                    // also support mb3
                    .on( 'contextmenu', function ( event ) {
                        event.preventDefault();
                        // remove listener if exists
                        $( document ).off( "click touchstart", editTileClick );
                        startEdit( $( this ), event );
                    } )
                    // add tile edit buttons for unpin and resize
                    .append( '<div class="tile-edit-button unpin"></div><div class="tile-edit-button resize"></div>' );

                // enable tile rearranging
                var allTileGroups = $( '.tile-group' );
                if( allTileGroups.length > 0 ) {
                    $( allTileGroups ).TileDrag( {} );
                }
            };

            // enter edit mode for jQuery tile object
            var startEdit = function ( $tile, event ) {
                // if switching tiles, stop edit on first tile
                if( $editTile && $editTile[ 0 ] !== $tile[ 0 ] ) {
                    stopEdit();
                }
                $editTile = $tile;

                // enable tile drag
                $editTile.trigger( 'setDragMode', [ $editTile, true ] );

                // get the available sizes for this tile
                if( $editTile.attr( "data-tileSizes" ) === undefined ) {
                    $editTile.sizes = [ "small", "wide", "large" ];
                } else {
                    $editTile.sizes = $.parseJSON( $editTile.attr( "data-tileSizes" ) );
                }

                // small size doesn't have a class, so if nothing else, default to that...
                $editTile.currentSize = "small";
                $editTile.find( "div.tile-edit-button.resize>.aw-base-icon" ).remove();
                if( $editTile.sizes.length > 1 ) {
                    // determine size of current tile
                    for( var sizeName in possibleSizes ) {
                        if( $editTile.hasClass( possibleSizes[ sizeName ] ) ) {
                            $editTile.currentSize = sizeName;
                        }
                    }

                    //add tile edit button for unpin
                    $editTile.find( "div.tile-edit-button.resize" ).append(
                        iconService.getTileIcon( possibleIcons[ $editTile.currentSize ] ) );
                }

                // hide unpin button if this is the last tile remaining or if it's protected
                $editTile.find( "div.tile-edit-button.unpin>.aw-base-icon" ).remove();
                if( $tiles.length > 1 && $editTile.attr( "_awp0protected" ) !== "True" ) {
                    // add tile edit button for unpin
                    $editTile.find( "div.tile-edit-button.unpin" ).append( iconService.getTileIcon( 'unpin' ) );
                }

                // set global edit mode and tile modification status
                exports.editMode = true;
                tileResized = false;
                tileUnpinned = false;

                // draw attention to the tile in edit mode
                $editTile.fadeTo( 1, 1 );
                $tiles.not( $editTile ).fadeTo( 1, 0.5 );
                $editTile.addClass( "tile-edit" );

                // exit edit mode on click outside of this tile
                $( document ).on( "click touchstart", editTileClick );
            };

            var stopEdit = function () {
                $tiles.fadeTo( 1, 1 );
                exports.editMode = false;

                $( document ).off( "click touchstart", editTileClick );

                if( $editTile ) {
                    // disable tile drag
                    $editTile.trigger( 'setDragMode', [ $editTile, false ] );
                    $editTile.removeClass( "tile-edit" );

                    // group ordering is based on the last tile in the group
                    // get adjacent tile or last tile in adjacent group
                    var prevOrder = parseInt( $editTile.prev().attr( "_awp0orderno" ) ||
                        $editTile.parent().prev().children().last().attr( "_awp0orderno" ), 10 );

                    var nextOrder = parseInt( $editTile.next().attr( "_awp0orderno" ) ||
                        $editTile.parent().next().children().last().attr( "_awp0orderno" ), 10 );

                    var group = $editTile.parent().attr( "_awp0group" );
                    var newGroup = 0;
                    if( !group ) {
                        // create new group using current time
                        group = 'group' + ( new Date() ).getTime();
                        newGroup = 100; // group order incrementor
                        $editTile.parent().attr( "_awp0group", group );
                    }

                    // update order as-needed based on current position
                    var order = parseInt( $editTile.attr( "_awp0orderno" ), 10 );
                    if( order <= prevOrder || order >= nextOrder || newGroup ) {
                        // calculate new order
                        if( nextOrder && prevOrder ) {
                            order = Math.round( ( nextOrder + prevOrder ) / 2 );
                            // weird special-case (can happen with 1st tile in a middle group)
                            if( order > nextOrder ) {
                                order = nextOrder - 2;
                            }
                        } else {
                            if( !nextOrder ) { // last tile in last group
                                order = prevOrder + 2 + newGroup;
                            } else { // first tile in first group
                                order = nextOrder - 2 - newGroup;
                            }
                        }

                        if( isNaN( order ) ) {
                            logSvc.error( 'Error positioning tile.' );
                            logSvc.info( 'previous tile: ' + prevOrder + ', next tile: ' + nextOrder + ', new group: ' + newGroup );
                            order = 0;
                        }

                        // track order in the dom
                        $editTile.attr( "_awp0orderno", order );
                    }

                    $editTile.find( "div.tile-edit-button.resize>.aw-base-icon" ).remove();
                    $editTile.find( "div.tile-edit-button.unpin>.aw-base-icon" ).remove();

                    // commit any change and exit edit mode
                    // this method will only make a server-trip if something has changed
                    exports.modifyTile( $editTile.attr( "_awp0uid" ), $editTile.currentSize.toString(), false, order,
                        group );
                    $editTile = null;
                }
            };

            // click (or touch) made while in edit mode
            var editTileClick = function ( ev ) {
                // check if the active tile was clicked
                var $clickedButton = $( ev.target ).closest( ".tile-edit-button" );
                var $clickedTile = $( ev.target ).closest( ".tile" );
                var cancelEdit = false;
                if( $clickedTile.is( $editTile ) ) {
                    // click is in current tile
                    if( $clickedButton.hasClass( "resize" ) ) {
                        // click was on resize button
                        // find size in array of sizes for this tile and decrement
                        var index = $editTile.sizes.indexOf( $editTile.currentSize );
                        if( --index < 0 ) {
                            index = $editTile.sizes.length - 1;
                        }
                        var newSize = $editTile.sizes[ index ];
                        // remove any size styling - in future, could loop through possibleSizes instead
                        $editTile.removeClass( "double-vertical" ).removeClass( "double" ).removeClass( "small" );
                        // set the style for the new size
                        $editTile.addClass( possibleSizes[ newSize ] );

                        //Add up update the resize button
                        $editTile.find( "div.tile-edit-button.resize>.aw-base-icon" ).remove();
                        $editTile.find( "div.tile-edit-button.resize" ).append(
                            iconService.getTileIcon( possibleIcons[ newSize ] ) );
                        $editTile.currentSize = newSize;

                        // tile has been modified
                        tileResized = true;
                    } else if( $clickedButton.hasClass( "unpin" ) ) {
                        // click was on unpin button
                        tileUnpinned = true;
                        exports.modifyTile( $editTile.attr( "_awp0uid" ), $editTile.currentSize.toString(),
                            tileUnpinned );
                        $editTile.remove();
                        $tiles = $tiles.not( $editTile );
                        cancelEdit = true;
                    }
                    if( tileResized || tileUnpinned ) {
                        // update layout
                        var tilesDiv = $( '.tiles' );
                        tilesDiv.trigger( 'changed' );
                        // and check for re-update every 200ms to deal with delayed update issue
                        // stop after 600ms - this seems to be worst-case
                        setTimeout( function () {
                            tilesDiv.trigger( 'changed' );
                            // A race condition exists where stopEdit fire before our GWT TileClickHandler, effectively
                            // causing an issue where we don't "capture" the click and it goes straight through into GWT land.  Putting
                            // this delay in here allows the TileClickHandler to see that we are still in edit mode, thus allowing
                            // us to capture the click in this function and dealing with it as intended.
                            if( cancelEdit ) {
                                $editTile = null;
                                stopEdit();
                            }
                            setTimeout( function () {
                                tilesDiv.trigger( 'changed' );
                                setTimeout( function () {
                                    tilesDiv.trigger( 'changed' );
                                }, 200 );
                            }, 200 );
                        }, 200 );
                    }
                } else {
                    // click was outside of $editTile
                    stopEdit();
                    if( $clickedTile.hasClass( "tile" ) ) {
                        // activate edit on newly selected tile
                        startEdit( $clickedTile, ev );
                    }
                }
            };

            initEdit();
        };

        /**
         * Create a 'dummy' function.
         */
        exports.modifyTile = function () {
            logSvc.info( 'Missing abstract implementation....modifyTile should be overritten' );
        };

        /**
         * Clean up listeners, DOM references, etc
         */
        exports.destroy = function () {
            var $tiles = $( ".tile" );

            $tiles.off( "tap" );
            $tiles.off( "taphold" );
            $tiles.off( "contextmenu" );
            $tiles.off( "setDragMode" );
            $tiles.off( "changed" );
            $( window ).off( "resize" );

            $( ".aw-gateway-gatewayPanel" ).off( "mousewheel" );
            $.removeData( ".aw-gateway-gatewayPanel" );

            $.removeData( ".tiles" );

            if( typeof editTileClick !== "undefined" ) {
                $( document ).off( "click touchstart", editTileClick );
            }

            var $groups = $( '.tile-group' );
            $groups.remove();

            $tiles.remove();
        };

        return exports;
    } );
