//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 window
 */

/**
 * use this plugin if you want to make tiled menu like windows 8 start menu what plugin needs for? it needs for
 * following elements structure
 *
 * <pre>
 *  (div class='page')
 *      (div class='tiles')
 *          (div class='tile-group')
 *              (div class='tile')(/div)
 *              (div class='tile')(/div)
 *              .........
 *              (div class='tile')(/div)
 *          (/div)
 *      (/div)
 *  (/div)
 * </pre>
 *
 * if you do some changes, for example, move tile from one group, you have to use $('.tiles').trigger('changed') and all
 * tiles will placed to own place
 *
 * @module js/start-menu
 */
define([ 'jquery' ], function($) {
    'use strict';

    $.StartMenu = function(element, options) {
        var $startMenu, plugin = this, maxGroupHeight;

        // ssu: attach h-scroll to mousewheel in aw-gateway-gatewayPanel
        var addMouseWheel = function() {
            $(".aw-gateway-gatewayPanel").on(
                    "mousewheel",
                    function(event, delta) {

                        // ignore ctrl-mousewheel, let browser do the default (zoom)
                        if (event.ctrlKey) {
                            return true;
                        } else {
                            var scroll_value = delta * 50;
                            $(".aw-gateway-gatewayPanel").scrollLeft(
                                    $(".aw-gateway-gatewayPanel").scrollLeft() - scroll_value);
                            return false;
                        }
                    });
        };

        var setPageWidth = function() {
            var tilesWidth = 0;

            $startMenu.find(".tile-group").each(function() {
                tilesWidth += $(this).outerWidth() + 80;
            });

            $startMenu.css("width", tilesWidth);

            // ssu: explicitly set height and width on the aw-gateway-gatewayPanel (parent of .page)
            // TODO: revisit with metro2.0
            var docH = $(document).height();
            var docW = $(document).width();
            var $topPanel = $(".aw-gateway-gatewayPanel");
            var headersH;

            $(".aw-gateway-gatewayPanel").off("mousewheel");

            if (docW < 481) // narrow-mode
            {
                headersH = 45 + 34 + 4;
                $(".aw-gateway-gatewayPanel").scrollLeft(0);
            } else {
                headersH = 60 + 27 + 4; // add 4px fudge factor to avoid partial scroll crop
                $(".aw-gateway-gatewayPanel").scrollTop(0);
                addMouseWheel();
            }

            $topPanel.css("height", docH - headersH);
        };

        /**
         * called on init and on resize window and any tiles moves
         */
        var tuneUpStartMenu = function() {
            var $groups = $startMenu.find('.tile-group');
            if ($groups.length === 0) {
                return;
            }

            maxGroupHeight = $(window).height() - $($groups.get(0)).offset().top;

            $groups.each(function(index, group) {
                var $group = $(group);
                // finding min width for group
                var groupWidth = 0;
                var $tiles = $group.find('.tile');
                if ($tiles.length === 0) {
                    return;
                }
                // finding min width according to the widest tile
                $tiles.each(function(index, tile) {
                    var $tile = $(tile);
                    var tileWidth = 161;
                    if ($tile.hasClass('double')) {
                        tileWidth = 322;
                    } else if ($tile.hasClass('triple')) {
                        tileWidth = 483;
                    } else if ($tile.hasClass('quadro')) {
                        tileWidth = 644;
                    }

                    if (tileWidth > groupWidth) {
                        groupWidth = tileWidth;
                    }
                });

                $group.css({
                    width : 'auto',
                    maxWidth : groupWidth
                });

                var counter, groupHeight_, groupHeight = $group.height();
                while (groupHeight > maxGroupHeight) {
                    if (counter > $tiles.length) { // protection from endless loop
                        break;
                    } else if (groupHeight === groupHeight_) {
                        counter++;
                    } else {
                        counter = 1;
                    }
                    groupHeight_ = groupHeight;
                    groupWidth += 161;
                    $group.css({
                        'maxWidth' : groupWidth
                    });
                    groupHeight = $group.height();
                }
            });

            setPageWidth();
        };

        plugin.init = function() {
            var resizeTimer;

            $startMenu = $('.tiles');

            setPageWidth();
            tuneUpStartMenu(); // need twice

            $(window).on('resize', function() {
                clearTimeout(resizeTimer);
                resizeTimer = setTimeout(function() {
                    tuneUpStartMenu();
                    setTimeout(function() {
                        tuneUpStartMenu();
                    }, 100);
                }, 100);
            });

            $startMenu.on('changed', function() {
                tuneUpStartMenu();
            });
        };

        plugin.init();
    };

    $.fn.StartMenu = function(options) {
        return this.each(function() {
            if (undefined === $(this).data('StartMenu')) {
                var plugin = new $.StartMenu(this, options);
                $(this).data('StartMenu', plugin);
            }
        });
    };

    var exports = {};

    /**
     * Setup for Jquery to access this API later.
     */
    exports.StartMenu = $.StartMenu;

    return exports;
});