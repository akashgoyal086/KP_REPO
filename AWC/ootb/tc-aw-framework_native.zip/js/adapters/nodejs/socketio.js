// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * @module adapters/nodejs/socketio
 */
define( [], function() {
    'use strict';
    var exports = {};
    exports.connect = function() {
        return {
            // nothing to do
            connected: false
        };
    };
    exports.disconnect = function() {
        // nothing to do
    };
    return exports;
} );