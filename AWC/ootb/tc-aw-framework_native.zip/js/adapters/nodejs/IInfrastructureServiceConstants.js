// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 *
 * @module adapters/nodejs/IInfrastructureServiceConstants
 */
define( [], function() {
    'use strict';

    var exports = {};

    return exports;
} );
