// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * http://uncorkedstudios.com/blog/multipartformdata-file-upload-with-angularjs
 *
 * @module adapters/nodejs/fmsService
 */
define( [ //
'app', //
'assert', //
'fs', //
'httpWrapper', //
'js/logService', //
'soa/kernel/soaService', //
'soa/preferenceService' //
], function( app, assert, fs, httpWrapper, logSvc, soaSvc, prefSvc ) {
    'use strict';

    var exports = {};

    /**
     * FMS Upload
     *
     * @param {String} filePath - Absolute path to the file to be uploaded.
     * @param {String} ticket - File 'ticket' previously generated to allow the uploaded file to be tracked.
     */
    exports.upload = function( filePath, ticket ) {
        assert( ticket, 'Invalid ticket!' );
        assert( filePath, 'Invalid file!' );

        var formData = {
            fmsFile: fs.createReadStream( filePath ),
            fmsTicket: ticket
        };

        return prefSvc.getStringValue( 'ActiveWorkspaceHosting.URL' ).then( function( url ) {
            assert( url, 'No ActiveWorkspaceHosting.URL preference found!' );
            httpWrapper.post( url, '/fms/fmsupload/', null, formData ).then( function( response ) {
                return response;
            }, function( err ) {
                logSvc.error( 'file upload failed:\n\t' + err.message );
            } );
        } );
    };

    /**
     * Register this service with the AngularJS application.
     *
     * @returns {Object} Reference to this module's API.
     */
    app.factory( 'fmsService', function() {
        return exports;
    } );

    return exports;
} );
