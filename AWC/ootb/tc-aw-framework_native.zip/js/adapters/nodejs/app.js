// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define,
 require
 */

/**
 * @module adapters/nodejs/app
 */
define( [], function() {
    'use strict';
    var exports = {};

    /**
     * Note: This function is a dummy 'stub' for the functionality provided by the AnulgarJS' application module.
     */
    exports.factory = function() {
        // Do nothing, this is a dummy 'stub'
    };

    /**
     * Load 'lodash'
     */
    exports._ = require( 'lodash' );

    exports.eventBus = {};

    /**
     * Note: This function is a dummy 'stub' for the functionality provided by the AnulgarJS' application module.
     */
    exports.eventBus.subscribeSoa = exports.eventBus.subscribeLocalStorage = exports.eventBus.subscribeWS = function() {
        // Nothing to do
    };

    /**
     * Note: This function is a dummy 'stub' for the functionality provided by the AnulgarJS' application module.
     */
    exports.eventBus.publishSoa = exports.eventBus.publishLocalStorage = exports.eventBus.publishWS = function() {
        // Nothing to do
    };

    exports.eventBus.getLocalStorage = function() {
        // Nothing to do
    };

    /**
     * Locale values set up-to-date once login is complete.
     * <P>
     * Note: Until login, the default values we be as shown here.
     */
    exports.localeInfo = {
        locale: 'en_US',
        is12HrFormat: false,
        sessionDateTimeFormat: 'dd-MMM-yyyy HH:mm',
        sessionDateFormat: 'dd-MMM-yyyy',
        sessionTimeFormat: 'HH:mm'
    };

    return exports;
} );