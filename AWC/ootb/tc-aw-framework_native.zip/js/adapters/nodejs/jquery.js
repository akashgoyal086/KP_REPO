// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 *
 * @module adapters/nodejs/jquery
 */
define( [], function() {
    'use strict';
    var jquery = function() {
    };
    jquery.html = function( value ) {
        return {
            val: function() {
                return value;
            }
        };
    };
    return jquery;
} );
