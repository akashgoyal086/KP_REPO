// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define,
 Buffer,
 process
 */

/**
 * This is the HTTP wrapper.
 *
 * There should be zero Teamcenter logic in this file.
 *
 * @module adapters/nodejs/httpWrapper
 */
define( [ 'assert', 'q', 'request' ], function( assert, Q, request ) {
    'use strict';

    /**
     * The ID of the session used to indicate the user is currently NOT logged in.
     */
    var defaultJSessionID = 'JSESSION=LOGGED_OFF';

    /**
     * ID of the current session.
     */
    var m_jsessionID = defaultJSessionID;

    var exports = {};

    /**
     * Invoke a service on the HTTP service via a 'GET' to the given URL.
     *
     * @param {String} url - (Not used) URL to the HTTP service to 'POST' to.
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     *          <P>
     *          Note: The caller should provide callback functions to the 'then' methods of this promise object (e.g.
     *          successCallback, [errorCallback, [notifyCallback]]). These methods will be invoked when the associated
     *          service result is known.
     */
    exports.get = function( url ) {
        return request.get( url );
    };

    /**
     * Invoke a service on the HTTP service via a 'POST' to the given URL.
     *
     * @param {String} url - URL to the HTTP service to 'POST' to.
     * @param {Object} jsonData - JSON payload data to provide to the service.
     * @param {FormData} formData - Form Data to provide to the service (used for file upload support)
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the given service is invoked and its
     *          response data is available.
     *          <P>
     *          Note: The caller should provide callback functions to the 'then' and/or 'fail' methods of this promise
     *          object. These methods will be invoked when the associated service result is known.
     */
    exports.post = function( url, jsonData, formData ) {
        assert( url, 'url must be provided!' );
        assert( jsonData || formData, 'Caller must provide either jsonData or formData!' );

        var urlFinal = url;

        if( !urlFinal || urlFinal.indexOf( 'http' ) !== 0 ) {
            urlFinal = process.env.AW_PROXY_SERVER + urlFinal;
        }

        var options = {
            url: urlFinal,
            headers: {
                Cookie: m_jsessionID
            }
        };

        if( jsonData ) {
            options.body = jsonData;
            options.json = true;
        } else if( formData ) {
            options.formData = formData;
        }

        var deferred = Q.defer();

        function callback( error, response, body ) {
            if( error ) {
                deferred.reject( error );
            } else if( typeof body === 'string' && body.indexOf( '<?xml version' ) === 0 ) {
                deferred.reject( new Error( body ) );
            } else {
                if( response && response.headers && response.headers['set-cookie'] ) {
                    var setCookie = response.headers['set-cookie'];
                    for( var ii = 0; ii < setCookie.length; ii++ ) {
                        var cookies = setCookie[ii].split( ';' );
                        for( var jj = 0; jj < cookies.length; jj++ ) {
                            var cookie = cookies[jj];
                            if( cookie && cookie.trim().indexOf( 'JSESSIONID=' ) === 0 ) {
                                m_jsessionID = cookie.trim();
                            }
                        }
                    }
                }

                deferred.resolve( body );
            }
        }

        request.post( options, callback );

        return deferred.promise;
    };

    /**
     * Resets the 'jsession' to a 'logged off' value.
     */
    exports.clearJSessionID = function() {
        m_jsessionID = defaultJSessionID;
    };

    return exports;
} );
