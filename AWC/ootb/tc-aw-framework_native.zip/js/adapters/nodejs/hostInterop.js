// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 *
 * @module adapters/nodejs/hostInterop
 */
define( [], function() {
    'use strict';

    var exports = {};

    exports.isHostServiceAvailable = function( desc ) {
        return false;
    };

    exports.ServiceDescriptor2 = function() {
        // Nothing to do.
    };

    return exports;
} );
