// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * This module is used to adapt the functionality provided by NodeJS module, 'chalk', to work within an AngularJS based
 * application.
 *
 * @module adapters/angularjs/chalk
 */
define( [], function() {
    'use strict';
    var exports = {};

    exports.red = function( msg ) {
        return msg;
    };

    exports.yellow = function( msg ) {
        return msg;
    };

    exports.yellow.dim = function( msg ) {
        return msg;
    };

    exports.green = function( msg ) {
        return msg;
    };

    exports.green.dim = function( msg ) {
        return msg;
    };

    exports.gray = function( msg ) {
        return msg;
    };

    return exports;
} );