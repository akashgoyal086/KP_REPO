// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define,
 document
 */

/**
 * @module adapters/angularjs/q
 */
define( [ 'angular' ], function( ngModule ) {
    'use strict';

    /**
     * Get the AngularJS $injector service from the document root element if possible. If not, get an instance from the
     * AngularJS module itself.
     * <P>
     * Note: It's possible the 'basic' one derived from AngularJS will not have all the services registered with it yet.
     */
    var docNgElement = ngModule.element( document.body );

    var injector = docNgElement.injector();

    if( !injector ) {
        return ngModule.injector( [ 'ng' ] );
    }

    return injector.get( '$q' );
} );