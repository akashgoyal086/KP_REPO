// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * This module is used to adapt the functionality provided by NodeJS module, 'assert', to work within an AngularJS based
 * application.
 *
 * @module adapters/angularjs/assert
 */
define( [ 'js/logService' ], function( logSvc ) {
    'use strict';

    /**
     * This function throws an exception with the given message text if the given 'expression' evaluates to FALSE.
     *
     * @param {Object} condition - Expression to evaluate.
     * @param {string} message - Message text to use in any exception thrown.
     * @returns {Void}
     */
    return function( condition, message ) {
        if( !condition ) {
            logSvc.warn( 'assert failed: ' + message );
            throw new Error( 'assert failed: ' + message );
        }
    };
} );