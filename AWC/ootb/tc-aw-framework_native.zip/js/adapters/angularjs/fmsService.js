// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * @module adapters/angularjs/fs
 */
define( [ 'assert' ], function( assert ) {
    'use strict';
    var exports = {};

    /**
     * Note: This function is a dummy 'stub' for the functionality provided by the NodeJS' 'fs' (a.k.a. file system)
     * module.
     *
     * @param {String} file - file path
     * @param {String} ticket - ticket
     */
    exports.upload = function( file, ticket ) {
        assert( ticket, 'Invalid ticket!' );
        assert( file, 'Invalid file!' );
    };

    return exports;
} );