// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define,
 document
 */

/**
 * @module adapters/angularjs/httpWrapper
 */
define( [ 'assert', 'angular', 'app' ], function( assert, ngModule, app ) {
    'use strict';

    /**
     * Setup to cache some AngularJS services.
     */

    var $http = null;

    var init = function(){
        if(!$http){
            $http = app.injector.get('$http');
            assert( $http, 'Unable to get AngularJS $http service' );
        }
    };

    var exports = {};

    /**
     * Invoke a service on the HTTP service via a 'GET' to the given URL.
     *
     * @param {String} url - (Not used) URL to the HTTP service to 'POST' to.
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     *          <P>
     *          Note: The caller should provide callback functions to the 'then' methods of this promise object (e.g.
     *          successCallback, [errorCallback, [notifyCallback]]). These methods will be invoked when the associated
     *          service result is known.
     */
    exports.get = function( url ) {
        init();
        return $http.get( url );
    };

    /**
     * Invoke a service on the HTTP service via a 'POST' to the given URL.
     *
     * @param {String} url - (Not used) URL to the HTTP service to 'POST' to.
     * @param {Object} jsonData - JSON payload data to provide to the service.
     * @param {FormData} formData - Form Data to provide to the service (used for file upload support)
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     *          <P>
     *          Note: The caller should provide callback functions to the 'then' methods of this promise object (e.g.
     *          successCallback, [errorCallback, [notifyCallback]]). These methods will be invoked when the associated
     *          service result is known.
     */
    exports.post = function( url, jsonData, formData ) {
        init();
        return $http( {
            method: 'POST',
            url: url,
            data: jsonData
        } ).then(
            function( response ) {
                assert( response, 'No response given for ' + url );

                var body = response.data;

                assert( typeof body !== 'string' || body.indexOf( '<?xml version' ) === -1,
                    'Unexpected response body for: ' + url );

                return body;
            } );
    };

    /**
     * Resets the 'jsession' to a 'logged off' value.
     */
    exports.clearJSessionID = function() {
        // Nothing to do
    };

    return exports;
} );