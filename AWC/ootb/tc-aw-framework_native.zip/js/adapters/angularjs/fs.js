// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * @module adapters/angularjs/fs
 */
define( [], function() {
    'use strict';
    var exports = {};

    /**
     * Note: This function is a dummy 'stub' for the functionality provided by the NodeJS' 'fs' (a.k.a. file system)
     * module.
     *
     * @param {string} name service name
     * @param {Function} providerFunction Function for creating new instance of the service.
     */
    exports.factory = function( name, providerFunction ) {
        // Do nothing, this is a dummy 'stub'
    };

    return exports;
} );