//@<COPYRIGHT>@
//==================================================
//Copyright 2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/* global
 define,
 document,
 awInclude,
 console
 */

/**
 * @module js/NgUITable - this is NOT USED in aw3.1 - will be used once VMGridWidget is turned on.
 *
 * The require define formatting is tied to the karma test script, don't change the format!
 */
define([ 'app', 'angular', 'jquery', 'js/NgDataProvider', 'ui.grid', 'js/NgProperty', 'js/NgI18n' ],
    function( app, ngModule, $, dataProviderModule ) {
        'use strict';

        // the ui-grid css is shared by several modules, check before adding it
        var cssCheck = $( "head:first > link" ).filter( "[href='" + app.getBaseUrlPath() + "/lib/uigrid/ui-grid.min.css']" ).length;
        if( cssCheck === 0 ) {
            // add the CSS for 'ui-grid' module.
            var link = document.createElement( "link" );
            link.type = "text/css";
            link.rel = "stylesheet";
            link.href = app.getBaseUrlPath() + "/lib/uigrid/ui-grid.min.css";
            document.getElementsByTagName( "head" )[ 0 ].appendChild( link );
        }

        var exports = {};

        /**
         * Defines the table controller
         *
         * @constructor awTableController
         *
         * @memberof NgControllers
         */
        app.controller( 'awTableController', [
            '$scope',
            '$timeout',
            'uiGridConstants',
            '$q',
            function( $scope, $timeout, uiGridConstants, $q ) {
                var self = this;

                self.whatamI = "awTableController"; // debug aid

                // internal switch to indicate that we are doing a reconcile of selection programmatically
                // do not trigger external selection change notification while set.
                self.reconcilingSelectionSet = false;
                self.needToReconcilePromise;

                /**
                 * function which will obtain and bind the initial set of data.
                 */
                self.getInitialGridData = function() {
//                    console.log( 'getInitialGridData called' );
                    var promise = $q.defer();

                    if( self.containerVM && self.containerVM.uiDataAdapter &&
                        self.containerVM.uiDataAdapter.bindingCollection ) {
                        var dataLen = self.containerVM.uiDataAdapter.bindingCollection.data.length;
//                        console.log( "initial rowcount " + dataLen );
                        self.containerVM.gridOptions.data = self.containerVM.uiDataAdapter.bindingCollection.data;

                        $timeout( function() {
//                            console.log( 'getfirst timeout' );
                            promise.resolve();
                            // see if register has already happened?
                            if( self.gridApi.infiniteScroll ) {
//                                console.log( 'getFirst nested timeout, YES infScroll' );
                                self.gridApi.infiniteScroll.resetScroll( false, self.containerVM.uiDataAdapter.dataProvider.moreRows );
                            } else {
                                console.log( 'getFirst nested timeout, no infScroll yet' );
                            }
                        } );
                    } else {
                        console.log( "no data provider yet" );
                        promise.resolve();
                    }
                    return promise.promise;
                };

                /**
                 * call into the data provider with a promise pattern
                 */
                self.promiseGetNextPage = function( skip ) {
                    var deferred = $q.defer();

                    self.containerVM.uiDataAdapter.getNextPage( skip, deferred );
                    return deferred.promise;
                };

                /**
                 * function invoked by uiGrid infinite scroll to get the next page of data.
                 * Async behavior - invoke the data provider which will add data to the binding
                 * collection and update status.
                 *
                 * This is triggered by a scroll down in the grid
                 */
                self.getDataDown = function() {
//                    console.log( 'self.getDataDown' );
                    var promise = $q.defer();
                    var skipCount = self.containerVM.uiDataAdapter.rowcount;
                    // skipcount is presently ignored....

                    self.promiseGetNextPage( skipCount ).then( function() {
                        // bind the lastest data to the grid
                        self.containerVM.gridOptions.data = self.containerVM.uiDataAdapter.bindingCollection.data;

                        // notify grid for more down available or not
                        var moreDown = self.containerVM.uiDataAdapter.dataProvider.moreRows;
                        var moreUp = false; // currently don't support page up retrieval

                        console.log( 'next page, self len: ' + self.containerVM.gridOptions.data.length +
                            ' moreDown: ' + moreDown + ' totalRows: ' + self.containerVM.uiDataAdapter.dataProvider.totalRowCount );

                        self.gridApi.infiniteScroll.dataLoaded( moreUp, moreDown ).then( function() {
                            promise.resolve();
                        } );
                    } );
                    return promise.promise;
                };

                /**
                 * not yet supported - api to retrieve data when scrolling upwards.
                 */

                self.getDataUp = function() {
                    console.log( 'getDataUp called - not supported yet!' );
                    // scrolling upwards in the list - if we've "dumped" memory pages to free
                    // memory, we need to go back and load them again.
                    //  FUTURE

                };

                /**
                 * create a uiGrid column definition instance based on the field information
                 * provided.
                 */
                self.createColDef = function( field ) {
                    var colDef = {};
                    colDef.field = field.name;
                    colDef.name = field.name;
                    colDef.displayName = field.displayName;
                    // do we need to ensure this is a function too?  could be a string maybe
                    if( field.api ) {
                        colDef.awapi = field.api;
                    }

                    if( field.cellTemplateStr ) {
                        colDef.cellTemplate = field.cellTemplateStr;
                    } else {
                        colDef.cellTemplate = '<aw-property-native-table-val prop="row.entity.entityDC.propDCs[col.field]" edit="containerVM.editable" />';
                    }

                    // other column aspects we can control
                    colDef.enableHiding = true;
                    colDef.enableSorting = false; // coming in phase1
                    colDef.enableColumnMenu = false;
                    colDef.enableFiltering = false;
                    colDef.enableColumnResizing = field.resizable; // specific to individual column.
                    colDef.enableColumnMoving = true;
                    colDef.width = field.width; // number, percentage, or * auto

                    colDef.cellTooltip = function( r, c ) {
                        return 'tooltipval';
                    };
                    colDef.visible = true;

                    return colDef;
                };

                /**
                 * @memberof NgControllers.awTableController
                 *
                 * @param {Object}
                 *            containerVM - the gridVM
                 */
                self.setContainerVM = function( containerVM ) {
//                    console.log( 'ui grid controller called setContainerVM.' );
                    $scope.containerVM = containerVM;
                    self.containerVM = containerVM;

                    var colDefs = [];
                    for( var inx = 0; inx < containerVM.fields.length; inx++ ) {
                        colDefs.push( self.createColDef( containerVM.fields[ inx ] ) );
                    }

//                    console.log( 'ui grid controller setting data.' );
                    // default settings for table capabilities
                    var s_multiSelect = false;
                    var s_rowSelect = false;
                    var s_allowColumnResize = true;

                    var s_useVarHeightRow = false;
                    var s_virtualizationThreshold;
                    var s_rowHeight = 37; //px

                    // apply the settings
                    if( self.containerVM.tableSettings ) {
                        var settings = self.containerVM.tableSettings;

                        if( settings.selectionOption ) {
                            if( settings.selectionOption === 'single' ) {
                                s_rowSelect = true;
                            } else if( settings.selectionOption === 'multi' ) {
                                s_rowSelect = true;
                                s_multiSelect = true;
                            } else { // none
                                console.log( 'selection option is none' );
                            }
                        }

                        if( settings.allowColumnResize ) {
                            s_allowColumnResize = settings.allowColumnResize;
                        }

                        if( settings.allowVariableRowHeight ) {
                            s_useVarHeightRow = true;
                        }

                        if( s_useVarHeightRow ) {
                            s_virtualizationThreshold = 100000;
                        }

//                        console.log( 'apply table settings' );
                    }

                    // create the options object on the scope - this drives uiGrid
                    $scope.gridOptions1 = {
                        // so we get the right string text wrap.
                        rowHeight: s_rowHeight,

                        // for var row height - disable virtualization - ugh
                        virtualizationThreshold: s_virtualizationThreshold,

                        // paging/scroll control
                        infiniteScrollRowsFromEnd: 30, // how close to end before we request another page.
                        infiniteScrollUp: false, // no up scroll support yet.
                        infiniteScrollDown: true,
                        enableInfiniteScroll: true, // always leverage paging

                        // selection controls
                        enableRowSelection: s_rowSelect,
                        enableRowHeaderSelection: false,
                        enableSelectAll: false,
                        multiSelect: s_multiSelect, // single select only to start with

                        enableColumnResizing: s_allowColumnResize,
                        enableGridMenu: true,
                        // columns
                        columnDefs: colDefs,
                        data: [], // this will get bound

                        // register the api interaction and callback
                        onRegisterApi: function( uiGridApi ) {
//                            console.log( ' onRegisterApi' );
                            $scope.gridApi = uiGridApi;
                            self.gridApi = uiGridApi;

                            // this event is triggered when the grid actually renders rows.
                            // at this point there are actual data rows that have been bound.
                            // see if there is an outstanding selection reconcile needed.
                            uiGridApi.core.on.rowsRendered( uiGridApi.grid.appScope, function() {
                                if( self.needToReconcilePromise ) {
                                    if( $scope.gridApi && $scope.gridApi.grid.options &&
                                        $scope.gridApi.grid.options.data.length > 0 ) {
                                        // can only do the task if there is data to reconcile against.
                                        var task = self.needToReconcilePromise;
                                        self.needToReconcilePromise = undefined; // clear reference (run it once)
                                        task.resolve(); // trigger the task
                                    }
                                }
                            } );

                            uiGridApi.infiniteScroll.on.needLoadMoreData( uiGridApi.grid.appScope, self.getDataDown );
                            uiGridApi.infiniteScroll.on.needLoadMoreDataTop( uiGridApi.grid.appScope, self.getDataUp );

                            uiGridApi.colMovable.on.columnPositionChanged( $scope, function( colDef, origPosition, newPosition ) {
                                var msg = 'col position change ' + colDef.name + ' old ' + origPosition + ' new ' + newPosition;
                                console.log( msg );
                            } );
                            uiGridApi.colResizable.on.columnSizeChanged( $scope, function( colDef, deltaChange ) {
                                var msg = 'col Size change ' + colDef.name + ' ' + deltaChange;
                                console.log( msg );
                                var currentSize = 0;
                                var colList = $scope.gridApi.grid.columns;
                                for( var i = 0; i < colList.length; i++ ) {
                                    if( colList[ i ].colDef === colDef ) {
                                        currentSize = colList[ i ].drawnWidth;
                                    }
                                }
                                if( $scope.containerVM && $scope.containerVM.events && $scope.containerVM.events.onColumnSizeChange ) {
                                    $scope.containerVM.events.onColumnSizeChange( colDef.name, deltaChange, currentSize );
                                }
                            } );

                            uiGridApi.selection.on.rowSelectionChanged( $scope, function( row ) {
                                // console.log( 'row selection change. ' );
                                if( !self.reconcilingSelectionSet ) {
                                    // ensure we don't trigger external notifications while we are reconciling selection
                                    if( $scope.containerVM && $scope.containerVM.events && $scope.containerVM.events.onRowSelectionChange ) {
                                        $scope.containerVM.events.onRowSelectionChange( row.entity.entityDC, row.isSelected );
                                    }
                                }
                            } );

                            uiGridApi.selection.on.rowSelectionChangedBatch( $scope, function( rows ) {
                                var msg = 'rows changed ' + rows.length;
                                console.log( msg );
                            } );

                        }

                    }; // end gridOptions

                    self.containerVM.gridOptions = $scope.gridOptions1;
                    $scope.$evalAsync( function() {
//                        console.log( 'trigger digest at end of setContainerVM' );
                    } );

                }; // setContainerVM

                $scope.refreshData = function( containerVM ) {
                    // update the grid binding data
                    containerVM.gridOptions.data = containerVM.uiDataAdapter.bindingCollection.data;
                };

                $scope.setDataAdapter = function( containerVM ) {
//                    console.log( 'scope. controller refresh - setDataAdapter' );
                    // trigger the loading of the initial data
                    self.getInitialGridData().then( function() {
                        $timeout( function() {
//                            console.log( 'getInitialGridData initial timeout delay' );
                            // reset the grid scroll position
                            if( self.gridApi && self.gridApi.infiniteScroll.resetScroll ) {
                                self.gridApi.infiniteScroll.resetScroll( false, containerVM.uiDataAdapter.dataProvider.moreRows );
                            } else {
                                console.log( 'getFirst initial timeout, no resetScroll yet' );
                            }
                        } );
                    } );
                };

                /**
                 * Trigger an update of the property list info from the column definition View Models
                 *
                 * @memberof NgControllers.awTableController
                 *
                 * @param {Object}
                 *            containerVM - the grid VM
                 */
                $scope.updateColumnDefs = function( containerVM ) {
//                    console.log( 'scope.updateColumnDefs updating property list ' );
                    if( containerVM.fields && containerVM.fields.length > 0 ) {
                        // empty existing
                        var colDefs = [];
                        // create the column definition representation for uiGrid.
                        // TODO - should these be data bound/Observables??
                        for( var inx = 0; inx < containerVM.fields.length; inx++ ) {
                            colDefs.push( self.createColDef( containerVM.fields[ inx ] ) );
                        }
                        containerVM.gridOptions.columnDefs = colDefs;
                    }
                };

                /**
                 * align the uiGrid selection with the incoming selected list.
                 */
                $scope.reconcileApplicationSelectionSet = function( selectedEntities ) {
                    self.reconcilingSelectionSet = true;
                    // a flag so that selection change notifications are not triggered
                    // while synch-ing selection

                    try {
                        if( $scope.gridApi && $scope.gridApi.selection ) {
                            // step 1 - remove any grid selections that no longer apply
                            var incomingCount = selectedEntities.length;
                            var gridSelCount = $scope.gridApi.grid.selection.selectedCount;
                            if( gridSelCount > 0 ) {
                                // see if any of these existing selections need to be cleared
                                var gridSelectedRows = $scope.gridApi.selection.getSelectedGridRows();
                                for( var idx = 0; idx < gridSelCount; idx++ ) {
                                    var selectedRow = gridSelectedRows[ idx ];
                                    // either no input list, or the current row is not in the list: clear it.
                                    if( selectedRow && selectedRow.entity ) {
                                        if( incomingCount === 0 || selectedEntities.indexOf( selectedRow.entity ) < 0 ) {
                                            selectedRow.setSelected( false ); // clear the selection
                                        }
                                    } else {
                                        console.log( ' selected row is undefined from gridSelectedRows' );
                                    }

                                }
                            }

                            //  step 2 - select any new entities from the input list.
                            if( incomingCount > 0 ) {
                                for( var idx = 0; idx < incomingCount; idx++ ) {
                                    var selectedEntity = selectedEntities[ idx ];
                                    // set the row for the entity as selected.  It may already be selected, but
                                    // we don't want to go thru the cost of getting the gridRow instance
                                    // for the entity.
                                    // console.log( 'selecting entity from the input list' );
                                    $scope.gridApi.selection.selectRow( selectedEntity );
                                }
                            }
                        } else {
                            // console.log( 'no gridAPI selection object yet nothing to interact with.' );
                            if( self.needToReconcilePromise ) {
                                console.log( 'already have a promise outstanding???' );
                            }
                            // create a promise to execute after the onRegister happens.
                            self.needToReconcilePromise = $q.defer();
                            self.needToReconcilePromise.promise.then( function() {
                                console.log( 'reconcile promise fires ' + selectedEntities.length );
                                // this seems sort of recursive.... can we do it?
                                $scope.reconcileApplicationSelectionSet( selectedEntities );
                            } );
                        }

                    } catch( ex ) {
                        console.log( 'exception during selection reconcile: ' + ex );
                    } finally {
                        self.reconcilingSelectionSet = false;
                    }
                };

            }
        ] ); // awTableController

        /**
         * define a directive to support image URI retrieval from injected code.  Will leverage the injected callback
         * function (for GWT integration) to get the image URI.
         *
         * Will set the inner html text of the directive element with the returned URI content.
         *
         */
        app.directive( 'awGridImage', function() {
            return {
                restrict: "E",
                link: function( scope, elt, attrs ) {
                    // column definition and data context for the row
                    var cDef = scope.col.colDef;
                    var rowData = scope.row.entity.entityDC; // DATACONTEXT
                    if( !rowData ) { // TODO  how frequent is this??
                        console.log( 'Warning - gridImage link function, no entityDC' );
                    }

                    var content = '<p>no callback</p>'; // debug TODO
                    if( cDef && cDef.awapi && cDef.awapi.getCellTemplate ) {
                        content = cDef.awapi.getCellTemplate( cDef.name, rowData.uid );
                    }

                    elt.html( content ); // set the inner HTML content
                }
            };
        } );

        app.directive( 'awGridName', function() {
            return {
                restrict: "E",
                link: function( scope, elt, attrs ) {
                    // column definition and data context for the row
                    var cDef = scope.col.colDef;
                    var rowData = scope.row.entity.entityDC; // DATACONTEXT
                    if( !rowData ) { // TODO  how frequent is this??
                        console.log( 'Warning - awGridName link function, no entityDC' );
                    }

                    var content = '<p>no callback</p>'; // debug TODO
                    if( cDef && cDef.awapi && cDef.awapi.getCellTemplate ) {
                        //                        console.log('request grid name: '+rowData.uid);
                        content = cDef.awapi.getCellTemplate( cDef.name, rowData.uid );
                        //                        console.log('content: '+content);
                    }

                    elt.html( content ); // set the inner HTML content
                }
            };
        } );

        /**
         * Initialize ('bootstrap') the angular system and create an angular controller on a new 'child' of the given
         * 'parent' element.
         *
         * @param {Element}
         *            parentElement - The DOM element the controller and 'inner' HTML content will be added to.
         *            <P>
         *            Note: All existing 'child' elements of this 'parent' will be removed.
         *
         * @param {Object}
         *            containerVM - The View Model for this container
         *            <P>
         *            Note: This object will have the 'rootScopeElement' property set on this object with the new
         *            AngularJS Element created to hold the compiled given 'innerHtml' and attached as a child to the
         *            given 'parentElement'.
         */
        exports.insertGrid = function( parentElement, containerVM ) {

            // allow for fixed or variable row height support - set a different css class.
            var gridContainerClass = 'aw-jswidgets-grid';
            if( containerVM.tableSettings && containerVM.tableSettings.allowVariableRowHeight ) {
                // not yet supported...
                gridContainerClass = 'aw-jswidgets-grid-mixRow';
            }

            var ctrlElement = ngModule.element( '<div class="' + gridContainerClass + '" ng-controller="awTableController"/>' );

            var inner = '<div id="grid" ui-grid="gridOptions1" ui-grid-auto-resize ui-grid-selection ui-grid-resize-columns ui-grid-move-columns ui-grid-infinite-scroll />';
            ctrlElement.html( inner );

            $( parentElement ).empty();
            $( parentElement ).append( ctrlElement );

            var ctrlFn = awInclude( parentElement, ctrlElement );
            if( ctrlFn ) {
                ctrlFn.setContainerVM( containerVM );
            }
        };

        // utility function to get the scope (if set) on the controller under the parent element.
        var getScopeForParent = function( parentElement ) {
            var scope = null;

            // assumes that the first child of parent is the controller element
            if( parentElement && parentElement.firstChild ) {
                scope = ngModule.element( parentElement.firstChild ).scope();
            }

            return scope;
        };

        exports.forceRefresh = function( parentElement, containerVM ) {
//            console.log( 'exports.forceRefresh' );
            var ngScope = getScopeForParent( parentElement );
            if( ngScope && !ngScope.$$destroyed ) {
//                console.log( 'module forceRefresh' );
                ngScope.refreshData( containerVM );

                ngScope.$evalAsync( function() {
//                    console.log( 'trigger digest?' );
                } );
            }
        };

        exports.setDataAdapter = function( parentElement, containerVM ) {
//            console.log( 'exports.setDataProvider' );
            var ngScope = getScopeForParent( parentElement );
            if( ngScope && !ngScope.$$destroyed ) {
//                console.log( 'module setDataAdapter' );
                ngScope.setDataAdapter( containerVM );
            }
        };

        /**
         * Forcing digest cycle
         *
         * @param {Element}
         *            parentElement - The element above the element the controller was created on.
         */
        exports.forceDigestCycle = function( parentElement ) {
//            console.log( 'calling forceDigestCycle wrapper JS' );

            var ngScope = getScopeForParent( parentElement );
            if( ngScope && !ngScope.$$destroyed ) {
//                console.log( 'force digest evalAsync' );
                ngScope.$evalAsync();
            }
        };

        /**
         * export function to trigger update of the columns ?
         */
        exports.forceUpdateColumnDefs = function( parentElement, containerVM ) {
            var ngScope = getScopeForParent( parentElement );
            if( ngScope && !ngScope.$$destroyed ) {
//                console.log( 'module updateColumnDefs' );
                ngScope.updateColumnDefs( containerVM );
            }
        };

        /**
         * export function to reconcile selection set
         */
        exports.reconcileApplicationSelectionSet = function( parentElement, selectedSet ) {
            var ngScope = getScopeForParent( parentElement );
            if( ngScope && !ngScope.$$destroyed ) {
//                console.log( 'module reconcileApplicationSelectionSet' );
                ngScope.reconcileApplicationSelectionSet( selectedSet );
            }
        };

        /**
         * native JS implementation for the table View Model. This pulls together all the interacting
         * pieces and settings that drive the table behavior. It generally delegates to other data structures
         * but this becomes the focal point for all ui grid based table interactions.
         *
         * There is GWT wrapper available to access this from GWT.
         */
        var UITableViewModel = function() {
            var self = this;

            self.whatamI = "UITableVM"; // debug aid

            // members
            self.fields = [ {
                name: 'object_name',
                displayName: 'name'
            } ]; // default initialization
            self.editable = false; // default to non-edit
            self.uiDataAdapter = {}; // will get initialized later

            // sub structure/ references
            self.api = {};
            self.events = {};
            self.tableSettings = undefined; // configuration and settings values

            // operations
            self.getAPIObject = function() {
                return self.api;
            };

            self.getEventAPIObject = function() {
                return self.events;
            };

            // TODO - from UIGridVMOverlay???
            // setFieldInfo()
            // removeFocusOnRefresh()

            self.api.getImageForId = function( id ) {
                return "";
            };

            /**
             * row selection change handler.
             */
            self.events.onRowSelectionChange = function( dc, selected ) {
                var id = dc.uid;
                console.log( ' UITableVM onRowSelChg ' + id );
                self.events.handleSingleSelection( id, selected );
            };

            self.events.onColumnSizeChange = function( name, deltaChange, currentSize ) {
                var msg = 'UITableVM col size chg: ' + name + " chg: " + deltaChange + '  size: ' + currentSize;
                console.log( msg );
            };

            self.events.onRMB = function( positionX, positionY ) {
                var msg = 'UITableVM RMB event in UIGridVMOverlay: ' + positionX + positionY;
                console.log( msg );
            };

            self.events.handleSingleSelection = function( id, selectionState ) {
                console.log( ' UITableVM handleSingleSelection ' + id );
            };
        };

        /**
         * angular factory registration
         */
        app.factory( 'UITableViewModelService', function() {
            return new UITableViewModel();
        } );

        exports.getUITableViewModel = function() {
            return new UITableViewModel();
        };

        // using JSO for now
        //        /**
        //         * native JS implementation for the table settings.  This will be all the various
        //         * configuration switches and settings - aggregated into a single object.   May support inheritance/extension
        //         * in the future.    Pass as a single aggregate to avoid fine grained api interaction.
        //         *
        //         * Use these settings to configure the uiGrid table settings.
        //         *
        //         * This needs to be an Observable.
        //         *
        //         * There is GWT wrapper available to access this from GWT.
        //         */
        //        var UITableSettings = function() {
        //            var self = this;
        //
        //            self.whatamI = "UITableSettings"; // debug aid
        //
        //            // members
        //            self.allowEdits = false;
        //            self.selectionOption = "none"; // Enum (none, single, multi)
        //            self.allowFieldReorder = false; // should table allow column order change
        //            self.allowColumnResize = true;
        //            self.allowFieldPinning = false;
        //        };
        //
        //        /**
        //         * angular factory registration
        //         */
        //        app.factory( 'UITableSettingsService', function() {
        //            return new UITableSettings();
        //        } );
        //
        //        exports.getUITableSettings = function() {
        //            return new UITableSettings();
        //        };
        //

        exports.getDataAdapter = function() {
//            console.log( 'in TableJS  dataProviderModule getDataAdapter' );
            return dataProviderModule.getDataAdapter();
        };

        exports.getPagingDataProvider = function() {
//            console.log( 'in TableJS  dataProviderModule getNativePagingDataProvider' );
            return dataProviderModule.getNativePagingDataProvider();
        };

        exports.getFixedDataProvider = function() {
//            console.log( 'in TableJS  dataProviderModule getFixedDataProvider' );
            return dataProviderModule.getFixedDataProvider();
        };

        return exports;
    } ); // End RequireJS Define
