//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 clearTimeout,
 define,
 setTimeout,
 window
 */

/**
 * @module js/NgPropertyLov
 */
define( [ 'app', 'angular', 'jquery', 'js/NgUtil' ], function( app, ngModule, $ ) {
    // Begin RequireJS Define
    'use strict';

    var exports = {};

    /**
     * @constructor LOVDataService
     */
    var LOVDataService = function( $q ) {
        var self = this;

        /**
         * Returns an AngularJS promise to fetch the initial LOV values.
         *
         * @memberof module:js/NgPropertyLov~LOVDataService
         *
         * @param {LOVCallbackAPI} lovApi - Reference to the LOV Callback API to use.
         *
         * @param {String} filterStr - Filter to apply to the results before being returned.
         *
         * @param {String} name - Name of the property we are requesting LOV entries for.
         *
         * @returns {Promise}
         */
        self.promiseInitialValues = function( lovApi, filterStr, name ) {
            var deferred = $q.defer();
            // make server call via lov data provider interface
            lovApi.getInitialValues( filterStr, deferred, name );
            return deferred.promise;
        };

        /**
         * Returns an AngularJS promise to fetch the 'next' set of LOV values.
         *
         * @memberof module:js/NgPropertyLov~LOVDataService
         *
         * @param {LOVCallbackAPI} lovApi - Reference to the LOV Callback API to use.
         *
         * @param {String} name - Name of the property we are requesting LOV entries for.
         *
         * @returns {Promise}
         */
        self.promiseNextValues = function( lovApi, name ) {
            var deferred = $q.defer();
            // make server call via lov data provider interface
            lovApi.getNextValues( deferred, name );
            return deferred.promise;
        };

        /**
         * Validate the given LOV entry value(s).
         *
         * @memberof module:js/NgPropertyLov~LOVDataService
         *
         * @param {LOVCallbackAPI} lovApi - Reference to the LOV Callback API to use.
         *
         * @param {LovEntryArray} lovEntries
         *
         * @param {String} name - Name of the property we are requesting LOV entries for.
         *
         * @returns {Void}
         */
        self.validateLOVValueSelections = function( lovApi, lovEntries, name ) {
            // make server call via lov data provider interface
            lovApi.validateLOVValueSelections( lovEntries, name );
        };
    };

    /**
     * Registers an instance of the {@linkcode module:js/NgPropertyLov~LOVDataService|LOVDataService} with the the
     * application module's factory.
     *
     * @member LOVDataService
     * @memberof NgServices
     *
     * @param $q
     *
     * @returns {Void}
     */
    app.factory( 'LOVDataService', [ '$q', function( $q ) {
        return new LOVDataService( $q );
    } ] );

    /**
     * Using controller for prop update currently, but consider passing an update f(x) from the parent controller using &
     *
     * @constructor awPropertyLovController
     * @memberof NgControllers
     */
    app.controller( 'awPropertyLovController', [
        '$scope',
        '$element',
        '$q',
        '$filter',
        'LOVDataService',
        'localeService',
        'dateTimeService',
        'ListService',
        'ValidationService',
        'UtilsService',
        function( $scope, $element, $q, $filter, lovDataSvc, localeSvc, dateTimeSvc, ListService, ValidationService, UtilsService ) {
            var uiProperty = $scope.prop;

            uiProperty.uiOriginalValue = uiProperty.uiValue;
            uiProperty.dbOriginalValue = uiProperty.dbValue;

            var prevDbValue = uiProperty.dbOriginalValue;

            $scope.lovEntries = [];
            $scope.expanded = false;
            $scope.moreValuesExist = true;
            $scope.lovInitialized = false;

            /**
             * TRUE if we are NOT waiting for any values to be returned by the server.
             *
             * @memberof NgControllers.awPropertyLovController
             * @private
             */
            $scope.queueIdle = true;

            $scope.dropPosition = 'below';

            var idleTimer = null;

            $scope.myCtrl = this;
            $scope.myCtrl.$parent = $element;
            $scope.dropDownVerticalAdj = 0;
            $scope.listFilterText = '';

            /**
             * Toggle the expand/collapse state of the lov list.
             * <P>
             * Note: Called by (aw-property-lov-val) directive template to delegate an 'ng-click' on the text box
             * itself.
             *
             * @memberof NgControllers.awPropertyLovController
             */
            $scope.toggleDropdown = function() {
                if( $scope.expanded ) {
                    // alternatively, we could just collapse here and handle the rest of the
                    // exit (like validation, etc) onBlur. For now, doing it here...
                    $scope.handleFieldExit();
                } else {
                    /**
                     * For now, do this regardless of whether we already have value data - this is necessary to deal
                     * with interdep lovEntries.
                     * <P>
                     * In the future, we can improve this for efficiency with something like: if (
                     * $scope.moreValuesExist && !$scope.lovInitialized )
                     */
                    $scope.requestInitialLovEntries();
                    ListService.expandList( $scope, $element );
                }
                //Necessary for IOS to allow toggling after intial opening.
                $element.find( '.aw-jswidgets-choice' ).off('touchstart');
                $element.find( '.aw-jswidgets-choice' ).on('touchstart', function (e) { $scope.toggleDropdown(e); });
            };

            /**
             * Bound via 'ng-change' on the 'input' element and called on input change - filter typing
             *
             * @memberof NgControllers.awPropertyLovController
             */
            $scope.changeFunction = function() {
                /**
                 * Before setting the dbValue, maybe we should look for a 'propDisplayValue' match in the lovEntries and
                 * use that internal value. Probably not just for Date though...
                 */
                if( uiProperty.type === 'DATE' || uiProperty.type === 'DATEARRAY' ) {
                    for( var ndx = 0; ndx < $scope.lovEntries.length; ndx++ ) {
                        if( $scope.lovEntries[ndx].propDisplayValue === uiProperty.uiValue ) {
                            uiProperty.dbValue = $scope.lovEntries[ndx].propInternalValue;
                            break;
                        }
                    }
                } else if( uiProperty.type === 'OBJECT' || uiProperty.type === 'OBJECTARRAY' ) {
                    // we can't set the dbValue for an object based on filter text, but we can check to see if the
                    // input
                    // has been cleared
                    if( !uiProperty.uiValue ) {
                        uiProperty.dbValue = '';
                    }
                } else {
                    uiProperty.dbValue = uiProperty.uiValue;
                }

                if( !uiProperty.isArray ) {
                    uiProperty.uiValues = [ uiProperty.uiValue ];
                    uiProperty.dbValues = [ uiProperty.dbValue ];
                }

                $scope.listFilterText = uiProperty.uiValue;

                // request the results and open the drop-down
                $scope.requestFilteredLovEntries();
                ListService.expandList( $scope, $element );
            };

            /**
             * Evaluate a key press in the input
             *
             * @memberof NgControllers.awPropertyLovController
             *
             * @param {Object} event - Keyboard event to evaluate.
             */
            $scope.evalKey = function( event ) {
                ListService.evalKey( $scope, event, $element );
            };

            /**
             * Called by the ListService when user escapes out of an LOV choice field. Actions is to revert value.
             *
             * @memberof NgControllers.awPropertyLovController
             */
            $scope.handleFieldEscape = function() {
                var uiProperty = $scope.prop;

                uiProperty.dbValue = uiProperty.dbOriginalValue;
                uiProperty.uiValue = uiProperty.uiOriginalValue;
            };

            /**
             * Retrieves lov entry based off filter text.
             *
             * @memberof NgControllers.awPropertyLovController
             *
             * @returns {LOVEntry} lov entry object created based off the filter text.
             */
            $scope.retrieveLovEntryWithFilterText = function() {
                var chosenLovEntry;
                var uiProperty = $scope.prop;
                if( uiProperty ) {
                    if( uiProperty.type === "DATE" ) {
                        var dbValue = dateTimeSvc.getJSDate( uiProperty.dbValue );

                        chosenLovEntry = {
                            propInternalValue: dbValue,
                            propDisplayValue: dateTimeSvc.formatSessionDateTime( dbValue )
                        };
                    } else {
                        chosenLovEntry = {
                            propInternalValue: uiProperty.dbValue,
                            propDisplayValue: uiProperty.uiValue
                        };

                        /**
                         * For static lov's if user enters the correct value but doesn't select it from list of values,
                         * then compare the user entered 'internalValue' with 'internalValue' of lov entries list and
                         * if it matches send lov entry object from lov entries list.
                         */
                        if( uiProperty.lovApi.type === 'static' ) {
                            for( var i = 0; i < $scope.lovEntries.length; i++ ) {
                                if( $scope.lovEntries[ i ].propInternalValue === chosenLovEntry.propInternalValue ) {
                                    chosenLovEntry = $scope.lovEntries[ i ];
                                    break;
                                }
                            }
                        }
                    }
                }

                return chosenLovEntry;
            };

            /**
             * Called by the ListService when exiting an LOV choice field.
             *
             * @memberof NgControllers.awPropertyLovController
             *
             * @param {Number} attnIndex - Index in the LOV selected by the user (or 'null' if user has cleared the
             *            field.
             */
            $scope.handleFieldExit = function( $event, attnIndex, skipFocusElem ) {
                var chosenLovEntry;

                if( app._.isNumber( attnIndex ) && attnIndex >= 0 ) {
                    chosenLovEntry = $scope.lovEntries[attnIndex];
                } else {
                    // attempt to set the filter text as the new value
                    chosenLovEntry = $scope.retrieveLovEntryWithFilterText();
                }

                $scope.setLovEntry( chosenLovEntry, $event, skipFocusElem );
            };

            /**
             * Called to update the dbValue based on uiValue and data type.
             *
             * @memberof NgControllers.awPropertyLovController
             *
             * @param {LOVEntry} lovEntry - The LOVEntry object containing the values to set the scope property's 'ui'
             *            and 'db' values based upon.
             */
            $scope.updateDbValue = function( lovEntry ) {
                // Initially the 'prevDbValue' is empty, avoid applying 'ng-dirty' class.
                var changed = ( prevDbValue !== lovEntry.propInternalValue );

                // update the dbValue based on the uiValue
                if( uiProperty.type === "DATE" ) {
                    if( dateTimeSvc.isNullDate( lovEntry.propInternalValue ) ) {
                        uiProperty.dbValue = '';
                        uiProperty.uiValue = '';
                    } else {
                        uiProperty.dbValue = dateTimeSvc.getJSDate( lovEntry.propInternalValue );
                        uiProperty.uiValue = dateTimeSvc.formatSessionDateTime( uiProperty.dbValue );
                    }
                } else {
                    uiProperty.dbValue = lovEntry.propInternalValue;
                    uiProperty.uiValue = lovEntry.propDisplayValue;
                }

                /**
                 * For integer and double we have to actually see if it is valid number and then convert it into number
                 * type accordingly or else throw an error
                 */
                if( uiProperty.type === "INTEGER" || uiProperty.type === "DOUBLE" ||
                        uiProperty.type === "INTEGERARRAY" || uiProperty.type === "DOUBLEARRAY" ) {
                    var newDbValue;
                    if( uiProperty.type === "INTEGER" || uiProperty.type === "INTEGERARRAY" ) {
                        newDbValue = ValidationService.checkInteger( $scope, null, lovEntry.propInternalValue );
                    } else {
                        newDbValue = ValidationService.checkDouble( $scope, null, lovEntry.propInternalValue );
                    }
                    // set the converted number to the dbValue
                    uiProperty.dbValue = lovEntry.propInternalValue = newDbValue;
                } else if( uiProperty.type === "DATE" || uiProperty.type === "DATEARRAY" ) {
                    var dateObject;

                    if( !lovEntry.propInternalValue ) {
                        dateObject = dateTimeSvc.getNullDate();
                    } else {
                        dateObject = dateTimeSvc.getJSDate( lovEntry.propInternalValue );
                        dateObject = ValidationService.checkDateTime( $scope, dateObject );
                    }

                    changed = dateTimeSvc.compare( prevDbValue, dateObject ) !== 0;

                    if( changed ) {
                        if( dateTimeSvc.isNullDate( dateObject ) ) {
                            uiProperty.dbValue = '';
                            uiProperty.uiValue = '';
                        } else {
                            uiProperty.dbValue = dateObject;
                            uiProperty.uiValue = dateTimeSvc.formatSessionDateTime( dateObject );
                        }
                    }
                }
            };

            /**
             * Bound via 'ng-blur' on the 'input' element and called on input 'blur' (i.e. they leave the field)
             *
             * @memberof NgControllers.awPropertyLovController
             * @param {Object} $event - DOM event
             */
            $scope.blurLovFunction = function( $event ) {
                var lovEntry;
                // attempt to set the filter text as the new value
                var uiProperty = $scope.prop;
                lovEntry = $scope.retrieveLovEntryWithFilterText();

                // Initially the 'prevDbValue' is empty, avoid applying 'ng-dirty' class.
                var changed = ( prevDbValue !== lovEntry.propInternalValue );
                $scope.updateDbValue( lovEntry );

                if( changed && !uiProperty.isArray ) {
                    app.vmPropSvc.updateViewModelProperty( uiProperty );
                }
            };

            /**
             * Called to set a new prop value via a pick or explicit set from tab, enter, or blur
             *
             * @memberof NgControllers.awPropertyLovController
             *
             * @param {LOVEntry} lovEntry - The LOVEntry object containing the values to set the scope property's 'ui'
             *            and 'db' values based upon.
             * @param {Object} $event - DOM event
             * @param {Boolean} skipFocusElem - (Optional) TRUE if we DO NOT want to focus the element after setting the
             *            LOV value.
             */
            $scope.setLovEntry = function( lovEntry, $event, skipFocusElem ) {
                ListService.collapseList( $scope );

                // Initially the 'prevDbValue' is empty, avoid applying 'ng-dirty' class.
                var changed = ( prevDbValue !== lovEntry.propInternalValue );
                $scope.listFilterText = '';
                $scope.updateDbValue( lovEntry );

                var $choiceElem = $element.find( '.aw-jswidgets-choice' );
                var $inputElem = $event;

                /**
                 * Event object is undefined when body 'click' event is fired.
                 * Set choice element to input element.
                 */
                if( !UtilsService.ifElementExists( $event ) ) {
                    $inputElem = $choiceElem;
                }

                if( changed ) {
                    /**
                     * By default we set the first element (i.e. index = 0) for listbox widget, which also adds dirty flag.
                     * we need to ignore it by checking whether there is a index property or index is not equal to zero.
                     * Note: Index property is not defined for dynamic lovs.
                     */
                    if( !lovEntry.hasOwnProperty( 'index' ) || lovEntry.index !== 0 ) {
                        /**
                         * Instead of relying on AbstractUICell's getEditedUIObjects(), we are tracking ourselves. Possibly
                         * could set "dirty" via $setViewValue() instead.
                         */
                        $choiceElem.addClass( 'ng-dirty' );
                    }

                    /**
                     * Update the view model with the values set just above.
                     */
                    if( !uiProperty.isArray ) {
                        app.vmPropSvc.updateViewModelProperty( uiProperty );
                    } else {
                        uiProperty.updateArray( $inputElem );
                    }

                    /**
                     * Check if the above validation step found no issues.<BR>
                     * If so: Send the selection to the server for its validation.
                     * If the server validation error flag is true that means server has returned an error to property
                     * So, call server again to clear the flag.
                     */
                    if( !uiProperty.error || uiProperty.hasServerValidationError ) {
                        // defer validation on array lovs since value isn't set until added to the array
                        lovDataSvc.validateLOVValueSelections( uiProperty.lovApi, [ lovEntry ], uiProperty.propertyName );
                    }

                    prevDbValue = uiProperty.dbValue;
                } else {
                    if( uiProperty.isArray ) {
                        uiProperty.updateArray( $inputElem, true );
                    }
                }

                /**
                 * Always leave the <input> node as the keyboard focus .
                 */
                if( !skipFocusElem ) {
                    $choiceElem.focus();
                }
            };

            /**
             * Do we have any values for the lov?
             *
             * @memberof NgControllers.awPropertyLovController
             *
             * @returns {Boolean} TRUE if the current LOV is NOT empty.
             */
            $scope.hasValues = function() {
                if( $scope.queueIdle ) {
                    if( $scope.lovEntries.length === 0 ||
                        ( $scope.lovEntries.length === 1 && $scope.lovEntries[0].isEmptyEntry ) ) {
                        return false;
                    }
                }

                return true;
            };

            /**
             * Get the initial values.
             *
             * @memberof NgControllers.awPropertyLovController
             */
            $scope.requestInitialLovEntries = function() {
                $scope.$evalAsync( function() {
                    $scope.lovEntries = [];
                    $scope.moreValuesExist = true;
                    $scope.queueIdle = false;
                    $scope.lovInitialized = true;
                } );

                lovDataSvc.promiseInitialValues( $scope.prop.lovApi, $scope.listFilterText, $scope.prop.propertyName ).then(
                    $scope.processInitialLovEntries, $scope.processError );
            };

            /**
             * @memberof NgControllers.awPropertyLovController
             */
            $scope.requestFilteredLovEntries = function() {
                // wait for a 300ms pause before submitting...
                clearTimeout( idleTimer );
                idleTimer = setTimeout( function() {
                    $scope.requestInitialLovEntries();
                }, 300 );
            };

            /**
             * Get the next set of vals (bound to 'aw-when-scrolled' attribute directive).
             *
             * @memberof NgControllers.awPropertyLovController
             */
            $scope.requestNextLovEntries = function() {
                /**
                 * This can get called from multiple places.... which would be fine except that the fx implementation
                 * will return duplicate values on sequential requests... therefore, throttle the requests here...
                 */
                if( $scope.lovInitialized && $scope.moreValuesExist && $scope.queueIdle ) {
                    $scope.$evalAsync( function() {
                        $scope.queueIdle = false;
                    } );

                    lovDataSvc.promiseNextValues( $scope.prop.lovApi, $scope.prop.propertyName ).then(
                        $scope.processLovEntries, $scope.processError );
                }
            };

            /**
             * Move the LOV information from the values returned from the SOA request into the property's local LOV
             * entry array.
             *
             * @memberof NgControllers.awPropertyLovController
             *
             * @param {ObjectArray} lovEntries - Array of LOV Entry objects returned from the SOA service.
             */
            $scope.processInitialLovEntries = function( lovEntries ) {
                // clear lovEntries to avoid racing filter results...
                $scope.lovEntries = [];
                $scope.processLovEntries( lovEntries );
            };

            /**
             * @memberof NgControllers.awPropertyLovController
             *
             * @param {ObjectArray} lovEntries - Array of LOV Entry objects returned from the SOA service.
             */
            $scope.processLovEntries = function( lovEntries ) {
                $scope.queueIdle = true;

                if( lovEntries && lovEntries.length === 0 ) {
                    // we have all the vals now...
                    $scope.moreValuesExist = false;
                }

                var firstSet = true;

                if( $scope.lovEntries.length ) {
                    firstSet = false;
                }

                // for static type do client side filtering
                var lovEntriesFinal = lovEntries;

                if( $scope.prop.lovApi.type === 'static' ) {
                    lovEntriesFinal = $filter( 'filter' )( lovEntriesFinal, $scope.listFilterText );
                }

                /**
                 * Add an 'empty' entry as the 1st entry in the list to allow the user the ability to un-set a property.
                 * <P>
                 * Note: If there are no entries after any filtering, then there is no need for the empty entry.
                 */
                var firstNonEmpty = 0;

                if( firstSet && lovEntriesFinal.length > 0 ) {
                    var lovEntryEmpty = {
                        propDisplayValue: '',
                        propInternalValue: null,
                        sel: false,
                        attn: false,
                        isEmptyEntry: true
                    };

                    $scope.lovEntries.push( lovEntryEmpty );

                    firstNonEmpty = 1;
                }

                ngModule.forEach( lovEntriesFinal, function( lovEntry ) {
                    // resetting selected flag to false for static type
                    if( $scope.prop.lovApi.type === 'static' ) {
                        lovEntry.sel = false;
                        lovEntry.attn = false;
                    }

                    // append new value to model
                    var lovDbValue = lovEntry.propInternalValue;

                    if( uiProperty.type === "DATE" ) {
                        lovDbValue = dateTimeSvc.getJSDate( lovEntry.propInternalValue );
                        lovEntry.propDisplayValue = dateTimeSvc.formatSessionDateTime( lovDbValue );

                        var result = dateTimeSvc.compare( uiProperty.dbValue, lovDbValue );

                        if( result === 0 ) {
                            lovEntry.sel = true;
                            lovEntry.attn = true;
                            lovEntriesFinal[0].attn = false;
                        }

                        // ********
                        // ********
                        // Note: Use coercive compare to support cases comparing a number to a string
                        // ******** Do not clean up lint warning.
                        // ********
                    } else if( uiProperty.dbValue == lovDbValue ) { // jshint ignore:line
                        lovEntry.sel = true;
                        lovEntry.attn = true;
                        lovEntriesFinal[0].attn = false;
                    }

                    if( $scope.lovEntries.length === firstNonEmpty && $scope.listFilterText ) {
                        // focus attention on first value if we've done any filtering
                        lovEntry.attn = true;
                    }

                    $scope.lovEntries.push( lovEntry );
                } );

                /**
                 * If this is the first set of values (not appending to an existing set), autoscroll to the selected or
                 * attention value.
                 */
                if( firstSet ) {
                    ListService.scrollAttention( $scope, $element );

                    /**
                     * For static lovs (i.e. listBox) remove the first value from the list
                     * which is an empty lov entry.
                     */
                    if( $scope.prop.lovApi.type === 'static' && $scope.lovEntries.length ) {
                        $scope.lovEntries.shift();
                    }
                }
            };

            /**
             * Call this if there is an error calling our service
             *
             * @memberof NgControllers.awPropertyLovController
             *
             * @param {String} reason -
             */
            $scope.processError = function( reason ) {
                // placeholder function. do nothing; error should already be handled.
                console.log( 'error: ' + reason );
            };

            /**
             *
             * @memberof NgControllers.awPropertyLovController
             *
             * @param {Object} lovEntry - The LOVEntry object containing the values to set the scope property's 'ui' and
             *            'db' values based upon.
             */
            $scope.setSelectedLOV = function( lovEntry ) {
                /**
                 * Set skipFocusElem flag to true so that it doesn't focus on listBox during setting the default value
                 * programmatically.
                 */
                $scope.setLovEntry( lovEntry, null, true );

                // set uiOriginalValue and dbOriginalValue for static lov widget if they are null/empty,
                // which is used by escape key for reverting value.
                if( !uiProperty.uiOriginalValue && !uiProperty.dbOriginalValue ) {
                    uiProperty.uiOriginalValue = lovEntry.propDisplayValue;
                    uiProperty.dbOriginalValue = lovEntry.propInternalValue;
                }

                // set prevDbValue for static lov widget if it is null/empty,
                if( !prevDbValue ) {
                    prevDbValue = lovEntry.propInternalValue;
                }
            };

            /**
             * @memberof NgControllers.awPropertyLovController
             */
            $scope.$on( '$destroy', function() {
                /**
                 * *** Important Debug Output *** Please keep this block (even if it's commented out)
                 */
                if( app.isDebugEnabled ) {
                    console.log( 'awPropertyLovController: Destroy $scope=' + $scope.$id );
                }

                if( $scope.$scrollPanel ) {
                    $scope.$scrollPanel.off( 'scroll.lov' );
                    $scope.$scrollPanel = null;
                }

                if( $scope.listener ) {
                    $scope.listener();
                }

                /**
                 * Remove any references to DOM elements (or other non-trivial objects) from this scope. The purpose is
                 * to help the garbage collector do its job.
                 */
                if( $scope.myCtrl ) {
                    $scope.myCtrl.$parent = null;
                    $scope.myCtrl = null;
                }

                $scope.lovEntries = null;
                $scope.prop = null;
            } );
        } ] );

    /**
     * Attribute directive to drive loading more values on scroll.
     *
     * @member aw-when-scrolled
     * @memberof NgAttributeDirectives
     *
     * @returns {Object}
     */
    app.directive( 'awWhenScrolled', function() {
        return {
            restrict: "A",
            link: function( scope, $element, attrs ) {
                var raw = $element[0];
                $element.on( 'scroll.lov', function() {
                    if( raw.scrollTop + raw.offsetHeight >= raw.scrollHeight ) {
                        scope.$evalAsync( attrs.awWhenScrolled );
                    }
                } );
            }
        };
    } );

    /**
     * @member aw-property-lov-val
     * @memberof NgElementDirectives
     *
     * @param $injector
     * @param localeSvc
     * @param dateTimeSvc
     *
     * @returns {Object}
     */
    app.directive( 'awPropertyLovVal', [ '$injector', 'localeService', 'dateTimeService',
        function( $injector, localeSvc, dateTimeSvc ) {
            return {
                restrict: 'E',
                scope: {
                    // prop comes from the parent controller's scope
                    prop: '='
                },
                controller: 'awPropertyLovController',
                link: function( scope, $element, attrs, lovCtrl ) {
                    /**
                     * Set nativeApi only when native 'lovService' is available (which indicates we are NOT in GWT/AW)
                     */
                    if( $injector.has( 'lovService' ) ) {
                        $injector.get( 'lovService' ).initNativeCellLovApi( scope.prop, scope );
                    }

                    localeSvc.getTextPromise().then( function( localizedText ) {
                        scope.prop.lovNoValsText = localizedText.NO_LOV_VALUES;
                    } );
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwLovVal.html'
            };
        } ] );

    /**
     * Controller for {@link NgElementDirectives.aw-property-lov-child} directive.
     *
     * @constructor awPropertyLovChildController
     * @memberof NgControllers
     *
     * @param $scope
     */
    app.controller( 'awPropertyLovChildController', [ '$scope', 'ListService', function( $scope, ListService ) {
        // lov data will be held here
        $scope.expanded = false;

        /**
         * Toggle lov expansion state on hlovs
         *
         * @memberof NgControllers.awPropertyLovChildController
         *
         * @param {Object} ev -
         *
         * @param {Object} parentLovEntry -
         */
        $scope.toggleChildren = function( ev, parentLovEntry ) {
            ev.stopPropagation();
            parentLovEntry.expanded = typeof parentLovEntry.expanded === 'undefined' ? true : !parentLovEntry.expanded;
            if( parentLovEntry.expanded ) {
                parentLovEntry.indicator = 'expanded';
                // if first click, also fetch initial vals
                if( typeof parentLovEntry.children === 'undefined' ) {
                    parentLovEntry.children = parentLovEntry.getChildren();
                }
            } else {
                parentLovEntry.indicator = '';
            }
        };

        /**
         * @memberof NgControllers.awPropertyLovChildController
         *
         * @param {Object} lovEntry -
         */
        $scope.setLovEntry = function( lovEntry, $event ) {
            $( 'body' ).off( 'click touchstart', ListService.exitFieldHandler );

            var element = $($event.currentTarget).closest('.aw-jswidgets-lovParentContainer').find( '.aw-jswidgets-choice' );
            $scope.$parent.setLovEntry( lovEntry, element );
        };

        /**
         * *** Important Debug Output *** Please keep this block (even if it's commented out)
         */
        if( app.isDebugEnabled ) {
            $scope.$on( '$destroy', function() {
                console.log( 'awPropertyLovChildController: Destroy $scope=' + $scope.$id );
            } );
        }
    } ] );

    /**
     * @member aw-property-lov-child
     * @memberof NgElementDirectives
     *
     * @param $compile
     *
     * @returns {Void}
     */
    app.directive( 'awPropertyLovChild', [ '$compile', function( $compile ) {
        return {
            restrict: 'E',
            scope: {
                // prop comes from the parent controller's scope
                lovEntry: '='
            },
            controller: 'awPropertyLovChildController',
            link: function( scope, $element ) {
                // if the child value has children of its own, insert dynamically to
                // avoid recursion in the template
                if( scope.lovEntry.hasChildren ) {
                    var lovChildrenHtml = ngModule.element( '<ul ng-show="lovEntry.expanded">' + //
                    '<li class="aw-jswidgets-nestingListItem" ng-repeat="child in lovEntry.children">' + //
                    '<aw-property-lov-child lov-entry="child"/></li></ul>' );
                    $element.append( lovChildrenHtml );
                    $compile( lovChildrenHtml )( scope );
                }
            },
            templateUrl: app.getBaseUrlPath() + '/html/NgAwLovChild.html'
        };
    } ] );

    /**
     * This method will set selected LOV entry
     *
     * @param {Element} parentElement - The DOM element to retrieve scope.
     * @param {Object} lovEntry - The LOVEntry object containing the values to set the scope property's 'ui' and 'db'
     *            values based upon.
     */
    exports.setSelectedLovEntry = function( parentElement, lovEntry ) {
        if( parentElement ) {
            var ctrlElement = ngModule.element( parentElement.querySelector( '.aw-jswidgets-propertyVal' ) );
            if( ctrlElement ) {
                var ngScope = ngModule.element( ctrlElement ).scope();
                if( ngScope && ngScope.$$childHead ) {
                    ngScope.$$childHead.setSelectedLOV( lovEntry );
                }
            }
        }
    };

    return exports;
} );
