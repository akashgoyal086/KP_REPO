//@<COPYRIGHT>@
//==================================================
//Copyright 2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 window
 */

/**
 * Max Row service is used to calculate the height of array widget based on max row count.
 * This service is only applicable for Array widget.
 *
 * @module js/NgMaxRowService
 */
define( [ 'app', 'jquery' ], function( app, $ ) {
    'use strict';
    /**
     * @constructor MaxRowService
     */
    var MaxRowService = function() {
        var self = this;


        /**
         * @memberof module:js/NgMaxRowService~MaxRowService
         * @private
         *
         * @param {Element} $element - DOM element the controller is attached to.
         *
         * @return {Number} - returns single row height of an array.
         */
        self._calculateRowHeight = function( liElement ) {
            // row height is equal to max(min-height, line-height) + padding.
            // row height is just the height of a single line - can't use element height
            // if an element has multiple lines it takes multiple rows
            var lineHeight = Math.max(
                parseInt( liElement.css( 'line-height' ), 10 ), //line-height css property
                parseInt( liElement.css( 'min-height' ), 10 ) ); //min-height css property

            var rowHeight = lineHeight + parseInt( liElement.css( 'padding-top' ), 10 ) +
                              parseInt( liElement.css( 'padding-bottom' ), 10 );

            return rowHeight;
        };

        /**
         * @memberof module:js/NgListService~ListService
         * @private
         *
         * @param {Element} $element - DOM element the controller is attached to.
         * @param {Number} maxRowCount - maximum row count visible.
         *
         * @return {Number} - returns calculated array height based of max row count.
         */
        self._calculateArrayHeight = function( $element, maxRowCount ) {
            if( $element ) {
                var arrayHeight = 0;
                var nextHeight = 0;

                //Calculate the height of each row individually
                for(var i=1; i<maxRowCount + 1; i++){
                    //Get the next row
                    var liElement = $( $element ).find( 'ul li.aw-jswidgets-arrayValueCellListItem:nth-child('+i+')' );
                    if( liElement && liElement.outerHeight() ) {
                        //if it does not exist reuse the height of the previous element in the list
                        nextHeight = self._calculateRowHeight( liElement );
                    }
                    arrayHeight += nextHeight;
                }
                return arrayHeight;
            }
            return null;
        };

    };

    /**
     * Definition for the MaxRowService service used by (aw-property-array-val) and (aw-property-non-edit-array-val).
     *
     * @member MaxRowService
     * @memberof NgServices
     *
     * @return {Void}
     */
    app.factory( 'MaxRowService', [ function() {
        return new MaxRowService();
    } ] );

    // End RequireJS Define
} );
