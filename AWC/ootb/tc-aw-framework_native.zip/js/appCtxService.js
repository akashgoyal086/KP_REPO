// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */
define( [ 'app', 'angular', 'lodash', 'js/NgProperty', 'js/genericViewModelProperty', 'js/eventBus' ], function( app,
    ngModule, _, ngProperty, _vmPropSvc, eventBus ) {
    'use strict';

    var exports = {
        ctx: {}
    };

    /**
     * registerCtx
     *
     * @param {String} name
     * @param {String} value
     */
    exports.registerCtx = function( name, value ) {
        exports.ctx[name] = value;

        // Announce app context registration
        eventBus.publishSoa( "appCtx.register", {
            "name": name,
            "value": value
        } );
    };
    /**
     * UnregisterCtx
     *
     * @param {String} name
     */
    exports.unRegisterCtx = function( name ) {
        delete exports.ctx[name];
        // Announce app context un-registration
        eventBus.publishSoa( "appCtx.register", {
            "name": name
        } );
    };

    /**
     * getCtx
     *
     * @param {String} path
     */
    exports.getCtx = function( path ) {
        return _.get( exports.ctx, path );
    };

    /**
     * @param {String} uid - UID of the ModelObject to create a ViewModelObject wrapper for.
     *
     * @return {ViewModelObject}
     */
    exports.createViewModelObject = function( modelObject ) {
        return new ViewModelObject( modelObject );
    };

    /**
     * Class used to help view specific state information.
     *
     * @constructor
     *
     * @param {ModelObject} modelObject to create a ViewModelObject for.
     */
    var ViewModelObject = function( modelObject ) {
        var self = this;

        self.uid = modelObject.uid;
        self.type = modelObject.type;
        self.modelType = modelObject.modelType;

        if( self.type ) {
            self.typeIconUrl = "/img/" + self.type.replace( /\s/g, "_" ) + ".png";
            self.thumbnailURL = self.typeIconUrl;
        }
        self.props = {};

        for( var propName in modelObject.props ) {
            if( modelObject.props.hasOwnProperty( propName ) ) {
                var prop = modelObject.props[propName];

                if( prop.propertyDescriptor ) {
                    var type = getClientPropertyType( prop.propertyDescriptor.valueType );
                    var displayName = prop.propertyDescriptor.displayName;
                    var hasLov = prop.propertyDescriptor.lovs && prop.propertyDescriptor.lovs.length > 0;
                    var isArray = prop.propertyDescriptor.anArray;
                    var isAutoAssignable = false;
                    var isEditable = false;
                    var isEnabled = true;
                    var isLocalizable = false;
                    var isNull = false;
                    var isRequired = false;
                    var maxArraySize = -1;
                    var maxLength = prop.propertyDescriptor.maxLength;
                    var isRichText = false;
                    var displayValues = "";
                    var error = "";
                    var renderingHint = "";
                    var numberOfCharacters = -1;
                    var numberOfLines = -1;

                    var uw_dbValue = null;

                    if( prop.dbValues && prop.dbValues.length > 0 ) {
                        if( type === 'DATE' ) {
                            var date = new Date( prop.dbValues[0] );
                            uw_dbValue = date.getTime();
                        } else {
                            uw_dbValue = prop.dbValues[0];
                        }
                    }

                    if( prop.uiValues ) {
                        displayValues = prop.uiValues;
                    } else {
                        displayValues = [];
                    }

                    var viewProp = _vmPropSvc.createViewModelProperty( propName, displayName, type, uw_dbValue,
                        displayValues );
                    _vmPropSvc.setHasLov( viewProp, hasLov );
                    _vmPropSvc.setIsArray( viewProp, isArray );
                    _vmPropSvc.setIsAutoAssignable( viewProp, isAutoAssignable );
                    _vmPropSvc.setIsEditable( viewProp, isEditable );
                    _vmPropSvc.setIsRichText( viewProp, isRichText );
                    _vmPropSvc.setIsEnabled( viewProp, isEnabled );
                    _vmPropSvc.setIsLocalizable( viewProp, isLocalizable );
                    _vmPropSvc.setIsNull( viewProp, isNull );
                    _vmPropSvc.setIsRequired( viewProp, isRequired );
                    _vmPropSvc.setLength( viewProp, maxLength );
                    _vmPropSvc.setError( viewProp, error );
                    _vmPropSvc.setRenderingHint( viewProp, renderingHint );
                    _vmPropSvc.setNumberOfCharacters( viewProp, numberOfCharacters );
                    _vmPropSvc.setNumberOfLines( viewProp, numberOfLines );
                    _vmPropSvc.setArrayLength( viewProp, maxArraySize );

                    if( prop.dbValues ) {
                        viewProp.dbValues = prop.dbValues;
                    } else {
                        viewProp.dbValues = [];
                    }

                    if( prop.uiValues ) {
                        viewProp.uiValues = prop.uiValues;
                    } else {
                        viewProp.uiValues = [];
                    }

                    viewProp.uiValue = viewProp.uiValues.join();

                    viewProp.initialize = false;

                    viewProp.propertyDescriptor = prop.propertyDescriptor;

                    viewProp.parentViewObject = self;

                    self.props[viewProp.name] = viewProp;
                }
            }
        }

        /**
         * return array propertyNameValue objects (property name + real prop values) of the properties that have been
         * modified.
         *
         * @memberof TcModelObject
         *
         * @return {String[]} Array of property names.
         */
        self.getDirtyProps = function() {
            var propertyNameValues = [];

            for( var prop in self.props ) {
                if( self.props.hasOwnProperty( prop ) ) {
                    if( self.props[prop].isDirty() ) {
                        var propNameValue = {};

                        propNameValue.name = prop;
                        propNameValue.values = self.props[prop].dbValues.slice( 0 );
                        propertyNameValues.push( propNameValue );
                    }
                }
            }
            return propertyNameValues;
        };
    };

    /**
     * @private
     *
     * @param {Integer} valueType - The valueType for this property
     *
     * @return {propertyType} propertyType based off the integer value of valueType (String/Double/char etc.)
     */
    var getClientPropertyType = function( valueType ) {
        var propertyType;
        switch( valueType ) {
        case 1:
            propertyType = 'CHAR';
            break;
        case 2:
            propertyType = 'DATE';
            break;
        case 3:
            propertyType = 'DOUBLE';
            break;
        case 4:
            propertyType = 'FLOAT';
            break;
        case 5:
            propertyType = 'INTEGER';
            break;
        case 6:
            propertyType = 'BOOLEAN';
            break;
        case 7:
            propertyType = 'SHORT';
            break;
        case 8:
            propertyType = 'STRING';
            break;
        case 9:
            propertyType = 'OBJECT';
            break;
        default:
            propertyType = 'UNKNOWN';
            break;
        }

        return propertyType;
    };

    /**
     * Register this service with the AngularJS application.
     */
    app.factory( 'appCtxService', [ function() {

        return exports;
    } ] );

    return exports;
} );
