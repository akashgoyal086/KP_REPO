// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/**
 * Note: The purpose of this JS file is to define some namespaces used when building JSDoc structure. These namespaces
 * are used to gather together implementations like 'controllers' and 'directives' that other wise require the code to
 * be available to document.
 */

/**
 * The collection of AngularJS controllers that can be attached to an element and referenced/injected in directives.
 *
 * @namespace NgControllers
 */

/**
 * The collection of AngularJS directives that can be used as an attribute in an element.
 *
 * @namespace NgAttributeDirectives
 */

/**
 * The collection of AngularJS directives that can be used as an element.
 *
 * @namespace NgElementDirectives
 */

/**
 * The collection of AngularJS directives that can be used as an element or an attribute in an element.
 *
 * @namespace NgMixedDirectives
 */

/**
 * The collection of AngularJS services registered with the application module's factory. Instances of service can be
 * access via AngulasJS $inject APIs and patterns.
 *
 * @namespace NgServices
 */
