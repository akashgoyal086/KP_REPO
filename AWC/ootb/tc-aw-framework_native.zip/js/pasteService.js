// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define,
 FormData
 */

/**
 * This service is used to manage the configuration of the paste operation.
 *
 * @module js/pasteService
 */
define( [ 'app', 'assert', 'fs', 'lodash', 'httpWrapper', 'js/logService', 'soa/kernel/soaService' ], function( app,
    assert, fs, _, httpWrapper, logSvc ) {
    'use strict';

    /**
     * Cached reference to 'soa_kernel_soaService'.
     */
    var _soaSvc = null;

    /**
     * Cached reference to '$q' service.
     */
    var _$q = null;

    /**
     * Array of 'dataset' type we wish to automatically skip.
     */
    var _invalidTypeNames = [ 'contents' ];

    /**
     * Cached URL to FMS service
     */
    var _fmsUploadUrl = '';

    /**
     * Cache of the 'pasteConfiguration.json' file. This object represents the union of all module level paste
     * configurations for the current AW application.
     *
     * The JSON object generically is structured as:
     *
     * <pre>
     * {
     *     'targetTypes' : {
     *          '(targetType_X)': {
     *              'sourceTypes': {
     *                  '(sourceType_Y)': {
     *                      'handler': '(pasteHandlerFunction_Z)'
     *                      'relation': '(relation_R)'
     *                      'datasetInfos': {
     *                          'extensions': [ '(extension_F)', '(extension_G)' ],
     *                          'datasetType': '(datsettype_H)',
     *                          'fileFormat': '(fileformat_J)',
     *                          'referenceName': '(namedReferenceName)'
     *                      }
     *                  }
     *                  ...
     *              }
     *          }
     *          ...
     *     }
     * }
     * </pre>
     *
     * Example: The following specifies that:<BR>
     * a) any 'target' of type 'WorkspaceObject' should use the 'defaultObjectPasteHandler' with default relations when
     * items of type 'ItemRevision' or 'DocumentRevision' are pasted on them.
     * <P>
     * b) any 'target' of type 'DocumentRevision' should use the 'defaultFilePasteHandler' specifying the 'TC_Attaches'
     * relations (and other datasetInfo properties) when objects of type 'Dataset' are pasted on them.
     *
     * <pre>
     * {
     *     'targetTypes': {
     *         'WorkspaceObject': {
     *             'sourceTypes': {
     *                 'ItemRevision': {
     *                     'handler': 'defaultFilePasteHandler'
     *                 },
     *                 'DocumentRevision': {
     *                     'handler': 'defaultFilePasteHandler'
     *                 }
     *             }
     *         },
     *         'DocumentRevision': {
     *             'sourceTypes': {
     *                 'Dataset': {
     *                     'handler': 'defaultFilePasteHandler',
     *                     'relation': 'TC_Attaches',
     *                     'datasetInfos': [ {
     *                         'extensions': [ 'jpeg', 'jpg' ],
     *                         'datasetType': 'JPEG',
     *                         'fileFormat': 'BINARY',
     *                         'referenceName': 'JPEG_Reference'
     *                     }, {
     *                         'extensions': [ 'gif', 'svg' ],
     *                         'datasetType': 'Image',
     *                         'fileFormat': 'BINARY',
     *                         'referenceName': 'Image'
     *                     } ]
     *                 }
     *             }
     *         }
     *     }
     * }
     * </pre>
     */
    var _pasteConfig = null;

    /**
     * Get file extension from a file path.
     *
     * @param {String} fileName - file path
     */
    function _getFileExtension( fileName ) {
        var extensionIndex = fileName.lastIndexOf( '.' );

        if( extensionIndex >= 0 ) {
            return fileName.substring( extensionIndex + 1 );
        }

        return ''; //$NON-NLS-1$
    }

    /**
     * @param {String} dataTransferItem - The 'dataTransfer' Item to extract from.
     * @return {String} The type code of the given
     */
    function _getDataTransferType( dataTransferItem ) {
        var extensionIndex = dataTransferItem.lastIndexOf( '/' );

        if( extensionIndex >= 0 ) {
            return dataTransferItem.substring( extensionIndex + 1 );
        }

        return ''; //$NON-NLS-1$
    }

    /**
     * Using the 'pasteConfig' provided by various AW modules, select the 'best fit' for the given 'target' IModelObject
     * based on its actual type (or the type of its nearest ancestor in the type hierarchy).
     *
     * @param {TargetTypes} targetTypes - Object from the 'pasteConfig' that contains all 'targetObject' definitions.
     *
     * @param {IModelObject} targetObject - The 'target' IModelObject to test.
     *
     * @return {Object} The 'best fit' 'sourceTypes' object in the 'pasteConfig' for the given 'target' object (or NULL
     *         if no match was possible).
     */
    function _bestTargetFit( targetTypes, targetObject ) {
        var typeHier = targetObject.modelType.typeHierarchyArray;

        for( var ii = 0; ii < typeHier.length; ii++ ) {
            var typeName = typeHier[ii];
            if( targetTypes[typeName] ) {
                return targetTypes[typeName];
            }
        }

        return null;
    }

    /**
     * @param {SourceTypes} sourceTypes - Object from the 'pasteConfig' specific to some 'targetObject'.
     *
     * @param {IModelObject} sourceObject - The 'source' IModelObject to test.
     *
     * @return {String} Name of the 'pasteHandlerFunction' appropriate for pasting the given 'source'.
     */
    function _bestSourceFit( sourceTypes, sourceObject ) {
        var typeHier = sourceObject.modelType.typeHierarchyArray;

        for( var ii = 0; ii < typeHier.length; ii++ ) {
            var typeName = typeHier[ii];
            if( sourceTypes[typeName] && sourceTypes[typeName].handler ) {
                return sourceTypes[typeName].handler;
            }
        }

        return null;
    }

    /**
     * Using the 'pasteConfig' provided by various AW modules, select the 'best fit' for the given 'target' IModelObject
     * based on its actual type (or the type of its nearest ancestor in the type hierarchy).
     *
     * @param {PasteConfiguration} pasteConfig - Set of configuration options for pasting various 'source' objects' onto
     *            different 'target' IModelObject types.
     *
     * @param {Object} targetObject - The 'target' IModelObject to test.
     *
     * @return {Object} The 'sourceTypes' property from the 'pasteConfig' for the given 'target' object type or its
     *         ancestor types up the hierarchy (or NULL if no match was found).
     */
    function _findValidSourceTypes( pasteConfig, targetObject ) {
        var typeHier = targetObject.modelType.typeHierarchyArray;

        /**
         * Starting at the 'target' object's actual type, try to find a matching 'targetType' property in the
         * 'pasteConfig'. If an exact match is not found, try the super type of the 'target' up its hierarchy tree. Stop
         * looking when the 1st one (i.e. the 'closest' one) is found.
         */
        for( var ii = 0; ii < typeHier.length; ii++ ) {
            var typeName = typeHier[ii];
            if( pasteConfig.targetTypes[typeName] ) {
                return pasteConfig.targetTypes[typeName].sourceTypes;
            }
        }

        return null;
    }

    /**
     * Take the array of fileNames and create 'datasets' and related them to the 'target' IModelObject and then upload
     * the JS Files and then commit the files to the new 'datasets'.
     *
     * @param {IModelObject} targetObject - The IModelObject the files are to be pasted onto.
     *
     * @param {Object} getDatasetTypesResponse - Response object from the previous SOA operation (or NULL if the given
     *            'datasetInfos' parameter should be used).
     *
     * @param {Object} datasetInfos - The 'datasetInfos' property from the 'sourceTypes' object in the 'pasteConfig'
     *            JSON.
     *
     * @param {FileArray} sourceFiles - Array of 'source' JS Files being dragged.
     *
     * @param {StringArray} fileNames - Array of file paths to files on this local client machine to create Datasets
     *            for.
     *
     * @param {String} relationType - The 'relationType' to use when attaching the new 'datasets' to the 'target'
     *            IModelObject.
     *
     * @param {Object} fileInfos - An object populated with various bits of information about the files, types & related
     *            information.
     *
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    function _createDatasetsAndRelate( targetObject, getDatasetTypesResponse, datasetInfos, sourceFiles, fileNames,
        relationType, fileInfos ) {
        assert( _pasteConfig, "The 'pasetConfiguration' is not loaded" );

        var requestIndex = 0;

        var request = [];

        _
            .forEach( fileNames,
                function( fileName ) {

                    /**
                     * Extract the file 'extension', file 'name' and dataSet 'name' from the file's name.
                     * <P>
                     * Note: The following code needs to match the same steps in
                     * 'CreateObjectPresenterW.onDatasetFileSelected'
                     */
                    var extension = null;

                    var extensionIndex = fileName.lastIndexOf( '.' );

                    if( extensionIndex >= 0 ) {
                        extension = fileName.substring( extensionIndex + 1 );
                    } else {
                        extension = ''; //$NON-NLS-1$
                    }

                    var datasetName = null;

                    var seperatorIndex = fileName.lastIndexOf( '\\' );

                    if( seperatorIndex === -1 ) {
                        seperatorIndex = fileName.lastIndexOf( '/' );
                    }

                    var datasetFileName = fileName.substring( seperatorIndex + 1 );

                    if( extensionIndex > seperatorIndex ) {
                        datasetName = fileName.substring( seperatorIndex + 1, extensionIndex );
                    } else {
                        datasetName = fileName.substring( seperatorIndex + 1 );
                    }

                    /**
                     * Determine 'Dataset' type, format and 'reference' from the 'datasetInfos' from 'pasteConfig' (if
                     * possible). If not in the 'pasteConfig' then use the information from the previous server call.
                     */
                    var namedReferenceName = '';
                    var datasetType = '';
                    var isText = false;

                    var found = false;

                    if( datasetInfos ) {
                        for( var i = 0; i < datasetInfos.length; i++ ) {
                            var datesetInfo = datasetInfos[i];

                            var exts = datesetInfo.extensions;

                            if( _.includes( exts, extension ) ) {
                                datasetType = datesetInfo.datasetType;
                                isText = datasetInfos.fileFormat === 'TEXT';
                                namedReferenceName = datesetInfo.referenceName;
                                found = true;
                            }
                        }
                    }

                    if( !found && getDatasetTypesResponse ) {
                        /**
                         * Loop through the possible FileTypes & relations valid for the Dataset.
                         */
                        var extentionTypeInfo = getDatasetTypesResponse.output;

                        for( var ii = 0; ii < extentionTypeInfo.length && !datasetType; ii++ ) {
                            var currExtTypeInfo = extentionTypeInfo[ii];

                            if( currExtTypeInfo.fileExtension === extension ) {
                                /**
                                 * Loop through the relation information until you find the 1st one that
                                 */
                                for( var jj = 0; jj < currExtTypeInfo.datasetTypesWithDefaultRelInfo.length &&
                                    !datasetType; jj++ ) {
                                    /**
                                     * We assume in the following that the 1st one with the matching file extension is
                                     * good.
                                     * <P>
                                     * This algorithm may need to be extended in the future to handle a 'best fit'
                                     * approach instead.
                                     */
                                    var dataSetTypeInfo = currExtTypeInfo.datasetTypesWithDefaultRelInfo[jj];

                                    var refInfo = dataSetTypeInfo.refInfos[0];

                                    namedReferenceName = refInfo.referenceName;
                                    isText = refInfo.fileFormat === 'TEXT';

                                    var dsType = app.cdm.getObject( dataSetTypeInfo.datasetType.uid );

                                    if( dsType ) {
                                        datasetType = dsType.props.object_string.dbValues[0];
                                    }
                                }
                            }
                        }
                    }

                    if( datasetType ) {
                        fileInfos.push( {
                            jsFile: sourceFiles[requestIndex],
                            datasetType: datasetType,
                            datasetName: datasetName,
                            datasetFileName: datasetFileName,
                            namedReferenceName: namedReferenceName,
                            isText: isText
                        } );

                        request.push( {
                            clientId: requestIndex.toString(),
                            createData: {
                                boName: datasetType,
                                propertyNameValues: {
                                    object_name: [ datasetName ]
                                }
                            },
                            targetObject: targetObject,
                            pasteProp: relationType
                        } );

                        requestIndex++;
                    }
                } );

        return _soaSvc.post( 'Internal-Core-2012-10-DataManagement', 'createRelateAndSubmitObjects', {
            inputs: request
        } );
    }

    /**
     * Invoke the 'getDatasetTypesWithDefaultRelation' SOA operation to determine which 'Dataset' type and 'relation'
     * type to create when dropping onto the given 'taregt' IModelObject.
     *
     * @param {Object} targetObject - The IModelObject the files are to be pasted onto.
     *
     * @param {StringArray} fileNames - Array of file paths to files on this local client machine to create Datasets
     *            for.
     *
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    function _getDatasetTypes( targetObject, fileNames ) {
        // Call to get Dataset types
        var request = {
            parent: targetObject,
            fileExtensions: []
        };

        /**
         * Determine an array of unique file extensions.
         */
        _.forEach( fileNames, function( fileName ) {
            var fileExt = _getFileExtension( fileName );

            if( fileExt && request.fileExtensions.indexOf( fileExt ) === -1 ) {
                request.fileExtensions.push( fileExt );
            }
        } );

        return _soaSvc.post( 'Internal-AWS2-2015-10-DataManagement', 'getDatasetTypesWithDefaultRelation', request );
    }

    /**
     * @param {Object} createDatasetsAndRelateResponse - Result from SOA 'createRelateAndSubmitObjects'.
     *
     * @param {ObjectArray} fileInfos - Array objects who's properties relate a 'dataset' and a file to be committed to
     *            it.
     *
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    function _getWriteTickets( createDatasetsAndRelateResponse, fileInfos ) {
        var requests = [];

        for( var i = 0; i < fileInfos.length; i++ ) {
            var fileInfo = fileInfos[i];

            fileInfo.dataset = createDatasetsAndRelateResponse.output[i].objects[0];

            var request = {};

            var clientId = i.toString();

            request.clientId = clientId;
            request.datasetTypeName = fileInfo.datasetType;
            request.version = 1;
            request.fileInfos = [ {
                clientFileId: clientId,
                refName: fileInfo.namedReferenceName,
                isText: fileInfo.isText,
                fileName: fileInfo.datasetFileName
            } ];

            requests.push( request );
        }

        return _soaSvc.post( 'Internal-Core-2008-06-FileManagement', 'getWriteTickets', {
            inputs: requests
        } );
    }

    /**
     * This class allows multiple file uploads to complete
     */
    var CommitManager = function() {
        var self = this;

        /**
         * Array of objects containing the 'fileInfo' and 'ticketInfo' for all currently pending commit's of a JS File
         * to a 'dataset'.
         */
        var _pendingCommits = [];

        /**
         * TRUE if a 'commit' SOA operation is currently taking place.
         * <P>
         * Note: This is needed since posting multiple 'commit' operations just 'stacks them up' in the queue.
         */
        var _commitInProgress = false;

        /**
         * The number of currently pending file uploads.
         */
        self.pendingUploadCount = 0;

        /**
         * The total number of file uploaded being managed by this CommitManager.
         */
        self.totalUploadCount = 0;

        /**
         * The 'deferred promise' object used to announce the life cycle of this CommitManager.
         */
        self.deferred = _$q.defer();

        /**
         * Array of 'dataset' IModelObjects created during the processing of this CommitManager.
         */
        self.sourceObjects = [];

        /**
         * Array of FMS servlet messages generated during the processing of this CommitManager for any files who's
         * upload was unsuccessful.
         */
        self.failureMessages = [];

        /**
         * Array of 'dataset' IModelObjects that had their associated file upload fail and should be deleted before we
         * are done.
         */
        self.pendingDatasetRemovals = [];

        /**
         * This function cleans up any pending 'dataset' deletes and resolves the primary deferred promise with a result
         * data object and finishes this file paste operation.
         */
        self.resolveFinalState = function() {
            /**
             * Check if we have some 'datasets' to delete
             */
            if( self.pendingDatasetRemovals.length > 0 ) {
                /**
                 * Remove the children 'datasets' from the 'parent 'target(s)'.
                 */
                _soaSvc.post( 'Core-2014-10-DataManagement', 'removeChildren', {
                    inputData: self.pendingDatasetRemovals
                } ).then( function( response ) {
                    /**
                     * Now that the 'datasets' are removed and detached from the 'target', announce to the rest of AW
                     * that it's related data has changed.
                     */
                    var updatedObjects = [ self.pendingDatasetRemovals[0].parentObj ];

                    app.eventBus.publishSoa( 'cdm.relatedModified', {
                        relatedModified: updatedObjects
                    } );

                    self.resolvePrimaryPromise();
                } );
            } else {
                self.resolvePrimaryPromise();
            }
        };

        /**
         * Resolve the primary deferred promise with a data object containing the results of the file paste operation.
         */
        self.resolvePrimaryPromise = function() {
            self.todoCommits.cancel();

            var result = {
                totalCount: self.totalUploadCount,
                sourceObjects: self.sourceObjects,
                failureMessages: self.failureMessages
            };

            self.deferred.resolve( result );
        };

        /**
         * This function is call one or more times during a file upload. When the upload is complete and successful,
         * this function will queue up a 'commit' of that file to its 'dataset' and 'ping' the LoDash 'debounce' used to
         * batchup the 'commit' operations to the SOA server.
         *
         * @param {Event} evt - Event from XMLHttpRequest called or more time during a file upload.
         */
        self.onLoad = function( evt ) {
            if( evt.currentTarget.readyState === 4 ) {
                app.eventBus.publishSoa( 'progress.end', {
                    endPoint: _fmsUploadUrl
                } );

                /**
                 * Decrement the number of files from the original set we are down to.
                 */
                self.pendingUploadCount--;

                /**
                 * Check if the upload was successful.
                 */
                var fileInfoDone = evt.currentTarget.fileInfo;

                if( evt.currentTarget.status === 200 ) {
                    /**
                     * Build the 'commit' request for the uploaded File to the 'dataset'.
                     */
                    var commitRequest = {
                        dataset: fileInfoDone.dataset,
                        createNewVersion: true,
                        datasetFileTicketInfos: [ {
                            datasetFileInfo: {
                                fileName: fileInfoDone.datasetFileName,
                                namedReferencedName: fileInfoDone.namedReferenceName,
                                isText: fileInfoDone.isText
                            },
                            ticket: evt.currentTarget.ticketInfo.ticket
                        } ]
                    };

                    _pendingCommits.push( commitRequest );

                    /**
                     * Remember this 'dataset' as one of the successful ones.
                     */
                    self.sourceObjects.push( fileInfoDone.dataset );

                    /**
                     * 'ping' the LoDash 'debounce' assistant to reset the timer.
                     */
                    evt.currentTarget.commitManager.todoCommits();
                } else {
                    /**
                     * Build a failure message and add it to the collection of such messages.
                     */
                    var failureMessage = '(' + evt.currentTarget.status + ') ' + evt.currentTarget.statusText + ' : ' +
                        evt.currentTarget.fileInfo.datasetFileName;

                    self.failureMessages.push( failureMessage );

                    /**
                     * Queue up the 'dataset' to be removed. Append to the array of an existing entry if from the same
                     * 'target' IModelObject.
                     */
                    var foundPending = false;

                    _.forEach( self.pendingDatasetRemovals, function( pendingDelete ) {
                        if( pendingDelete.parentObj === evt.currentTarget.targetObject ) {
                            foundPending = pendingDelete;
                        }
                    } );

                    if( foundPending ) {
                        foundPending.childrenObj.push( fileInfoDone.dataset );
                    } else {
                        var removeInput = {
                            parentObj: evt.currentTarget.targetObject,
                            childrenObj: [ fileInfoDone.dataset ]
                        };

                        self.pendingDatasetRemovals.push( removeInput );
                    }

                    /**
                     * Check if we have no upload or commits pending by this CommitManager.<BR>
                     * If so: Resolve the 'deferred' for this CommitManager to inform any listener that we are all done.
                     */
                    if( self.pendingUploadCount === 0 && _pendingCommits.length === 0 ) {
                        self.resolveFinalState();
                    }
                }
            }
        };

        /**
         * Calls the SOA 'commitDatasetFiles' API passing it however many 'dataset' files are currently pending. The
         * array of pending will be reset.
         */
        self.processPendingCommits = function() {
            if( _pendingCommits.length ) {
                if( _commitInProgress ) {
                    return;
                }

                var commitInput = {
                    commitInput: _pendingCommits
                };

                _pendingCommits = [];

                _commitInProgress = true;

                _soaSvc.post( 'Core-2006-03-FileManagement', 'commitDatasetFiles', commitInput ).then(
                    function( response ) {
                        _commitInProgress = false;

                        self.processPendingCommits();
                    } );
            } else {
                /**
                 * We have no commits pending so check if we have uploaded the last file in the set being managed by
                 * this CommitManager.<BR>
                 * If so: Resolve the 'deferred' for this CommitManager to inform any listener that we are all done.
                 */
                if( self.pendingUploadCount === 0 ) {
                    self.resolveFinalState();
                }
            }
        };

        /**
         * Create a 'debounce' function to help balance the server load during upload.
         */
        self.todoCommits = _.debounce( self.processPendingCommits, 1000, {
            leading: false,
            trailing: true,
            maxWait: 10000
        } );

        return self;
    };

    /**
     * ############################################################<BR>
     * Define the public functions exposed by this module.<BR>
     * ############################################################<BR>
     */
    var exports = {};

    /**
     * Look for support of the 'files' in the 'dataTranfer' area of the event.
     *
     * @param {DrageStartEvent} event - The {@link DragStartEvent} to test.
     * @return TRUE if the 'files' property is found in the 'dataTransfer' property of the event.
     */
    exports.dataTransferContainsFiles = function( event ) {
        var types = event.dataTransfer.types;

        for( var i = 0; i < types.length; ++i ) {
            if( types[i] === 'Files' ) {
                return true;
            }
        }

        return false;
    };

    /**
     * Perform the 'default' configured paste behavior for the given IModelObjects onto the given 'target' IModelObject
     * creating the given relationship type between them.
     *
     * @param {ModelObject} targetObject - The 'target' IModelObject for the paste.
     * @param {ModelObjectArray} sourceObjects - Array of 'source' IModelObjects to paste onto the 'target' IModelObject
     * @param {String} relationType - relation type name (object set property name)
     *
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.defaultObjectPasteHandler = function( targetObject, sourceObjects, relationType ) {
        var relations = [];

        _.forEach( sourceObjects, function( sourceObject ) {
            relations.push( {
                primaryObject: targetObject,
                secondaryObject: sourceObject,
                relationType: relationType
            } );
        } );

        var injector = app.ngModule.element( document ).injector();

        var dmSvc = injector.get( 'soa_dataManagementService' );

        return dmSvc.createRelations( relations );
    };

    /**
     * @param {ModelObject} targetObject - The 'target' IModelObject for the paste.
     * @param {ModelObjectArray} sourceObjects - Array of 'source' IModelObjects to paste onto the 'target'
     *            IModelObject.
     * @param {String} relationType - Relation type name (object set property name)
     *
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.execute = function( targetObject, sourceObjects, relationType ) {
        if( _pasteConfig ) {
            var queue = {};

            _.forEach( sourceObjects, function( sourceObject ) {
                var handlerFunctionName = null;

                var targetTypeConfig = _bestTargetFit( _pasteConfig.targetTypes, targetObject );

                if( targetTypeConfig ) {
                    handlerFunctionName = _bestSourceFit( targetTypeConfig.sourceTypes, sourceObject );
                }

                if( !handlerFunctionName ) {
                    handlerFunctionName = 'defaultObjectPasteHandler';

                    logSvc.warn( "No configured paste handler found for source type: '" +
                        sourceObject.modelType.typeHierarchyArray[0] + "' when target type: '" +
                        targetObject.modelType.typeHierarchyArray[0] + "'" + '\n' + //
                        "RelationType: '" + relationType + "'" + '\n' + //
                        '...Assuming default handler' );
                }

                if( !queue.hasOwnProperty( handlerFunctionName ) ) {
                    queue[handlerFunctionName] = [];
                }

                queue[handlerFunctionName].push( sourceObject );
            } );

            /**
             * Loop for each unique 'handler' and build up a promise chain.
             */
            var promise = null;

            _.forEach( queue, function( queuedSourceObjects, handlerFunctionName ) {
                /**
                 * Check if the function exists.
                 */
                if( !exports[handlerFunctionName] ) {
                    logSvc.error( 'Unknown paste handler function: ' + handlerFunctionName );
                } else {
                    /**
                     * Check if this is the 1st link in the promise chain.<BR>
                     * If so: Get the top-level promise from the 1st handler.<BR>
                     * If not: Add the next handler's promise as the next link in the promise chain.
                     */
                    if( !promise ) {
                        promise = exports[handlerFunctionName]( targetObject, queuedSourceObjects, relationType );
                    } else {
                        promise.then( function() {
                            return exports[handlerFunctionName]( targetObject, queuedSourceObjects, relationType );
                        } );
                    }
                }
            } );

            if( !promise ) {
                var deferred = _$q.defer();

                deferred.resolve();

                promise = deferred.promise;
            }

            return promise;
        }
    };

    /**
     * Creates new 'source' 'Dataset' type objects, uploads the given JS Files to FMS and attaches them to the 'sources'
     * and then pastes the 'sources' onto the given 'target' IModelObject.
     *
     * @param {ObjectArray} pasteFilesInput - An array of objects that maps a unique 'relationType' to the array of
     *            'sourceObjects' (JS Files) that should be pasted onto the 'targetObject' with that 'relationType'.
     *
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available. The resolved data is the result object from the final call to
     *          'Core-2006-03-DataManagement/createRelations'.
     */
    exports.pasteFiles = function( pasteFilesInput ) {
        /**
         * Create the object used to manage all info for the duration of this set of files.
         */
        var commitManager = new CommitManager();

        _.forEach( pasteFilesInput, function( curr ) {

            var targetObject = curr.targetObject;
            var relationType = curr.relationType;
            var sourceFiles = curr.sourceObjects;

            var filenames = [];

            for( var j = 0; j < sourceFiles.length; j++ ) {
                filenames.push( sourceFiles[j].name );
            }

            var targetTypeConfig = _bestTargetFit( _pasteConfig.targetTypes, targetObject );

            var datasetInfos = null;

            if( targetTypeConfig && targetTypeConfig.sourceTypes.Dataset ) {
                datasetInfos = targetTypeConfig.sourceTypes.Dataset.datasetInfos;
            }

            var fileInfos = [];

            _getDatasetTypes( targetObject, filenames ).then(
                function( getDatasetTypesResponse ) {
                    return _createDatasetsAndRelate( targetObject, getDatasetTypesResponse, datasetInfos, sourceFiles,
                        filenames, relationType, fileInfos );

                } ).then( function( createDatasetsAndRelateResponse ) {
                /**
                 * Now that the 'datasets' are created and related to the 'target', announce to the rest of AW that it's
                 * related data has changed.
                 */
                var updatedObjects = [ targetObject ];

                app.eventBus.publishSoa( 'cdm.relatedModified', {
                    relatedModified: updatedObjects
                } );

                /**
                 * Get the FMS tickets we need to commit the files we are about to upload.
                 */
                return _getWriteTickets( createDatasetsAndRelateResponse, fileInfos );

            } ).then( function( getWriteTicketsResponse ) {
                /**
                 * Set the total # of file we are going to handle
                 * <P>
                 * Create the LoDash 'debounce' we will use to control how often we use the 'commit' SOA operation.
                 * <P>
                 * Note: 'maxWait' is only relevant if 'lots' of files are uploading quickly yet we still want to
                 * 'commit' regularly (i.e. after 'maxWait' time).
                 */
                commitManager.pendingUploadCount += Object.keys( getWriteTicketsResponse.tickets ).length;
                commitManager.totalUploadCount += commitManager.pendingUploadCount;

                _.forEach( getWriteTicketsResponse.tickets, function( ticketInfos ) {

                    _.forEach( ticketInfos, function( ticketInfo ) {
                        /**
                         * Save the 'source' 'dataset' this File is associated with.
                         */
                        var fileInfo = fileInfos[ticketInfo.clientFileId];

                        /**
                         * Create an 'XMLHttpRequest' and setup a callback for when the upload is 'DONE" and we commit
                         * the file to the 'dataset'.
                         */
                        var httpRequest = new XMLHttpRequest();

                        httpRequest.onload = commitManager.onLoad;

                        /**
                         * Build up the information we will need later to commit the file to the 'dataset' when the
                         * upload is complete.
                         */
                        httpRequest.commitManager = commitManager;
                        httpRequest.targetObject = targetObject;
                        httpRequest.fileInfo = fileInfo;
                        httpRequest.ticketInfo = ticketInfo;

                        /**
                         * Start to 'in progress' UI and perform the 'post' to upload the JS file.
                         */
                        httpRequest.open( "POST", _fmsUploadUrl, true );

                        var formData = new FormData();

                        formData.append( 'fmsFile', fileInfo.jsFile, fileInfo.jsFile.name );
                        formData.append( 'fmsTicket', ticketInfo.ticket );

                        app.eventBus.publishSoa( 'progress.start', {
                            endPoint: _fmsUploadUrl
                        } );

                        httpRequest.send( formData );
                    } );
                } );
            } );
        } );

        /**
         * Return the primary deferred promise
         */
        return commitManager.deferred.promise;
    };

    /**
     * Publish a 'drop' topic on the 'paste' channel of the Native JS 'eventBus' with the given data.
     *
     * @param {ObjectArray} pasteInput - An array of objects that maps a unique 'relationType' to the array of
     *            'sourceObjects' {@link IModelObject} s that should be pasted onto the 'targetObject' with that
     *            'relationType'.
     */
    exports.publishDropEvent = function( pasteInput ) {
        app.eventBus.publish( {
            channel: 'paste',
            topic: 'drop',
            data: {
                pasteInput: pasteInput
            }
        } );
    };

    /**
     * @param {DragStartEvent} event - The DragStartEvent to extract types from.
     * @return {StringArray} Array of unique 'types' of the items in the 'dataTransfer' (or empty array if the files
     *         types are not available. For example in IE or FireFox).
     */
    exports.getDataTransferFileTypes = function( event ) {
        var dtTypes = [];

        if( event.dataTransfer.items ) {
            var itemObjs = event.dataTransfer.items;

            for( var i = 0; i < itemObjs.length; i++ ) {
                var fileExt = _getDataTransferType( itemObjs[i].type );

                if( fileExt && dtTypes.indexOf( fileExt ) === -1 ) {
                    dtTypes.push( fileExt );
                }
            }
        }

        return dtTypes;
    };

    /**
     * @param {String} targetUID -
     * @param {StringArray} fileTypes -
     * @return {Promise}
     */
    exports.getDataTransferSourceTypes = function( targetUID, fileTypes ) {
        var targetObject = app.cdm.getObject( targetUID );

        var request = {
            parent: targetObject,
            fileExtensions: fileTypes
        };

        return _soaSvc.postUnchecked( 'Internal-AWS2-2015-10-DataManagement', 'getDatasetTypesWithDefaultRelation',
            request ).then(
            function( response ) {

                if( response.partialErrors || response.PartialErrors || response.ServiceData &&
                    response.ServiceData.partialErrors ) {
                    return [];
                }

                var dsTypes = [];

                var output = response.output;

                for( var i = 0; i < output.length; i++ ) {
                    var dsInfos = output[i].datasetTypesWithDefaultRelInfo;

                    for( var j = 0; j < dsInfos.length; j++ ) {
                        var dsInfo = dsInfos[j];
                        var dsUid = dsInfo.datasetType.uid;

                        var dsType = app.cdm.getObject( dsUid );

                        var type = dsType.props.object_string.dbValues[0];

                        dsTypes.push( type );
                        break;
                    }
                }

                var someMissing = false;

                _.forEach( dsTypes, function( typeName ) {
                    if( !app.cmm.containsType( typeName ) && _invalidTypeNames.indexOf( typeName ) === -1 ) {
                        someMissing = true;
                    }
                } );

                if( someMissing ) {
                    return _soaSvc.ensureModelTypesLoaded( dsTypes, dsTypes );
                }

                return dsTypes;

            }, function( e ) {
                return [];
            } );
    };

    /**
     * @param {ModelObject} targetObject - The 'target' IModelObject to use when determining which 'source' types are
     *            potentially valid to be dropped upon it.
     *
     * @return {Object} The 'sourceTypes' property from the 'pasteConfig' for the given 'target' object type or its
     *         ancestor types up the hierarchy (or NULL if no match was found).
     */
    exports.getObjectValidSourceTypes = function( targetObject ) {
        assert( _pasteConfig, "The 'pasetConfiguration' is not loaded" );

        return _findValidSourceTypes( _pasteConfig, targetObject );
    };

    /**
     * @param {ModelObject} targetObject - The 'target' IModelObject to use when determining which 'source' types are
     *            potentially valid to be dropped upon it.
     *
     * @param {String} sourceType - The 'source' type to return the 'sourceTypeInfo' for.
     *
     * @return {Object} The 'sourceTypes' property from the 'pasteConfig' for the given 'target' object type or its
     *         ancestor types up the hierarchy (or NULL if no match was found).
     */
    exports.getValidSourceTypeInfo = function( targetObject, sourceType ) {
        var sourceTypes = exports.getObjectValidSourceTypes( targetObject );

        if( sourceTypes ) {
            var modelType = app.cmm.getType( sourceType );

            if( modelType ) {
                for( var i = 0; i < modelType.typeHierarchyArray.length; i++ ) {
                    var type = modelType.typeHierarchyArray[i];
                    if( sourceTypes[type] ) {
                        return sourceTypes[type];
                    }
                }
            } else {
                logSvc.warn( "The 'source' ModelType is not currently loaded: " + modelType );
            }
        }

        return null;
    };

    /**
     * Register this service with the AngularJS application.
     *
     * @returns {Object} Reference to this module's API.
     */
    app.factory( 'pasteService', [
        '$q',
        'soa_kernel_soaService',
        function( $q, soaSvc ) {
            _$q = $q;
            _soaSvc = soaSvc;

            try {
                httpWrapper.get( app.cdm.getBaseURL() + app.getBaseUrlPath() + '/js/pasteConfiguration.json' ).then(
                    function( res ) {
                        _pasteConfig = res.data;
                    } );
            } catch( e ) {
                logSvc.warn( 'Error while reading/parsing pasteConfiguration.json: ' + e );
            }

            _fmsUploadUrl = app.cdm.getBaseURL() + 'fms/fmsupload/';

            return exports;
        } ] );

    return exports;
} );