//@<COPYRIGHT>@
//==================================================
//Copyright 2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 awInclude
 */

/**
 * @module js/NgTableProperty - wraps NgUIGrid.js for table props view.
 */

 define(
    [ 'app', 'angular', 'jquery', 'js/NgUIGrid','js/NgI18n' ],
    function(app, ngModule, $ , ngUiGrid) {
        'use strict';

        var exports = {};

        /**
         * Defines the table property controller
         *
         * @constructor awTablePropertyController
         * @memberof NgControllers
         */
        app.controller('awTablePropertyController', [
            '$scope',
            '$element',
            'localeService',
             function($scope, $element ,localeService) {
                var self = this;

                self.setOverlay = function (gridOverlay) {
                    $scope.prop = gridOverlay;
                };

                $scope.removeSelectedRow = function(event) {
                    if($scope.prop && $scope.prop.api.removeRows) {
                        $scope.prop.api.removeRows();
                    }
                };


                $scope.addTableRow = function(event) {
                    if($scope.prop && $scope.prop.api.addNewRow) {
                        $scope.prop.api.addNewRow();

                    }
                };
                $scope.getRemoveTitle = function(event) {
                    localeService.getTextPromise().then( function( localTextBundle ) {
                        $(event.currentTarget).attr('title', localTextBundle.REMOVE_BUTTON_TITLE);
                    });

                };

                $scope.getAddTitle = function(event) {
                    localeService.getTextPromise().then( function( localTextBundle ) {
                        $(event.currentTarget).attr('title', localTextBundle.ADD_BUTTON_TITLE);
                    });
                };
            }
        ]); // awTablePropertyController

        /**
         * Definition for the (aw-table-property) directive.
         *
         * @member aw-table-property
         * @memberof NgElementDirectives
         */
        app.directive('awTableProperty', function() {

            return {

                restrict : 'E',
                scope : {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop : '='
                },
                controller : 'awTablePropertyController',
                templateUrl : app.getBaseUrlPath() + '/html/NgAwTableProperty.html'
            };
        });

        /**
         * Initialize ('bootstrap') the angular system and create an angular controller on a new 'child' of the given
         * 'parent' element.
         *
         * @param {Element} parentElement - The DOM element the controller and 'inner' HTML content will be added to.
         *            <P>
         *            Note: All existing 'child' elements of this 'parent' will be removed.
         *
         * @param {String} innerHtml - String that defines the exact HTML content that will be added to the 'parent'
         *            element.
         *
         * @param {Object} gridOverlay - Arbitrary object to be set as the primary 'scope' of the new angular
         *            controller.
         *            <P>
         *            Note: This object will have the 'rootScopeElement' property set on this object with the new
         *            AngularJS Element created to hold the compiled given 'innerHtml' and attached as a child to the
         *            given 'parentElement'.
         */
        exports.insertGrid = function(parentElement, innerHtml, gridOverlay) {
            ngUiGrid.insertGrid( parentElement, innerHtml, gridOverlay );
        };

        exports.forceRefresh = function(parentElement, gridOverlay) {
            ngUiGrid.forceRefresh( parentElement, gridOverlay );
        };

        exports.insertHeader = function(parentElement, innerHtml, gridOverlay) {
            /**
             * Create an 'outer' <DIV> (to hold the given 'inner' HTML) and create the angular controller on it.
             * <P>
             * Remove any existing 'children' of the given 'parent'
             * <P>
             * Add this new element as a 'child' of the given 'parent'
             */
            var ctrlElement = ngModule.element('<div class="aw-layout-tablePropertyContent" ng-controller="awTablePropertyController">');

            ctrlElement.html(innerHtml);

            $(parentElement).empty();
            $(parentElement).append(ctrlElement);

            var ctrlFn = awInclude(parentElement, ctrlElement);
            if (ctrlFn) {
                ctrlFn.setOverlay(gridOverlay);
            }
        };

        return exports;
    });