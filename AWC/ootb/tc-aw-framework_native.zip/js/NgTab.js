//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 awInclude,
 console,
 define,
 navigator,
 window
 */

/**
 * @module js/NgTab
 */
define(
    [ 'app', 'angular', 'jquery' ],
    function( app, ngModule, $ ) {
        'use strict';

        /**
         * Controller referenced from the 'div' containing all the tab UI.
         *
         * @param {Object} $scope - The 'scope' all controller level values are defined on.
         * @param {Element} $element - DOM element the controller is attached to.
         * @param {AngularService} $interval -
         * @param {AngularService} $filter -
         * @param {AngularService} $timeout =
         *
         * @constructor awTabController
         *
         * @memberof NgControllers
         * @return {Void}
         */
        app.controller( 'awTabController', [ '$scope', '$element', '$interval', '$filter', '$timeout',
            function( $scope, $element, $interval, $filter, $timeout ) {
                var self = this;
                $scope.selectedObject = {};
                $scope.$on( '$destroy', function() {
                    $element.remove();
                    // $element = null;
                } );

                /**
                 * @memberof NgControllers.awTabController
                 *
                 * @param {Object} tabsModel - Tab model to be set on this controller's scope.
                 * @return {Void}
                 */
                self.setData = function( tabsModel ) {
                    $scope.$evalAsync( function() {
                        $scope.tabsModel = tabsModel;
                    } );
                };

                /**
                 * Set api object for page callback and initialize the tab bar.
                 *
                 * @memberof NgControllers.awTabController
                 *
                 * @param {Callback} apiFn - API for call backs from this controller.
                 * @return {Void}
                 */
                $scope.setCallbackApi = function( apiFn ) {
                    $scope.tabApiFn = apiFn;
                    $scope.clearTabs();
                    $timeout( function() {
                        $scope.$apply();
                    } );
                };

                /**
                 * Add a tab to the Tab Bar
                 *
                 * @memberof NgControllers.awTabController
                 *
                 * @param {NgTabItem} tabItem - Tab Object
                 * @return {Void}
                 */
                $scope.addTab = function( tabItem ) {
                    $scope.$evalAsync( function() {
                        var addToArray = true;
                        for( var i = 0; i < $scope.tabsModel.length; i++ ) {
                            if( $scope.tabsModel[i].pageId === tabItem.pageId ) {
                                addToArray = false;
                            }
                        }
                        if( addToArray ) {
                            $scope.tabsModel.push( tabItem );
                            var orderBy = $filter( 'orderBy' );
                            $scope.order = function( predicate, reverse ) {
                                $scope.tabsModel = orderBy( $scope.tabsModel, predicate, reverse );
                            };
                            $scope.order( 'pageId', false );
                        }
                        $timeout( function() {
                            $scope.$apply();
                        } );
                    } );
                };

                /**
                 * Clear the current tabs.
                 *
                 * @memberof NgControllers.awTabController
                 * @return {Void}
                 */
                $scope.clearTabs = function() {
                    $scope.$evalAsync( function() {
                        $scope.tabsModel = [];
                    } );
                };

                /**
                 * Update the currently selected Tab
                 *
                 * @memberof NgControllers.awTabController
                 *
                 * @param pageId PageId to set selected.
                 * @return {Void}
                 */
                $scope.updateSelectedTabById = function( pageId ) {
                    $scope.$evalAsync( function() {
                        for( var i = 0; i < $scope.tabsModel.length; i++ ) {
                            if( $scope.tabsModel[i].pageId === pageId ) {
                                $scope.tabsModel[i].selectedTab = true;
                                $scope.selectedObject.tab = $scope.tabsModel[i];

                            } else {
                                $scope.tabsModel[i].selectedTab = false;
                            }
                        }
                        $timeout( function() {
                            $scope.$apply();
                        } );
                    } );
                };

                // /**
                //  * *** Important Debug Output *** Please keep this block (even if it's commented out)
                //  */
                // if (app.isDebugEnabled) {
                //     $scope.$on('$destroy', function() {
                //         console.log('awTabController: Destroy $scope=' + $scope.$id);
                //     });
                // }
            } ] );

        /**
         * @constructor awTabContainerController
         * @memberof NgControllers
         *
         * @param {Object} $scope - The 'scope' all controller level values are defined on.
         * @param {Element} $element - DOM element the controller is attached to.
         * @param {AngularService} $interval -
         *
         * @return {Void}
         */
        app.controller( 'awTabContainerController',
            [
                '$scope',
                '$element',
                '$interval',
                function( $scope, $element, $interval ) {
                    var self = this;

                    $scope.tabs = null;
                    $scope.tabsModel = [];
                    $scope.selectedObject = {};
                    if( $scope.$parent && $scope.$parent.tabsModel ) {
                        $scope.tabsModel = $scope.$parent.tabsModel;
                        $scope.selectedObject = $scope.$parent.selectedObject;
                    }

                    $scope.tabApi = null;

                    if( $scope.tabContainerModel ) {
                        $scope.tabsModel = $scope.tabContainerModel;
                    }

                    if( $scope.callback ) {
                        $scope.tabApi = $scope.callback;
                    }

                    if( $scope.$parent && $scope.$parent.tabApi ) {
                        $scope.tabApi = $scope.$parent.tabApi;
                    }

                    $scope.webkitPrefix = "";
                    if( navigator.userAgent.toLowerCase().indexOf( "applewebkit" ) !== -1 ) {
                        $scope.webkitPrefix = "-webkit-";
                    }

                    /**
                     * @memberof NgControllers.awTabContainerController
                     *
                     * @param {Object} tabsModel -
                     * @return {Void}
                     */
                    self.setData = function( tabsModel ) {
                        $scope.$apply( function() {
                            $scope.tabsModel = tabsModel;
                        } );
                    };

                    /**
                     * Method to be called from the TAB container
                     *
                     * @memberof NgControllers.awTabContainerController
                     *
                     * @param {NgTabItem} selectedTab -
                     * @return {Void}
                     */
                    self.updateSelectedTab = function( selectedTab ) {
                        if( selectedTab !== $scope.selectedObject.tab ) {
                            $scope.selectedObject.tab = selectedTab;
                            if( $scope.updateSelectedTabById ) {
                                $scope.updateSelectedTabById( parseInt( $scope.selectedObject.tab.pageId, 10 ) );
                            } else {
                                if( $scope.$parent.updateSelectedTabById ) {
                                    $scope.$parent.updateSelectedTabById( parseInt( $scope.selectedObject.tab.pageId,
                                        10 ) );
                                }
                            }
                            $scope.setSelectedTab();
                        } else {
                            if( $scope.lastElement === selectedTab && $scope.firstElement !== selectedTab ) {
                                $scope.moveTabs();
                            }
                        }
                    };

                    // /**
                    //  * *** Important Debug Output *** Please keep this block (even if it's commented out)
                    //  */
                    // if (app.isDebugEnabled) {
                    //     console.log('awTabContainerController: Destroy $scope=' + $scope.$id);
                    // }

                } ] );

        /**
         * Outer Tab Container directive that builds enclosing DIV and Arrow SPAN.
         *
         * @member aw-tab-container
         * @memberof NgElementDirectives
         *
         * @param {AngularService} $timeout -
         * @param {AngularService} $interval -
         *
         * @return {Void}
         */
        app
            .directive(
                'awTabContainer',
                [
                    '$timeout',
                    '$interval',
                    function( $timeout, $interval ) {
                        return {
                            priority: 0,
                            transclude: true,
                            restrict: 'E',
                            templateUrl: app.getBaseUrlPath() + "/html/NgAwTabContainer.html",
                            scope: {
                                tabContainerModel: "=",
                                callback: "="
                            },
                            controller: 'awTabContainerController',
                            link: function postLink( scope, $element, attrs, tabContainerCtrl ) {
                                scope.lastElement = null;
                                scope.lastSelected = null;
                                scope.partialElement = null;
                                scope.firstElement = undefined;
                                scope.showArrow = false;
                                scope.selectedInRange = false;
                                scope.resizing = false;
                                scope.tabBarWidth = null;
                                scope.autoSelection = false;
                                $timeout( function() {
                                    scope.tabBarWidth = $element.find( "ol" )[0].clientWidth;
                                    scope.partialHidden = false;
                                }, 0 );

                                /**
                                 * Select the tab and ultimately fire the select API in AW.
                                 *
                                 * @return {Void}
                                 */
                                scope.setSelectedTab = function() {
                                    scope.displaySelection();
                                    scope.selectedObject.tab.selectedTab = true;
                                    if( scope.partialHidden && scope.selectedObject.tab === scope.lastElement &&
                                        !scope.autoSelection ) {
                                        scope.moveTabs();
                                    } else {
                                        scope.autoSelection = false;
                                        scope.refreshCarousel();
                                    }
                                    scope.lastSelected = scope.selectedObject.tab;
                                    if( scope.tabApi ) {
                                        scope.tabApi( parseInt( scope.selectedObject.tab.pageId, 10 ),
                                            scope.selectedObject.tab.name );
                                    } else {
                                        scope.$parent.tabApiFn.updateTabClick( parseInt(
                                            scope.selectedObject.tab.pageId, 10 ), scope.selectedObject.tab.name );
                                    }
                                };

                                /**
                                 * Set the new selected TAB to selected CSS state and revert last selected item to
                                 * unselected.
                                 *
                                 * @return {Void}
                                 */
                                scope.displaySelection = function() {

                                    if( scope.selectedObject.tab !== scope.lastSelected && scope.lastSelected ) {

                                        scope.lastSelected.selectedTab = false;
                                    }
                                    scope.lastSelected = scope.selectedObject.tab;
                                };

                                /**
                                 * Refresh the tabs, sizing those visible in the viewable area. In order for the text
                                 * overflow to be triggered, the last element in the visible area must be sized to the
                                 * amount of viewable space.
                                 *
                                 * @return {Void}
                                 */
                                scope.refreshCarousel = function() {
                                    if( scope.$parent && scope.$parent.tabsModel ) {
                                        scope.tabsModel = scope.$parent.tabsModel;
                                    }
                                    for( var i = 0; i < scope.tabsModel.length; i++ ) {
                                        var tabModel = scope.tabsModel[i];
                                        if( !tabModel.selectedTab && !tabModel.initialAnchorWidth ) {
                                            tabModel.initialAnchorWidth = $element.find( "a" )[i].clientWidth;
                                        }
                                        if( !tabModel.selectedTab && !tabModel.initialTabWidth ) {
                                            tabModel.initialTabWidth = $element.find( "li" )[i].clientWidth;
                                        }
                                        tabModel.width = "100%";
                                    }
                                    // $timeout is necessary to guarantee the digest has ended and
                                    // the DOM reflects the model.
                                    var childWidths = 0;
                                    scope.selectedInRange = false;
                                    scope.firstElement = undefined;
                                    scope.lastElement = undefined;
                                    scope.partialElement = undefined;
                                    scope.partialHidden = false;
                                    scope.showArrow = false;
                                    var tabContainerDomEl = $( $element ).find( "ol" )[0];
                                    scope.tabBarWidth = tabContainerDomEl.clientWidth;
                                    if( tabContainerDomEl.children.length > 0 && scope.tabBarWidth > 0 ) {

                                        // Process what tabs are visible and if any need
                                        // resized to
                                        // trigger text overflow.
                                        for( var tabNdx = 0; tabNdx < scope.tabsModel.length; tabNdx++ ) {
                                            var tabModel = scope.tabsModel[tabNdx];

                                            var tabEl = $( tabContainerDomEl.children[tabNdx] ).find( "li" );

                                            if( !tabEl[0] ) {
                                                continue;
                                            }

                                            var tabElWidth = tabEl[0].clientWidth;
                                            var tabAnchorElWidth = $( tabContainerDomEl.children[tabNdx] ).find( "a" )[0].clientWidth;
                                            if( tabModel.initialAnchorWidth &&
                                                tabAnchorElWidth < tabModel.initialAnchorWidth ) {
                                                tabAnchorElWidth = tabModel.initialAnchorWidth;
                                            }
                                            if( tabModel.initialTabWidth && tabElWidth < tabModel.initialTabWidth ) {
                                                tabElWidth = tabModel.initialTabWidth;
                                            }
                                            if( tabNdx === 0 ) {
                                                scope.firstElement = tabModel;
                                            }
                                            var childWidth = tabElWidth;
                                            tabModel.displayTab = "visible";
                                            if( ( childWidths + tabAnchorElWidth >= ( scope.tabBarWidth ) || tabAnchorElWidth > scope.tabBarWidth ) &&
                                                ( !scope.partialHidden ) ) {
                                                var resizedWidth = tabAnchorElWidth -
                                                    ( ( childWidths + tabAnchorElWidth ) - scope.tabBarWidth );
                                                if( ( resizedWidth >= 0 ) && ( resizedWidth <= tabAnchorElWidth ) ||
                                                    ( scope.tabsModel.length > tabNdx + 1 ) ) {
                                                    if( tabModel.width !== "100%" ) {
                                                        scope.partialElement = tabModel;
                                                    }
                                                }

                                                // this is necessary due to an issue with
                                                // text
                                                // overflow in the CSS.
                                                if( scope.tabBarWidth - childWidths <= 24 || resizedWidth <= 24 ) {
                                                    tabModel.displayTab = "hidden";
                                                    scope.lastElement = scope.tabsModel[tabNdx - 1];
                                                    scope.partialElement = scope.tabsModel[tabNdx];
                                                    scope.partialHidden = true;
                                                } else {
                                                    if( resizedWidth <= tabAnchorElWidth ) {
                                                        if( resizedWidth > 0 ) {
                                                            tabModel.width = resizedWidth + "px";
                                                            scope.partialHidden = true;
                                                        }
                                                        if( scope.showArrow ) {
                                                            scope.partialElement = tabModel;
                                                        }
                                                    } else {
                                                        if( scope.tabsModel.length === tabNdx + 1 ) {
                                                            scope.showArrow = false;
                                                        }
                                                    }
                                                }

                                                if( tabModel.displayTab !== "hidden" ) {
                                                    scope.lastElement = tabModel;
                                                    scope.partialElement = tabModel;
                                                }
                                            } else {
                                                if( tabModel.selectedTab && childWidths < scope.tabBarWidth ) {
                                                    scope.selectedInRange = true;
                                                }
                                                if( childWidths >= scope.tabBarWidth ) {
                                                    tabModel.displayTab = "hidden";
                                                }
                                            }
                                            if( tabModel.selectedTab && childWidths >= scope.tabBarWidth ) {
                                                scope.selectedInRange = false;
                                            }
                                            childWidths = ( childWidths + childWidth );
                                        }
                                        if( scope.partialElement ) {
                                            scope.showArrow = true;
                                        }
                                        // If the selection is outside of the viewable area
                                        // it needs
                                        // to be moved to the start.
                                        if( !scope.selectedInRange &&
                                            scope.selectedObject.tab !== scope.partialElement &&
                                            scope.selectedObject.tab !== scope.firstElement && !isNaN( childWidths ) ) {
                                            scope.preserveSelection();
                                        }
                                        // If the tab has been moved one position left but
                                        // is still
                                        // not full visible, then move again.
                                        else if( ( ( scope.showArrow && scope.selectedObject.tab &&
                                            scope.selectedObject.tab === scope.lastElement &&
                                            scope.selectedObject.tab !== scope.firstElement && scope.selectedObject.tab === scope.partialElement ) ) &&
                                            !scope.resizing ) {
                                            scope.moveTabs();
                                        }
                                        // Apply is necessary to update the value for the
                                        // ng-hide on
                                        // the arrow.
                                        $timeout( function() {
                                            scope.$apply();
                                        } );
                                        scope.resizing = false;
                                    }
                                    tabContainerDomEl = null;
                                };

                                /**
                                 * Keep the current selection in the viewable area.
                                 *
                                 * @return {Void}
                                 */
                                scope.preserveSelection = function() {
                                    if( scope.tabsModel.length > 0 && scope.selectedObject.tab !== undefined ) {
                                        if( scope.selectedObject.tab !== undefined ) {
                                            if( scope.tabsModel.indexOf( scope.selectedObject.tab ) > -1 ) {
                                                scope.lastElement = scope.tabsModel.splice( 0, 1 )[0];
                                                scope.tabsModel.push( scope.lastElement );
                                                scope.firstElement = scope.tabsModel[0];
                                                if( scope.selectedObject.tab === scope.firstElement ) {
                                                    scope.selectedInRange = true;
                                                    scope.refreshCarousel();
                                                } else {
                                                    scope.preserveSelection();
                                                }
                                            }
                                        }
                                    }
                                };

                                /**
                                 * Move the tabs one position left. Adds a transition effect to the tab bar. Detaches
                                 * the first tab and adds it as the last element The perceived carousel animation is
                                 * achieved by moving all the tabs left by the width of the first time. The animation
                                 * transition is then programatically removed and after the detach the tabs are moved
                                 * back to the previous position.
                                 *
                                 * @return {Void}
                                 */
                                scope.moveTabs = function() {
                                    // $timeout is necessary to guarantee the digest has ended and
                                    // the DOM reflects the model.

                                    // return all tabs to original size before move.
                                    for( var i = 0; i < scope.tabsModel.length; i++ ) {
                                        var tabModel = scope.tabsModel[i];
                                        tabModel.width = "100%";
                                    }
                                    var allTabs = $element.find( "ol" )[0];
                                    allTabs.className += " aw-jswidget-animateMove";
                                    var firstTab = scope.tabsModel[0];
                                    var elWidth = $( allTabs ).find( "li" )[0].clientWidth;
                                    // We need to add the transition end event to remove and append
                                    // our tabs
                                    // after the animation completes.
                                    $( allTabs )
                                        .bind(
                                            "webkitTransitionEnd oTransitionEnd otransitionend transitionend msTransitionEnd",
                                            function() {
                                                allTabs.className = allTabs.className.replace(
                                                    /(?:^|\s)aw-jswidget-animateMove(?!\S)/g, '' );
                                                scope.performTabReorder();
                                            } );
                                    allTabs.style[scope.webkitPrefix + "transform"] = 'translate(' + -elWidth +
                                        'px, 0)';
                                };

                                /**
                                 * Performs the Model reorder.
                                 *
                                 * @return {Void}
                                 */
                                scope.performTabReorder = function() {
                                    $timeout( function() {
                                        var child = scope.tabsModel[0];
                                        scope.tabsModel.splice( 0, 1 );
                                        scope.tabsModel.push( child );
                                        if( scope.lastSelected === undefined || scope.lastSelected === null ||
                                            scope.lastSelected === child ) {
                                            child.classValue = "aw-base-tabTitle";
                                            scope.autoSelection = true;
                                            tabContainerCtrl.updateSelectedTab( scope.tabsModel[0] );
                                        }
                                        var allTabs = $element.find( "ol" )[0];
                                        // Remove transition end event as we do not want to attach a new
                                        // one.
                                        $( allTabs )
                                            .unbind(
                                                "webkitTransitionEnd oTransitionEnd otransitionend transitionend msTransitionEnd" );
                                        allTabs.style[scope.webkitPrefix + "transform"] = 'translate(' + 0 + 'px, 0)';
                                    } );
                                };

                                scope.checkResize = function() {
                                    var tabBarOL = $element.find( "ol" )[0];
                                    if( tabBarOL && tabBarOL.children.length > 0 ) {
                                        var firstTabId = $element.find( "ol" ).find( "a" )[0].name;
                                        if( tabBarOL.clientWidth !== scope.oldWidth ) {
                                            scope.oldWidth = tabBarOL.clientWidth;
                                            scope.resizing = true;
                                            scope.refreshCarousel();
                                        }
                                        if( tabBarOL && scope.oldFirstTabId !== firstTabId ) {
                                            scope.oldFirstTabId = firstTabId;
                                            scope.refreshCarousel();
                                        }
                                    }
                                    tabBarOL = null;
                                };

                                /**
                                 * Allow tabs variable to be set from child scope. Sets up interval polling for
                                 * container resize.
                                 *
                                 * @memberof NgControllers.awTabContainerController
                                 *
                                 * @return {Void}
                                 */
                                scope.setTabs = function() {
                                    scope.oldWidth = null;
                                    scope.oldFirst = null;

                                    scope.refreshCheck = setInterval( function() {
                                        scope.checkResize();
                                    }, 1000 );

                                    scope.$on( '$destroy', function() {
                                        // /**
                                        // * *** Important Debug Output *** Please keep this block (even if it's
                                        // commented out)
                                        // */
                                        // console.log('awTabContainerController: Destroy scope=' + scope.$id);

                                        if( ngModule.isDefined( scope.refreshCheck ) ) {
                                            clearInterval( scope.refreshCheck );
                                        }
                                        scope.refreshCheck = null;
                                        $element.remove();
                                        $element = null;
                                    } );
                                };

                                if( !ngModule.isDefined( scope.refreshCheck ) ) {
                                    scope.setTabs();
                                }
                            }
                        };
                    } ] );

        /**
         * Inner tab directive that builds the tab list.
         *
         * @member aw-tab
         * @memberof NgElementDirectives
         *
         * @param {AngularService} $timeout -
         *
         * @return {Void}
         */
        app.directive( 'awTab', [ '$timeout', function( $timeout ) {
            return {
                restrict: 'E',
                require: "^awTabContainer",
                templateUrl: app.getBaseUrlPath() + "/html/NgAwTab.html",
                scope: {
                    tabModel: "="
                },
                link: function( scope, $element, attrs, tabContainerCtrl ) {
                    $timeout( function() {
                        if( scope.tabModel.selectedTab === true ) {
                            tabContainerCtrl.updateSelectedTab( scope.tabModel );
                        }
                        // tabContainerCtrl.checkInitialSelection();
                        // Updates the selected tab
                        // The change will be picked up by the watch
                        scope.selectCurrentTab = function() {
                            scope.tabModel.selectedTab = true;
                            tabContainerCtrl.updateSelectedTab( scope.tabModel );
                        };
                    }, true );
                    scope.$on( '$destroy', function() {
                        $element.remove();
                        // $element = null;
                    } );
                }
            };
        } ] );

        var exports = {};

        /**
         * Array of parameters used in calls to 'addTabObject' made BEFORE the call to 'initTabWidget' is used to
         * initialized the internal structures of the 'TabWidget'.
         * <P>
         * Note: This can happen when multiple GWT-side functions are used to async load the NgTab module.
         *
         * @private
         */
        exports._pendingAddTabs = [];

        /**
         * Initialize (i.e. 'bootstrap') the angular system and create an angular controller on a new 'child' of the
         * given 'parent' element.
         *
         * @param {Element} parentElement - The DOM element the controller and 'inner' HTML content will be added to.
         *            <P>
         *            Note: All existing 'child' elements of this 'parent' will be removed.
         *
         * @param {Callback} apiFn - API for call backs from this controller.
         */
        exports.initTabWidget = function( parentElement, apiFn ) {
            /**
             * Create an 'outer' <DIV> (to hold the given 'inner' HTML) and create the angular controller on it.
             * <P>
             * Remove any existing 'children' of the given 'parent'
             * <P>
             * Add this new element as a 'child' of the given 'parent'
             * <P>
             * Include the DOM elements into the AngularJS system for AW and set the callback API function.
             */
            var ctrlElement = $( '<div ng-controller="awTabController"/>' );

            ctrlElement
                .html( "<aw-tab-container><aw-tab tab-model='tabModel' ng-repeat='tabModel in tabsModel'/></aw-tab-container>" );

            $( parentElement ).empty();
            $( parentElement ).append( ctrlElement );

            awInclude( parentElement, ctrlElement );

            var contrScope = ngModule.element( ctrlElement ).scope();

            if( contrScope ) {
                contrScope.setCallbackApi( apiFn );

                /**
                 * Check if there were any calls to 'addTabObject' made before 'initTabWidget'<BR>
                 * If so: Add those pending tabs additions now.
                 */
                if( exports._pendingAddTabs.length > 0 ) {
                    for( var i = 0; i < exports._pendingAddTabs.length; i++ ) {
                        var params = exports._pendingAddTabs[i];

                        exports.addTabObject( params.parentElement, params.pageId, params.pageTitle, params.selected );
                    }

                    exports._pendingAddTabs = [];
                }
            }
        };

        /**
         * Data object used to hold id/state for a single Tab.
         *
         * @constructor NgTabItem
         *
         * @param {String} pageId - The corresponding page Id.
         *
         * @param {String} pageTitle - The tab name for display.
         *
         * @param {boolean} isSelected - Set tab as selected. Only ever set one tab as selected.
         */
        exports.NgTabItem = function( pageId, pageTitle, isSelected ) {
            this.pageId = pageId;
            this.name = pageTitle;
            this.selectedTab = isSelected;
            this.displayTab = true;
            this.classValue = "aw-base-tabTitle";
        };

        /**
         * Add a tab to the Tab Bar
         *
         * @param {Element} parentElement - The DOM element to retrieve scope.
         */
        exports.addTabObject = function( parentElement, pageId, pageTitle, selected ) {
            var contrScope = ngModule.element( parentElement.firstChild ).scope();

            if( contrScope ) {
                var tabItem = new exports.NgTabItem( pageId, pageTitle, selected );

                contrScope.addTab( tabItem );
            } else {
                /**
                 * The 'initTabWidget' must not have been called yet. Buffer the parameters of the new tab until things
                 * get initialized.
                 */
                exports._pendingAddTabs.push( {
                    parentElement: parentElement,
                    pageId: pageId,
                    pageTitle: pageTitle,
                    selected: selected
                } );
            }
        };

        /**
         * Set selection on a tab.
         *
         * @param {Element} parentElement - The DOM element to retrieve scope.
         *
         * @param {Number} pageId - PageId of tab to be selected.
         */
        exports.updateSelectedTab = function( parentElement, pageId ) {
            var contrScope = ngModule.element( parentElement.firstChild ).scope();

            if( contrScope ) {
                contrScope.updateSelectedTabById( pageId );
            }
        };

        /**
         * Clear Tabs.
         *
         * @param {Element} parentElement - The DOM element to retrieve scope.
         */
        exports.clearTabs = function( parentElement ) {
            var contrScope = ngModule.element( parentElement.firstChild ).scope();

            if( contrScope ) {
                contrScope.clearTabs();
            }
        };

        /**
         * Called when the hosting GWT TabWidget is 'unLoaded'. This method will call $destroy on the AngularJS 'scope'
         * associated with the tab container's ng-controller.
         * <P>
         * Note: *** No further use of this controller is allowed (or wise) ***
         *
         * @param {Element} parentElement - The DOM element to retrieve scope.
         */
        exports.unLoadTabContainer = function( parentElement ) {
            var contrScope = ngModule.element( parentElement.firstChild ).scope();
            if( contrScope ) {
                contrScope.$destroy();
            }
        };

        /**
         * Return the object that defines the public API of this module.
         */
        return exports;
        // End RequireJS Define
    } );
