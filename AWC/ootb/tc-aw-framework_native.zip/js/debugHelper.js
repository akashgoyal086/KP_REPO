//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 onmousedown
 */

define([ 'jquery' ], function($) {
    'use strict';

    /**
     */
    var lengthOf = function(object) {
        var element_count = 0;
        for ( var e in object) {
            if (object.hasOwnProperty(e)) {
                element_count++;
            }
        }
        return element_count;
    };

    /**
     * Logs all JQuery cache objects created by AngularJS.
     */
    var logCachedObjects = function() {
        var scopeCnt = 0;
        var ngccCnt = 0;
        var scopeArray = [];

        for ( var num in $.cache) {
            if ($.cache.hasOwnProperty(num)) {
                var obj = $.cache[num];
                if (obj.hasOwnProperty('data')) {
                    var data = obj.data;
                    var scp = null;
                    var curScopes = [];
                    if (data.hasOwnProperty('$scope')) {
                        scp = data.$scope;
                        if (data.hasOwnProperty('$ngControllerController')) {
                            ngccCnt++;
                        }
                    }

                    if (data.hasOwnProperty('$isolateScope')) {
                        scp = data.$isolateScope;
                    }

                    if (scp) {
                        scopeCnt++;
                        // list the chain all the way up
                        var curScp = scp;
                        while (curScp) {
                            curScopes.push(curScp.$id);
                            curScp = curScp.$parent;
                        }
                        scopeArray.push(curScopes);
                    }
                }
            }
        }

        // Attempt to weed out scopes that are in other, longer chains
        for (var i = 0; i < scopeArray.length; i++) {
            var curChain = scopeArray[i];
            var headScope = curChain[0];
            var bFound = false;
            for (var j = 0; j < scopeArray.length; j++) {
                if (j === i) {
                    continue;
                }

                var checkChain = scopeArray[j];
                for (var k = 0; k < checkChain.length; k++) {
                    if (headScope === checkChain[k]) {
                        bFound = true;
                        break;
                    }
                }
            }

            if (!bFound) {
                var msg = "Scope Chain: ";
                for (var n = 0; n < curChain.length; n++) {
                    msg += curChain[n] + "->";
                }

                console.log(msg);
            }
        }
        if (ngccCnt > 0) {
            console.log("$ Cached NgControllerControllers #: " + ngccCnt);
        }

        if (scopeCnt > 0) {
            console.log("$ Cached Scopes #: " + scopeCnt);
        }

    };

    /**
     * Ignore the 'readonly' warning.
     */
    onmousedown = function() { //jshint ignore:line
        if ($.cache) {
            console.log("$ cache size:" + lengthOf($.cache));
            logCachedObjects();
        }
    };
});
