//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define
 */
/**
 * @module js/NgValidationService
 */
define( [ 'app', 'angular', 'jquery', 'jqueryui', 'js/localeService', 'js/dateTimeService' ], function( app, ngModule, $ ) {
    'use strict';

    /**
     * User input Validation Service Object.
     *
     * @constructor ValidationService
     *
     * @param {localeService} localeSvc -
     *
     * @param {dateTimeService} dateTimeSvc -
     */
    var ValidationService = function( localeSvc, dateTimeSvc ) {
        var self = this;

        /**
         * Integer minimum value, which is equal to Java Integer's minimum value
         */
        var _integerMinValue = -2147483648;

        /**
         * Integer maximum value, which is equal to Java Integer's maximum value
         */
        var _integerMaxValue = 2147483647;

        /**
         * Remove all characters from the given string that are not valid for a double value.
         * <P>
         * Note: If there is any failure in validation, the details of which will appear as a non-null value on the
         * 'scope.errorApi.errorMsg' property.
         *
         * @memberof module:NgValidationService~ValidationService
         *
         * @param {String} clean - String to 'clean'.
         *
         * @returns {String} The given string value now cleaned of any non-numeric characters.
         */
        var _parseDoubleCharacters = function( clean ) {
            var charArray = [ '.', '-', '+', 'e' ];

            for( var i = 0; i < charArray.length; i++ ) {
                var check = clean.split( charArray[i] );

                if( !ngModule.isUndefined( check[1] ) ) {
                    clean = check[0] + charArray[i] + check[1];
                }
            }

            return clean;
        };

        /**
         * @memberof module:NgValidationService~ValidationService
         *
         * @param {Function} msgFn - Function to call that will set the error message
         */
        var _setErrorText = function( scope, msgFn ) {
            scope.errorApi.errorMsg = '...details pending';
            var localTextBundle = localeSvc.getLoadedText();
            if( localTextBundle ) {
                msgFn( localTextBundle );
            } else {
                localeSvc.getTextPromise().then( msgFn( localTextBundle ) );
            }
        };

        /**
         * Set error message to overlay object and calls back to gwt land to fire validation error event.
         *
         * @memberof module:NgValidationService~ValidationService
         *
         * @param {String} msg - error message
         */
        self.setErrorMessage = function( scope, msg ) {
            /**
             * Don't clear error property if the server validation flag is true. Set client side error message only if
             * server validation flag is false OR when server validation flag is true and client side message is not
             * null/empty.
             */
            if( ( scope.prop.hasServerValidationError && msg ) || !scope.prop.hasServerValidationError ) {
                scope.errorApi.errorMsg = msg;
                scope.prop.error = msg;
                // callback to gwt land to fire validation error event
                if( scope.prop.propApi && scope.prop.propApi.fireUIValidationErrorEvent ) {
                    scope.prop.propApi.fireUIValidationErrorEvent( scope.prop.error );
                }
            }
        };

        /**
         * Process the value and checks whether it is a valid double value, if its not valid double then throw an error.
         * <P>
         * Note: If there is any failure in validation, the details of which will appear as a non-null value on the
         * 'scope.errorApi.errorMsg' property.
         *
         * @memberof module:js/NgValidationService~ValidationService
         *
         * @param {NgScope} scope - The AngularJS 'scope' containing the property to interact with.
         *
         * @param {NgModelController} ngModelCtrl - The (optional) NgModelController to interact with in case the UI
         *            needs to be updated.
         *
         * @param {String} value - String to test for validity.
         *
         * @returns {Number} Same as given input value with any invalid characters removed.
         */
        self.checkDouble = function( scope, ngModelCtrl, value ) {
            var pattern = /[^\+|\-|0-9\.|e]/g;
            var clean = value;

            if( !scope.prop.hasLov ) {
                clean = value.replace( pattern, '' );
                clean = _parseDoubleCharacters( clean );
            }

            if( ngModelCtrl && value !== clean ) {
                ngModelCtrl.$setViewValue( clean );
                ngModelCtrl.$render();
            }

            // check if value is valid number, if not valid then throw error
            if( isFinite( clean ) ) {
                // nullify error and since it is a valid number convert it to number
                // watcher function will sync prop.error too, but the async function can happen after
                // gwt's setError function which reverts the errorMsg to the previous error.
                self.setErrorMessage( scope, null );

                // convert it to number type only when value is not null or not empty
                if( clean !== null && clean !== '' ) {
                    clean = Number( clean );
                }
            } else {
                _setErrorText( scope, function( localTextBundle ) {
                    var msg = localTextBundle.INVALID_DOUBLE;
                    msg = msg.replace( '{0}', clean );
                    self.setErrorMessage( scope, msg );
                } );
            }

            return clean;
        };

        /**
         * Process the value and checks whether it is a valid integer value, if its not a valid integer then report an
         * error.
         * <P>
         * Note: If there is any failure in validation, the details of which will appear as a non-null value on the
         * 'scope.errorApi.errorMsg' property.
         *
         * @memberof module:js/NgValidationService~ValidationService
         *
         * @param {NgScope} scope - The AngularJS 'scope' containing the property to interact with.
         *
         * @param {NgModelController} ngModelCtrl - The (optional) NgModelController to interact with in case the UI
         *            needs to be updated.
         *
         * @param {String} value - String to test for validity.
         *
         * @returns {Number} Same as given input value with any invalid characters removed.
         */
        self.checkInteger = function( scope, ngModelCtrl, value ) {
            var pattern = /[^\+|\-|0-9]/g;
            var clean = value;

            if( !scope.prop.hasLov ) {
                clean = value.replace( pattern, '' );
            }

            if( ngModelCtrl && value !== clean ) {
                ngModelCtrl.$setViewValue( clean );
                ngModelCtrl.$render();
            }

            // check if value is valid number, if not valid then throw error
            if( isFinite( clean ) ) {
                if( Number( clean ) < _integerMinValue || Number( clean ) > _integerMaxValue ) {
                    _setErrorText( scope, function( localTextBundle ) {
                        var msg = localTextBundle.INTEGER_OUT_OF_RANGE;

                        msg = msg.replace( '{0}', clean );
                        msg = msg.replace( '{1}', _integerMinValue.toString() );
                        msg = msg.replace( '{2}', _integerMaxValue.toString() );

                        self.setErrorMessage( scope, msg );
                    } );
                } else {
                    // nullify error and since it is a valid number convert it to number
                    // watcher function will sync prop.error too, but the async function can happen after
                    // gwt's setError function which reverts the errorMsg to the previous error.
                    self.setErrorMessage( scope, null );

                    // convert it to number type only when value is not null or not empty
                    if( clean !== null && clean !== '' ) {
                        clean = Number( clean );
                    }
                }
            } else {
                _setErrorText( scope, function( localTextBundle ) {
                    var msg = localTextBundle.INVALID_INTEGER;
                    msg = msg.replace( '{0}', clean );

                    self.setErrorMessage( scope, msg );
                } );
            }

            return clean;
        };

        /**
         * Process the value and checks whether it can be successfully converted into a date, if its not a valid date
         * then report an error. Note: If there is any failure in validation, the details of which will appear as a
         * non-null value on the 'scope.errorApi.errorMsg' property.
         *
         * @memberof module:js/NgValidationService~ValidationService
         *
         * @param {NgScope} scope - The AngularJS 'scope' containing the property to interact with.
         *
         * @param {String} dateValue - String value to test.
         *
         * @param {Boolean} initErrorMsg - TRUE if the 'scope.errorApi.errorMsg' should be set to NULL before the check.
         *
         * @returns {String} The given string value.
         */
        self.checkDate = function( scope, dateValue, initErrorMsg ) {
            if( initErrorMsg ) {
                scope.errorApi.errorMsg = null;
            }

            if( dateValue ) {
                try {
                    var fmt = dateTimeSvc.getDateFormat();

                    $.datepicker.parseDate( fmt, dateValue );

                    scope.errorApi.errorMsg = null; // It's a valid date, clear the error message
                } catch( ex ) {
                    _setErrorText( scope, function( localTextBundle ) {
                        var msg = localTextBundle.INVALID_DATE;

                        msg = msg.replace( '{0}', dateTimeSvc.getDateFormatPlaceholder() );

                        scope.errorApi.errorMsg = msg;
                    } );
                }
            }

            return dateValue;
        };

        /**
         * Process the value and checks whether it can be successfully converted into a date, if its not a valid date
         * then report an error.
         * <P>
         * Note: This method will 1st clear any existing value in the 'scope.errorApi.errorMsg' property.
         * <P>
         * Note: If there is any failure in validation, the details of which will appear as a non-null value on the
         * 'scope.errorApi.errorMsg' property.
         *
         * @memberof module:js/NgValidationService~ValidationService
         *
         * @param {NgScope} scope - The AngularJS 'scope' containing the property to interact with.
         *
         * @param {Date} dateObject - JS Date object to test.
         *
         * @returns {Date} The given dateObject.
         */
        self.checkDateTime = function( scope, dateObject ) {
            scope.errorApi.errorMsg = null;

            if( dateObject ) {
                var dateValue = dateTimeSvc.formatDate( dateObject );

                self.checkDate( scope, dateValue, false );

                if( !scope.errorApi.errorMsg ) {
                    var timeValue = dateTimeSvc.formatTime( dateObject );

                    self.checkTime( scope, timeValue, false );
                }
            }

            return dateObject;
        };

        /**
         * Process the value and checks whether it can be successfully converted into a date, if its not a valid date
         * then report an error.
         * <P>
         * Note: If there is any failure in validation, the details of which will appear as a non-null value on the
         * 'scope.errorApi.errorMsg' property.
         *
         * @memberof module:js/NgValidationService~ValidationService
         *
         * @param {NgScope} scope - The AngularJS 'scope' containing the property to interact with.
         *
         * @param {String} dateValue - Date string value to test.
         *
         * @param {String} timeValue - Time string value to test.
         */
        self.checkDateTimeValue = function( scope, dateValue, timeValue ) {
            scope.errorApi.errorMsg = null;

            self.checkDate( scope, dateValue, false );

            if( !scope.errorApi.errorMsg ) {
                self.checkTime( scope, timeValue, false );
            }
        };

        /**
         * Process the value and checks whether it can be successfully converted into a time, if its not a valid time
         * then report an error. Note: If there is any failure in validation, the details of which will appear as a
         * non-null value on the 'scope.errorApi.errorMsg' property.
         *
         * @memberof module:js/NgValidationService~ValidationService
         *
         * @param {NgScope} scope - The AngularJS 'scope' containing the property to interact with.
         *
         * @param {String} timeValue - String value to test.
         *
         * @param {Boolean} initErrorMsg - TRUE if the 'scope.errorApi.errorMsg' should be set to NULL before the check.
         *
         * @returns {String} The given string timeValue.
         */
        self.checkTime = function( scope, timeValue, initErrorMsg ) {
            if( initErrorMsg ) {
                scope.errorApi.errorMsg = null;
            }

            if( timeValue ) {
                /**
                 * Remove any trailing ':' before trying to match the pattern
                 */
                var timeValueLcl = timeValue;

                if( timeValueLcl.length > 0 && timeValueLcl.charAt( timeValueLcl.length - 1 ) === ':' ) {
                    timeValueLcl = timeValueLcl.substring( 0, timeValueLcl.length - 1 );
                }

                /**
                 * Attempt to convert this string into a JS Date object.
                 */
                var timeObject = dateTimeSvc.getDateFromTimeValue( timeValueLcl );

                if( timeObject ) {
                    scope.errorApi.errorMsg = null; // It's a valid date, clear the error message
                } else {
                    _setErrorText( scope, function( localTextBundle ) {
                        var msg = localTextBundle.INVALID_TIME;

                        msg = msg.replace( '{0}', dateTimeSvc.getTimeFormatPlaceholder() );

                        scope.errorApi.errorMsg = msg;
                    } );
                }
            }

            return timeValue;
        };
    };

    /**
     * Registered an instance of {@linkcode module:js/localeService|localeService} as with the application module's
     * service factory.
     *
     * @param localeSvc
     * @param dateTimeSvc
     *
     * @returns {ValidationService}
     */
    app.factory( 'ValidationService', [ 'localeService', 'dateTimeService', function( localeSvc, dateTimeSvc ) {
        return new ValidationService( localeSvc, dateTimeSvc );
    } ] );

    // End RequireJS Define
} );
