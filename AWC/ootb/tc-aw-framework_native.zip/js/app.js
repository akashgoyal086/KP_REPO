//@<COPYRIGHT>@
//==================================================
//Copyright 2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 require
 */

/**
 * This module represents the primary 'AngularJS application module'.
 *
 * @module js/app
 */
define(
    [ 'angular', 'angulartemplatecache', 'js/eventBus', 'ui.grid' ],
    function( ngModule, ngTemplateCache, eventBus ) {
        'use strict';

        /**
         * Start up AngularJS
         * <P>
         * For now we have to add the ng module dependencies for uiGrid here, as there is no other mechanism to pull
         * them in dynamically yet.
         */
        var app = ngModule.module( 'AwRootAppModule',
            [ 'ui.grid', 'ui.grid.selection', 'ui.grid.resizeColumns', 'ui.grid.moveColumns', 'ui.grid.pinning',
                'ui.grid.cellNav', 'ui.grid.autoResize', 'ui.grid.infiniteScroll' ] );
        app.eventBus = eventBus;

        var exports = app;
        var baseUrlPath = null;

        // set solution definition and change browser title
        // string insertion in war construction
        var solutionName = "Teamcenter";
        var solutionDef = '{{solutionDef}}';
        if( solutionDef ) {
            solutionName = solutionDef.solutionName;
        }
        document.title = "Starting " + solutionName;

        /**
         * Locale values set up-to-date once login is complete.
         * <P>
         * Note: Until login, the default values we be as shown here.
         */
        exports.localeInfo = {
            locale: 'en_US',
            is12HrFormat: false,
            sessionDateTimeFormat: 'dd-MMM-yyyy HH:mm',
            sessionDateFormat: 'dd-MMM-yyyy',
            sessionTimeFormat: 'HH:mm'
        };

        /**
         * Set the solution definition
         *
         * @param {Object} solution - the solution definition
         */
        exports.setSolutionDef = function( solution ) {
            solutionDef = solution;
        };

        /**
         * Get the solution definition
         *
         * @returns {Object} solution - the solution definition
         */
        exports.getSolutionDef = function() {
            return solutionDef;
        };

        /**
         * Set the base url path
         *
         * @param {String} url - The url path.
         */
        exports.setBaseUrlPath = function( url ) {
            baseUrlPath = url;
        };

        /**
         * Get the base url path
         *
         * @returns {String} url - The url path.
         */
        exports.getBaseUrlPath = function() {
            return baseUrlPath ? baseUrlPath : 'thinclient';
        };

        /**
         * Get some providers injected and save reference to them.
         *
         * @param {Object} $locationProvider
         */
        app
            .config( [
                '$locationProvider',
                '$controllerProvider',
                '$compileProvider',
                '$filterProvider',
                '$provide',
                function( $locationProvider, $controllerProvider, $compileProvider, $filterProvider, $provide ) {
                    app.controllerProvider = $controllerProvider;
                    app.controller = $controllerProvider.register;
                    app.directive = $compileProvider.directive;
                    app.filter = $filterProvider.register;
                    app.factory = $provide.factory;
                    app.service = $provide.service;

                    /**
                     * Add the postal 'event bus' to the root scope.
                     *
                     * @param {Object} $delegate - The original service instance, which can be monkey patched,
                     *            configured, decorated or delegated to.
                     *
                     * @returns {Object} The same $delegate object as specified to this function.
                     */
                    $provide.decorator( '$rootScope', [ '$delegate', function( $delegate ) {
                        Object.defineProperty( $delegate.constructor.prototype, '$eventBus', {
                            value: app.eventBus,
                            enumerable: false
                        } );

                        return $delegate;
                    } ] );

                    $provide
                        .factory(
                            'exceptionLoggingService',
                            [
                                '$log',
                                function( $log ) {
                                    function error( exception, cause ) {
                                        var invalidUserSession = exception &&
                                            exception.cause &&
                                            exception.cause['.QName'] === 'http://teamcenter.com/Schemas/Soa/2006-03/Exceptions.InvalidUserException';
                                        if( !invalidUserSession ) {
                                            $log.error.apply( $log, arguments );
                                        }
                                    }
                                    return error;
                                } ] );

                    $provide.provider( '$exceptionHandler', {
                        $get: [ 'exceptionLoggingService', function( exceptionLoggingService ) {
                            return exceptionLoggingService;
                        } ]
                    } );

                } ] );

        /**
         * Load a map of all HTML templates.
         *
         * @param {Object} $templateCache - The JSON container with all AngularJS templates loaded into it.
         */
        app.run( [ '$templateCache', '$injector', function( $templateCache, $injector ) {
            app.injector = $injector; //need to assign injector here because providers are not instantiated until run
            ngTemplateCache.init( $templateCache );
        } ] );

        return exports;
    } );
