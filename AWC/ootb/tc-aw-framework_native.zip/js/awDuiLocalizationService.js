// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */
define( [ 'app', 'angular', 'lodash', 'js/localeService' ], function( app, ngModule, _ ) {
    'use strict';

    /*
     * cached reference to the angular $q or promise service
     */
    var _$q = null;

    /**
     * cached reference to the _locale service
     */
    var _localeService = null;
    var exports = {};

    /**
     * Populate I18n map.
     *
     * @param{Object} I18n data from ViewModel json
     * @returns {Promise} an angular promise
     */
    exports.populateI18nMap = function( i18nObjects ) {
        var deferred = _$q.defer();
        if( !i18nObjects ) {
            deferred.resolve();
        }
        var i18n = {};
        var allPromises = [];

        for( var key in i18nObjects ) {
            var promise = getLocalizedText( key, i18nObjects[key] );
            then( i18n, key, promise );
            allPromises.push( promise );
        }
        _$q.all( allPromises ).then( function( xx ) {
            deferred.resolve( i18n );
        } );

        return deferred.promise;
    };

    /**
     * A helper method to attach a then(...) to provided promise
     *
     * @param {Object} i18n the object holding i18n key object map
     * @param {String} key  the key into key map
     * @param {Promise} promise object
     */
    var then = function( i18n, key, promise ) {
        promise.then( function( localizedText ) {
            i18n[key] = localizedText;
        } );
    };

    /**
     * Get a localized text for provided text from provided bundles
     *
     * @param {String} englishText
     * @param {Array} bundles
     * @returns a promise
     */
    var getLocalizedText = function( englishText, bundles ) {
        var deferred = _$q.defer();
        getLocalizedTextFormBundlesRecursively( englishText, bundles, deferred );
        return deferred.promise;
    };

    /**
     * Get a localized text for provided text from provided bundles, recursively if not found in previous bundle.
     *
     * @param {String} englishText
     * @param {Array} bundles
     * @param {Object} deferred
     * @returns a promise
     *
     */
    var getLocalizedTextFormBundlesRecursively = function( englishText, bundles, deferred ) {
        if( bundles.length === 0 ) {
            deferred.resolve();
        } else {
            getLocalizedTextFromOneBundle( englishText, bundles.shift() ).then( function( localizedText ) {
                if( localizedText !== undefined ) {
                    deferred.resolve( localizedText );
                } else {
                    getLocalizedTextFormBundlesRecursively( englishText, bundles, deferred );
                }
            } );
        }
    };

    /**
     * Get a localized text for provided text from provided bundle.
     *
     * @param {String} englishText
     * @param {Object} bundle
     * @returns a promise
     *
     */
    var getLocalizedTextFromOneBundle = function( englishText, bundle ) {
        var deferred = _$q.defer();
        _localeService.getTextPromise( app.getBaseUrlPath() + '/i18n/' + bundle ).then( function( textBundle ) {
            deferred.resolve( textBundle[englishText] );
        } );
        return deferred.promise;
    };
    /**
     * Register this service with the AngularJS application.
     */
    app.factory( 'awDuiLocalizationService', [ '$q', 'localeService', function( $q, localeService ) {
        _$q = $q;
        _localeService = localeService;
        return exports;
    } ] );

    return exports;
} );
