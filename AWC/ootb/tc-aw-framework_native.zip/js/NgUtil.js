//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 navigator
 */

/**
 * This service is for utility functions that we want available, but don't make sense as part of the other property
 * render JS files
 *
 * @module js/NgUtilService
 */
define( [ //
'app', //
'angular', //
'jquery' ], //
function( app, ngModule, $ ) {
    'use strict';

    var UtilsService = function() {
        var self = this;

        /**
         * Determines if we're currently running on a mobile OS
         *
         * @memberof module:js/NgUtil~UtilsService
         *
         * @returns {Boolean} 'true' if the browser is being run on a mobile device.
         */
        self.isMobileOS = function() {
            if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test( navigator.userAgent ) ) {
                return true;
            }
            return false;
        };

        /**
         * Determines if we're running on iOS
         *
         * @memberof module:js/NgUtil~UtilsService
         *
         * @returns {Boolean} 'true' if the browser is being run on an Apple iOS device..
         */
        self.isiOS = function() {
            if( /iPhone|iPad|iPod/i.test( navigator.userAgent ) ) {
                return true;
            }
            return false;
        };

        /**
         * Determines if element has scrollBar by comparing the scrollHeight with clientHeight
         *
         * @memberof module:js/NgUtil~UtilsService
         *
         * @returns {Boolean} 'true' if scrollBar is present
         */
        self.hasScrollBar = function( element ) {
            if( element && element.get( 0 ) ) {
                // removing 10 pixels from scrollHeight and comparing because in IE even when there is
                // no scroll bar it shows couple of pixels difference between scrollHeight and clientHeight.
                return element.get( 0 ).scrollHeight - 10 > element.get( 0 ).clientHeight;
            }
            return false;
        };

        /**
         * The about the input box is allowed to move to the left/right before the UI popup (e.g. calendar, LOV ) is
         * collapsed/hidden.
         *
         * @memberof module:js/NgListService~ListService
         */
        self.MAX_X = 40;

        /**
         * The about the input box is allowed to move to the up/down before the UI popup (e.g. calendar, LOV ) is
         * collapsed/hidden.
         *
         * @memberof module:js/NgListService~ListService
         */
        self.MAX_Y = 40;

        self.handleScroll = function( scope, $element, scrollNamespace, cb ) {
            // Check for mobile OS
            if( !self.isMobileOS() ) {
                // Get the closest scroll panel
                scope.$scrollPanel = $element.closest( '.aw-base-scrollPanel' );
                // When scroll element is found and it doesn't have scrollBar, then traverse through the DOM until
                // '.aw-layout-panelMain' and see if there are any scroll elements who has scrollBar
                if( scope.$scrollPanel && !self.hasScrollBar( scope.$scrollPanel ) ) {
                    var scrollElement = scope.$scrollPanel.parentsUntil( $( '.aw-layout-panelMain' ), '.aw-base-scrollPanel' )
                        .filter( function() {
                            return self.hasScrollBar( $( this ) );
                        } );

                    if( scrollElement.hasClass( 'aw-base-scrollPanel' ) ) {
                        scope.$scrollPanel = scrollElement;
                    }
                }

                // Add scroll listener only when scroll bar is present for the element
                if( scope.$scrollPanel && self.hasScrollBar( scope.$scrollPanel ) ) {
                    var oldX = scope.$scrollPanel.scrollTop();
                    var oldY = scope.$scrollPanel.scrollLeft();

                    var eventName = 'scroll.' + scrollNamespace;
                    scope.$scrollPanel.on( eventName, function() {
                        if( scope.$scrollPanel ) {
                            var curX = scope.$scrollPanel.scrollTop();
                            var curY = scope.$scrollPanel.scrollLeft();

                            if( Math.abs( oldX - curX ) > self.MAX_X || Math.abs( oldY - curY ) > self.MAX_Y ) {
                                oldX = curX;
                                oldY = curY;
                                cb();
                            }
                        }
                    } );
                }
            }
        };

        /**
         * Check whether we are running in IExxxx
         *
         * @memberof module:js/NgUtil~UtilsService
         *
         * @return TRUE if we are running in IExxxx
         */
        self.isIE = function() {
            return navigator.userAgent.indexOf( 'Trident' ) !== -1  && navigator.userAgent.indexOf( 'MSIE' ) === -1;
        };

        /**
         * Check whether the given value is a valid number
         *
         * @memberof module:js/NgUtil~UtilsService
         *
         * @return TRUE if input value is valid number
         */
        self.isValidNumber = function( value ) {
            if( value !== null && value !== undefined &&
                isFinite( value ) ) {
                return true;
            }
            return false;
        };

        /**
         * Check whether the given element exists
         *
         * @return TRUE if element exists
         */
        self.ifElementExists = function( element ) {
            if( element && element.length ) {
                return true;
            }
            return false;
        };

        /**
         * Check to see if the event is a result of a click in the element referenced in the query string
         *
         * There is no single way to determine what the target is, rather it varies based on the browser
         *
         * @param blurEvent The blur event
         * @param {String} queryString jQuery string to identify the element we're checking as the potential target
         *
         *  @return TRUE if the query string finds an element that matches in the click target, FALSE otherwise
         */
        self.isBlurTarget = function(blurEvent, queryString) {
            var isTarget = ($(blurEvent.relatedTarget).closest(queryString)).length > 0;  // Chrome Check

            if (!isTarget && blurEvent.originalEvent && blurEvent.originalEvent.explicitOriginalTarget)
            {
                isTarget = ($(blurEvent.originalEvent.explicitOriginalTarget).closest(queryString)).length > 0;  // Firefox Check
            }

            if (!isTarget)
            {
                isTarget = ($(document.activeElement).closest(queryString)).length > 0;  // IE11
            }
            return isTarget;
        };
    };

    app.factory( 'UtilsService', function() {
        return new UtilsService();
    } );

} ); // End RequireJS Define
