// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

define(
    [ 'app',  'angular', 'lodash', 'js/panelViewModelService', 'js/localeService', 'js/appCtxService', 'js/eventBus' ],
    function( app, ngModule, _, panelViewModelService, localeService, appCtxService, eventBus ) {
        'use strict';


        app.directive( 'awPanelContent', [ 'panelViewModelService', 'appCtxService',
            function( panelViewModelSvc, appCtxService ) {
                return {
                    restrict: 'E',
                    transclude: true,
                    template: '<div class="aw-layout-panelContent" ng-transclude></div>',
                    controller: function( $scope, $element ) {
                        $scope.data = panelViewModelSvc.data;
                        $scope.ctx = appCtxService.ctx;
                    },
                    replace: true
                };
            } ] );

        app
            .directive(
                'awPanelImage',
                [ function() {
                    return {
                        restrict: 'E',
                        scope: {
                            source: '='
                        },
                        template: '<div class="aw-xrt-thumbnailImagePanel aw-theme-xrtPanel"><img ng-src="{{source}}" class="aw-xrt-thumbnailImage"></div>',
                        replace: true
                    };
                } ] );
        app.directive( 'awPanelBreak', [ function() {
            return {
                restrict: 'E',
                template: '<div class="aw-xrt-sectionBreak"></div>',
                replace: true
            };
        } ] );
        app.directive( 'awPanelHeader', [ 'panelViewModelService', 'appCtxService',
            function( panelViewModelSvc, appCtxService ) {
                return {
                    restrict: 'E',
                    transclude: true,
                    template: '<div class="aw-layout-panelHeader" ng-transclude></div>',
                    controller: function( $scope, $element ) {
                        $scope.data = panelViewModelSvc.data;
                        $scope.ctx = appCtxService.ctx;
                    },
                    replace: true

                };
            } ] );
        app.directive( 'awPanelBody', [ 'panelViewModelService', 'appCtxService',
            function( panelViewModelSvc, appCtxService ) {
                return {
                    restrict: 'E',
                    transclude: true,
                    template: '<form name="awPanelBody" class="aw-layout-panelBody aw-base-scrollPanel" ng-transclude novalidate></form>',
                    controller: function( $scope, $element ) {
                        $scope.data = panelViewModelSvc.data;
                        $scope.ctx = appCtxService.ctx;
                    },
                    replace: true
                };
            } ] );
        app.directive( 'awPanelFooter', [ 'panelViewModelService', 'appCtxService',
            function( panelViewModelSvc, appCtxService ) {
                return {
                    restrict: 'E',
                    transclude: true,
                    template: '<div class="aw-layout-panelFooter" ng-transclude></div>',
                    controller: function( $scope, $element ) {
                        $scope.data = panelViewModelSvc.data;
                        $scope.ctx = appCtxService.ctx;
                    },
                    replace: true
                };
            } ] );
        app.directive( 'awPanelButton', [ 'panelViewModelService', function( panelViewModelSvc ) {
            return {
                restrict: 'E',
                transclude: true,
                scope: {
                    action: '@'
                },
                controller: function( $scope ) {
                    $scope.doit = function( action ) {
                        panelViewModelSvc.executeCommand( action, $scope );

                    };
                },
                template: '<button class="aw-base-blk-button" ng-click="doit(action)" ng-transclude ></button>',
                replace: true
            };
        } ] );
        app.directive( 'awPanelWidget', [ 'panelViewModelService', 'appCtxService',
            function( panelViewModelSvc, appCtxService ) {
                return {
                    restrict: 'E',
                    scope: {
                        prop: '=',
                        hint: '@'
                    },
                    controller: function( $scope, $element ) {
                        $scope.data = panelViewModelSvc.data;
                        $scope.ctx = appCtxService.ctx;
                    },
                    templateUrl: app.getBaseUrlPath() + '/html/duiPanelWidget.html'
                };
            } ] );
        app.directive( 'awPanelRadiobutton', [ 'panelViewModelService', function( panelViewModelSvc ) {
            return {
                restrict: 'E',
                scope: {
                    action: '@',
                    prop: '='
                },
                controller: function( $scope ) {
                    $scope.doIt = function( action ) {
                        panelViewModelSvc.executeCommand( action, $scope );
                    };
                },
                templateUrl: app.getBaseUrlPath() + '/html/duiPanelRadiobutton.html'
            };
        } ] );
        app.directive( 'awPanelListbox', [ 'panelViewModelService', function( panelViewModelSvc ) {

            return {
                restrict: 'E',
                scope: {
                    prop: '=',
                    list: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/duiPanelListbox.html',
                controller: function( $scope ) {
                    var utility = {};
                    utility.createLOVOverlayObjectList = function( list ) {
                        var overlayObjectList = [];
                        for( var i in list ) {
                            overlayObjectList.push( utility.createLOVUiOverlayObject( list[i] ) );
                        }
                        return overlayObjectList;
                    };
                    utility.createLOVUiOverlayObject = function( itemName ) {

                        var ret = {
                            propDisplayValue: itemName,
                            propInternalValue: itemName,
                            propDisplayDescription: "",
                            hasChildren: false,
                            children: {},
                            sel: false
                        };
                        return ret;
                    };

                    $scope.prop.lovApi = {};
                    $scope.prop.lovApi.type = "static";

                    $scope.prop.lovApi.getInitialValues = function( filterStr, deferred, name ) {

                        if( !$scope.list ) {
                            $scope.list = [];
                        }
                        var lovObjects = utility.createLOVOverlayObjectList( $scope.list );
                        deferred.resolve( lovObjects );
                    };
                    $scope.prop.lovApi.getNextValues = function( promise ) {
                        // no-op
                        promise.resolve( null );
                    };
                    $scope.prop.lovApi.validateLOVValueSelections = function( value ) {
                        return true;
                    };
                }
            };
        } ] );

        app.directive( 'awPanelSection', [ 'panelViewModelService', 'appCtxService',
            function( panelViewModelSvc, appCtxService ) {
                return {
                    restrict: 'E',
                    transclude: true,
                    scope: {
                        caption: '@',
                        name: '@'
                    },
                    templateUrl: app.getBaseUrlPath() + '/html/duiPanelSection.html',
                    replace: true,
                    controller: function( $scope, $element ) {
                        $scope.data = panelViewModelSvc.data;
                        $scope.ctx = appCtxService.ctx;
                    },
                    link: function( $scope, $element, $attribute ) {
                        var deregister = $scope.$watch( 'data.' + $scope.caption, function( value ) {
                            $scope.caption = value;
                        } );

                        $scope.$on(
                            "$destroy",
                            function handleDestroyEvent() {
                                deregister();
                            }
                        );
                    }
                };
            } ] );
        app.directive( 'visibleWhen', [ function() {
            return {
                restrict: 'A',
                replace: true,
                link: function( scope, element, attr ) {
                    scope.$watch( attr.visibleWhen, function( value ) {
                        element.css( 'display', value ? '' : 'none' );
                    } );
                }
            };
        } ] );

        app.directive( 'awPanel', [ 'panelViewModelService', 'localeService', 'appCtxService',
            function( panelViewModelSvc, localeSvc, appCtxService ) {
                return {
                    restrict: 'E',
                    transclude: true,
                    scope: {
                        caption: '@'
                    },
                    templateUrl: app.getBaseUrlPath() + '/html/duiPanel.html',
                    controller: function( $scope, $element ) {
                        $scope.data = panelViewModelSvc.data;
                        $scope.ctx = appCtxService.ctx;
                    },
                    link: function( $scope, $element, $attribute ) {
                        var deregister = $scope.$watch( 'data.' + $scope.caption, function( value ) {
                            $scope.caption = value;
                        } );
                        $scope.$on(
                            "$destroy",
                            function handleDestroyEvent() {
                                deregister();
                            }
                        );
                        eventBus.publishSoa( "awPanel.reveal", {
                            "scope": $scope
                        } );
                    },
                    replace: true
                };
            } ] );

        app.directive( 'awPanelI18n', [ 'panelViewModelService', function( panelViewModelSvc ) {
            return {
                restrict: 'E',
                link: function( $scope, element, attribute ) {
                    $scope.data = panelViewModelSvc.data;
                    var key = element.text();
                    if( key && key.length !== 0 ) {
                        var localizedText = _.get( $scope.data, key );
                        if( localizedText ) {
                            ngModule.element( element ).text( localizedText );
                        }
                    }
                }
            };
        } ] );
        /**
         * @name awRepeat
         * @restrict Attribute
         * @param {repeat_expression} 'variable: expression'
         * @multiElement
         * @example <aw-div aw-repeat='item : items'></aw-div>
         */
        app.directive( 'awRepeat', function( $compile ) {
            var directiveDefinitionObject = {
                restrict: 'A',
                priority: 9999,
                compile: function( element, attribute ) {

                    function updateElement( repeatExpression ) {
                        var $ele = ngModule.element( element );
                        $ele.removeAttr( 'aw-repeat' );
                        $ele.attr( 'ng-repeat', repeatExpression );
                    }
                    var expression = attribute.awRepeat.trim();
                    // check for 'item : items'
                    if( expression.match( /([a-z]|[A-Z]|$|_).*:.*/g ) ) {
                        expression = expression.replace( ':', 'in' );
                    } else {
                        throw 'Invalid expression:' + expression;
                    }
                    updateElement( expression );
                    return function( $scope, $element, $attrs ) {
                        $compile( $element )( $scope );
                    };
                }
            };
            return directiveDefinitionObject;
        } );

// End RequireJS Define
    } );