// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 localStorage
 */

/**
 * Note: Many of the the functions defined in this module return a {@linkcode module:angujar~Promise|Promise} object.
 * The caller should provide callback function(s) to the 'then' method of this returned object (e.g. successCallback,
 * [errorCallback, [notifyCallback]]). These methods will be invoked when the associated service result is known.
 *
 * @module soa/historyService
 */
define( [ 'app', 'lodash', 'soa/kernel/clientDataModel', 'soa/kernel/soaService', 'soa/dataManagementService' ],
    function( app, _, cdm, soaSvc, dmSvc ) {
        'use strict';

        var exports = {};

        /**
         * Cache of the list array of history objects queried from the server.
         */
        var _historyObjects = [];

        /**
         * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
         *          data is available.
         */
        exports.getHistory = function() {
            return soaSvc.post( 'Internal-AWS2-2012-10-DataManagement', 'getHistory', {} ).then( function( response ) {
                _historyObjects = [];
                var uidsToLoad = [];
                _.forEach( response.historyObjects, function( historyObject ) {
                    _historyObjects.push( cdm.getObject( historyObject.uid ) );
                    uidsToLoad.push( historyObject.uid );
                } );
                if( uidsToLoad.length > 0 ) {
                    return dmSvc.loadObjects( uidsToLoad ).then( function( loadObjectsResponse ) {
                        // Load the required properties for display of the history objects.
                        return dmSvc.getProperties( uidsToLoad, [ 'object_string' ] );
                    } ).then( function( getPropResponse ) {
                        return _historyObjects;
                    } );
                }
                return _historyObjects;
            } );
        };

        /**
         * @param {Array} modelObjs - array of model objects
         */
        exports.updateHistory = function( modelObjs ) {
            if( modelObjs ) {
                var workspaceObjs = [];
                var update = _historyObjects.length === 0;
                _.forEach( modelObjs, function( modelObj ) {
                    if( modelObj && modelObj.modelType && modelObj.modelType.typeHierarchyArray &&
                        modelObj.modelType.typeHierarchyArray.indexOf( 'WorkspaceObject' ) ) {
                        workspaceObjs.push( modelObj );

                        if( !update ) {
                            update = _historyObjects.indexOf( modelObj ) === -1;
                        }
                    }
                } );

                if( update && workspaceObjs.length > 0 ) {
                    return soaSvc.post( 'Internal-AWS2-2012-10-DataManagement', 'updateHistory', {
                        historyInput: {
                            objectsToAdd: workspaceObjs,
                            objectsToRemove: workspaceObjs
                        }
                    } );
                }
            }
        };

        // Listen for when objects are deleted to the CDM
        app.eventBus.subscribeSoa( "cdm.deleted", function( data, envelope ) {
            // If deleted objects are in the history, remove them now.
            if( _historyObjects.length > 0 && data.deletedObjectUids && data.deletedObjectUids.length > 0 ) {
                var toRemove = [];
                _.forEach( _historyObjects, function( obj ) {
                    if( data.deletedObjectUids.indexOf( obj.uid ) > -1 ) {
                        toRemove.push( obj );
                    }
                } );
                if( toRemove.length > 0 ) {
                    soaSvc.post( 'Internal-AWS2-2012-10-DataManagement', 'updateHistory', {
                        historyInput: {
                            objectsToAdd: [],
                            objectsToRemove: toRemove
                        }
                    } );
                }
            }
        } );

        /**
         * @return {ModelObjectArray} An array of the IModelObjects most recently gotten from the server.
         */
        exports.getCachableObjects = function() {
            var modelObjects = [];
            _.forEach( _historyObjects, function( obj ) {
                modelObjects.push( obj );
            } );
            return modelObjects;
        };

        /**
         * Register this service with the AngularJS application.
         *
         * @returns {historyService} Reference to this module's API.
         */
        app.factory( 'soa_historyService', function() {
            return exports;
        } );

        return exports;
    } );