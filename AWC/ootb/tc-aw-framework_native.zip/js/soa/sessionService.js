// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * Note: Many of the the functions defined in this module return a {@linkcode module:angujar~Promise|Promise} object.
 * The caller should provide callback function(s) to the 'then' method of this returned object (e.g. successCallback,
 * [errorCallback, [notifyCallback]]). These methods will be invoked when the associated service result is known.
 *
 * @module soa/sessionService
 */
define( [ 'app', 'soa/kernel/soaService', 'soa/kernel/clientDataModel', 'js/logService' ], function( app, soaSvc, cdm,
    logSvc ) {
    'use strict';

    var exports = {};

    /**
     * Sign In to server
     *
     * @param {String} username - The username to sing in with.
     *
     * @param {String} password - The password for the given username (if not supplied, username assumed as password)
     *
     * @param {String} group - The user's group to sign into (if undefined, empty string assumed)
     *
     * @param {String} role - The user's role to sign into (if undefined, empty string assumed)
     *
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.signIn = function( username, password, group, role, locale, sessionDiscriminator ) {
        var body = {
            credentials: {
                user: username,
                password: password,
                group: group,
                role: role,
                locale: locale,
                descrimator: sessionDiscriminator ? sessionDiscriminator : 'AWJSK3'
            }
        };

        return soaSvc.postUnchecked( 'Core-2011-06-Session', 'login', body ).then( function( response ) {
            app.eventBus.publishSoa( "session.signIn", {} );
            return response;
        } );
    };

    /**
     * Sign out from server
     *
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.signOut = function() {
        return soaSvc.postUnchecked( 'Core-2006-03-Session', 'logout', {} ).then( function( response ) {
            soaSvc.setSessionInfo( true );
            app.eventBus.publishSoa( "session.signOut", {} );
            return response;
        } );
    };

    /**
     * Set User Session State.
     *
     * @param {Array} pairs - Array of Name-Value pair objects
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.setUserSessionState = function( pairs ) {
        return soaSvc.post( 'Core-2015-10-Session', 'setUserSessionStateAndUpdateDefaults', {
            pairs: pairs
        } ).then( function( response ) {
            soaSvc.setSessionInfo();
            // With a successful change in session, we force a reload for security concerns & memory leaks.
            location.reload( false );
            return response;
        } );
    };

    /**
     * Register this service with the AngularJS application.
     *
     * @returns {sessionService} Reference to this module's API.
     */
    app.factory( 'soa_sessionService', function() {
        return exports;
    } );

    return exports;
} );