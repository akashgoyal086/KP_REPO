// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * This module is used to aggregate all the other modules at this API level. This aggregate is used during the war build
 * 'optimization' step.
 */
define( [ //
'soa/clipboardService', //
'soa/constantsService', //
'soa/dataManagementService', //
'soa/favoritesService', //
'soa/historyService', //
'soa/pinService', //
'soa/preferenceService', //
'soa/sessionService', //
'soa/kernel/module' //
], function() {
    'use strict';
} );
