// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * Note: Many of the the functions defined in this module return a {@linkcode module:angujar~Promise|Promise} object.
 * The caller should provide callback function(s) to the 'then' method of this returned object (e.g. successCallback,
 * [errorCallback, [notifyCallback]]). These methods will be invoked when the associated service result is known.
 *
 * @module soa/dataManagementService
 */
define( [ //
'app', //
'lodash', //
'assert', //
'q', //
'soa/kernel/clientDataModel', //
'soa/kernel/propertyPolicyService', //
'soa/kernel/soaService', //
'soa/preferenceService', //
'js/dateTimeService', //
'js/logService' ], //
function( app, _, assert, Q, cdm, propPolicySvc, soaSvc, prefSvc, dateTimeSvc, logSvc ) {
    'use strict';

    // The following preferences are being added as a short term only solution for the aw2.4 release. These
    // will be removed in the following release & only the startup preferences indicated by the server will
    // be considered.
    var prefNames = [ 'AWBBackgroundContextAutoSaveFrequency', 'AWS_SearchPreFilter_Property1_SelectedValue',
        'AWS_SearchPreFilter_Property2_SelectedValue', 'AWC_SEEC_OpenSupportedTypes', 'AWC_VIS_OpenSupportedTypes',
        'AW_SE_AM_disable_tracelink', 'Create_Att0MeasurableAttribute_mru_list',
        'Create_Att0MeasurableAttribute_mru_max', 'Create_Subscription_mru_list', 'Create_Subscription_mru_max',
        'Create_WORKSPACE_OBJECT_mru_max', 'DARB_LastUsedView', 'DARB_PresentationLayout',
        'HostConfig_2014_02_OpenSupportedTypes', 'PLE_DisabledDefnStatusList', 'PLE_EnableAttrPublishStatusList',
        'PLE_EnabledDefnStatusList', 'PLE_InputOutputAttrParentObjectTypes', 'RV1_DARB_Tooltip_Max_Row',
        'RV1_DARB_Tooltip_Max_Width', 'S2cl_EnableTagSuggestions', 'SCM_notification_mode', 'SS1_DASS_enable',
        'SS1_DASS_shape_default', 'SS1_DASS_size_default_max', 'AWS_SearchPreFilter_Property1_SelectedValue',
        'AWS_SearchPreFilter_Property2_SelectedValue', 'SS1_DASS_size_default_min', 'SS1_DASS_size_lower_limit',
        'SS1_DASS_size_upper_limit', 'AW_SubLocation_Generic_ViewMode', 'Tracelink_Edit_enabled' ];

    var exports = {};

    /**
     * Create objects
     *
     * @param {ObjectArray} input - array of 'createObjects' input
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.createObjects = function( input ) {
        return soaSvc.post( 'Core-2008-06-DataManagement', 'createObjects', {
            input: input
        } );
    };

    /**
     * Create Relation and Submit objects.
     *
     * @param {ObjectArray} inputs - array of create & submit object input
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.createRelateAndSubmitObjects = function( inputs ) {
        return soaSvc.post( 'Internal-Core-2012-10-DataManagement', 'createRelateAndSubmitObjects', {
            inputs: inputs
        } );
    };

    /**
     * Create relations.
     *
     * @param {ObjectArray} inputs - array of create relation input
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.createRelations = function( inputs ) {
        return soaSvc.post( 'Core-2006-03-DataManagement', 'createRelations', {
            input: inputs
        } );
    };

    /**
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.getCurrentUserGateway = function() {
        return soaSvc.post( 'Internal-AWS2-2012-10-DataManagement', 'getCurrentUserGateway', {} );
    };

    /**
     * @param {String} typeName - type name
     * @param {String} propName - property name
     * @param {String} pattern - pattern
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.getNextId = function( typeName, propName, pattern ) {
        return exports.getNextIds( [ {
            typeName: typeName,
            propName: propName,
            pattern: pattern ? pattern : ''
        } ] );
    };

    /**
     * @param {Array} vInfoForNextId - array of type name, property name & pattern objects
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.getNextIds = function( vInfoForNextId ) {
        return soaSvc.post( 'Core-2008-06-DataManagement', 'getNextIds', {
            vInfoForNextId: vInfoForNextId
        } );
    };

    /**
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.getTCSessionInfo = function() {
        return soaSvc.getTCSessionInfo().then( function( response ) {
            if( response && response.extraInfoOut ) {
                // Capture the data time format from the server
                var userSession = cdm.getUserSession();
                var locale = 'en'; //default
                if( userSession.props && userSession.props.fnd0locale ) {
                    locale = userSession.props.fnd0locale.dbValues[0];
                }
                dateTimeSvc.setSessionDateTimeFormat( locale, response.extraInfoOut.DefaultDateFormat );

                if( response.extraInfoOut.AWC_StartupPreferences ) {
                    // The server should tell us what preferences we need to bulk cache upon login. This avoids unnecessary
                    // client-server chats.
                    prefNames = prefNames.concat( response.extraInfoOut.AWC_StartupPreferences.split( ',' ) );
                }

                return prefSvc.getMultiStringValues( prefNames, true ).then( function( getPrefResponse ) {
                    return response;
                } );
            }
            // This should happen but should do it anyway to ensure serial processing.
            return response;
        } );
    };

    /**
     * @param {StringArray} uids - Array of {ModelObject} UIDs to load {PropertyObject}s for.
     * @param {StringArray} propNames - Array of {PropertyObject} names to load.
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.loadDataForEditing = function( uids, propNames ) {
        var inputs = [];
        _.forEach( uids, function( uid ) {
            inputs.push( {
                obj: cdm.getObject( uid ),
                propertyNames: propNames
            } );
        } );
        return soaSvc.postUnchecked( 'Internal-AWS2-2012-10-DataManagement', 'loadDataForEditing', {
            inputs: inputs
        } ).then( function( response ) {
            if( response.outputs ) {
                _.forEach( uids, function( uid ) {
                    _.forEach( response.outputs, function( output ) {
                        if( uid === output.obj.uid ) {
                            var modelObj = cdm.getObject( uid );
                            modelObj.objLsds = output.objLsds;
                        }
                    } );
                } );
            }
            return response;
        } );
    };

    /**
     * @param {Object} input - Array e.g. { inputData: [ { clientId: '', parentObj: { uid: 'QteVoUbsqd$DyB', type:
     *            'Awp0TileCollection' }, childrenObj: [ { uid: 'QzaVoUbsqd$DyB', type: 'Awp0Tile' } ], propertyName:
     *            'Awp0GatewayTileRel' } ]}
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.removeChildren = function( input ) {
        return soaSvc.post( 'Core-2014-10-DataManagement', 'removeChildren', {
            inputData: input
        } );
    };

    /**
     * @param {Object} inputs -
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.saveEdit = function( inputs ) {
        return soaSvc.post( 'Internal-AWS2-2012-10-DataManagement', 'saveEdit', {
            inputs: inputs
        } );
    };

    /**
     * @param {Array} info - array of set property info objects
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.setProperties = function( info ) {
        return soaSvc.post( 'Core-2010-09-DataManagement', 'setProperties', {
            info: info,
            options: []
        } );
    };

    /**
     * @param {StringArray} uids - array of model object UIDs to load
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.loadObjects = function( uids ) {
        var missingUids = [];
        _.forEach( uids, function( uid ) {
            var modelObject = cdm.getObject( uid );
            if( !modelObject || _.isEmpty( modelObject.props ) ) {
                missingUids.push( uid );
            }
        } );

        if( missingUids.length > 0 ) {
            return soaSvc.post( 'Core-2007-09-DataManagement', 'loadObjects', {
                uids: missingUids
            } );
        }

        // no op
        var deferred = Q.defer();
        deferred.resolve();
        return deferred.promise;
    };

    /**
     * @param {ModelObject} target -
     *
     * @param {String} pasteProp - Relation type
     *
     * @param {String} typeName -
     *
     * @param {String} itemName -
     *
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.createItem = function( target, pasteProp, typeName, itemName ) {
        var propName = 'item_id';
        var revisionTypeName = typeName + 'Revision';
        var revisionPropName = 'item_revision_id';
        var itemRevision = {};

        return exports.getNextIds( [ {
            typeName: typeName,
            propName: propName
        }, {
            typeName: revisionTypeName,
            propName: revisionPropName
        } ] ).then( function( response ) {
            return exports.createRelateAndSubmitObjects( [ {
                createData: {
                    boName: typeName,
                    propertyNameValues: {
                        item_id: [ response.nextIds[0] ],
                        object_name: [ itemName ]
                    },
                    compoundCreateInput: {
                        revision: [ {
                            boName: revisionTypeName,
                            propertyNameValues: {
                                'item_revision_id': [ response.nextIds[1] ]
                            },
                            compoundCreateInput: {}
                        } ]
                    }
                }
            } ] );
        } ).then( function( response ) {
            itemRevision = cdm.getObject( response.output[0].objects[2].uid );
            return exports.createRelations( [ {
                relationType: pasteProp,
                primaryObject: target,
                secondaryObject: itemRevision
            } ] );
        } ).then( function( response ) {
            return itemRevision;
        } );
    };

    /**
     * Cache of promises for getProperties to "reuse" if the same request comes in before the first response has
     * completed.
     *
     * @private
     */
    var _getPropertiesPromises = [];

    /**
     * Ensures that the specified properties are loaded into the cache. If they are not already loaded a server call is
     * made to load them.
     *
     * @param {StringArray} uids - array of model object UIDs
     * @param {StringArray} propNames - array of property names
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.getProperties = function( uids, propNames ) {
        var objects = [];
        uids.sort();
        _.forEach( _.unique( uids, true ), function( uid ) {
            var modelObject = cdm.getObject( uid );
            if( modelObject ) {
                var modelObjAdded = false;
                // Cached model object
                _.forEach( propNames, function( propName ) {
                    if( modelObject.modelType.propertyDescriptorsMap.hasOwnProperty( propName ) && //
                    ( !modelObject.props || !modelObject.props.hasOwnProperty( propName ) ) ) {
                        if( !modelObjAdded ) {
                            // Valid property for this model type AND property not cached
                            objects.push( modelObject );
                            modelObjAdded = true;
                        }
                    }
                } );
            }
        } );

        if( objects.length > 0 ) {
            propPolicySvc.validatePropertyRegistration( objects, propNames );

            var input = {
                objects: objects,
                attributes: propNames
            };

            var promise = null;
            _.forEach( _getPropertiesPromises, function( promiseLp ) {
                if( !promise && _.isEqual( input.attributes, promiseLp.input.attributes ) ) {
                    if( objects.length === promiseLp.input.objects.length ) {
                        promise = promiseLp; // assume a match
                        for( var ii = 0; ii < objects.length; ii++ ) {
                            if( objects[ii].uid !== promiseLp.input.objects[ii].uid ) {
                                promise = null; // invalid assumption
                                break;
                            }
                        }
                    }
                }
            } );

            if( !promise ) {
                promise = soaSvc.post( 'Core-2006-03-DataManagement', 'getProperties', input ).then(
                    function( response ) {
                        _getPropertiesPromises.splice( _getPropertiesPromises.indexOf( promise ), 1 );
                        return response;
                    } );
                _getPropertiesPromises.push( promise );
                promise.input = input;
            }
            return promise;
        }

        var deferred = Q.defer();

        deferred.resolve();

        return deferred.promise;
    };

    /**
     * Convenience method for 'core' {@linkcode module:soa/dataManagementService.getStyleSheet|getStyleSheet} to handle
     * default values used in that service's request.
     *
     * @param {ModelObject} modelObject - The soa object to get the stylesheet for.
     * @param {String} styleSheetType - (Optional) The type of style sheet to return (Default: 'SUMMARY').
     * @param {Object} clientContext - (Optional) (Default: {'ActiveWorkspace:Location':
     *            'com.siemens.splm.clientfx.tcui.xrt.showObjectLocation'})
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.getStyleSheet = function( modelObject, styleSheetType, clientContext ) {
        assert( modelObject, 'getStyleSheet: No ModelObject specified' );

        var styleSheetTypeFinal = styleSheetType;
        var clientContextFinal = clientContext;

        if( !styleSheetTypeFinal ) {
            styleSheetTypeFinal = 'SUMMARY';
        }

        if( !clientContextFinal ) {
            clientContextFinal = {
                'ActiveWorkspace:Location': 'com.siemens.splm.clientfx.tcui.xrt.showObjectLocation'
            };
        }
        return soaSvc.post( 'Internal-AWS2-2016-04-DataManagement', 'getStyleSheet', {
            processEntireXRT: false,
            input: [ {
                businessObject: modelObject,
                styleSheetType: styleSheetTypeFinal,
                clientContext: clientContextFinal
            } ]
        } );
    };

    /**
     * Post the input directly to getStyleSheet
     *
     * @param {Integer} input - The json request object. All necessary fields should already be filled
     */
    exports.getStyleSheetPure = function( input ) {
        return soaSvc.post( 'Internal-AWS2-2016-04-DataManagement', 'getStyleSheet', input );
    };

    /**
     * Register this service with the AngularJS application.
     *
     * @returns {dataManagementService} Reference to this module's API.
     */
    app.factory( 'soa_dataManagementService', function() {
        return exports;
    } );

    return exports;
} );
