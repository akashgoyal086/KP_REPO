// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 localStorage
 */

/**
 * Note: Many of the the functions defined in this module return a {@linkcode module:angujar~Promise|Promise} object.
 * The caller should provide callback function(s) to the 'then' method of this returned object (e.g. successCallback,
 * [errorCallback, [notifyCallback]]). These methods will be invoked when the associated service result is known.
 *
 * @module soa/clipboardService
 */
define( [ 'app', 'lodash', 'soa/kernel/clientDataModel', 'soa/dataManagementService' ], function( app, _, cdm, dmSvc ) {
    'use strict';

    /** Clipboard event topic */
    var CLIPBOARD_EVENT_TOPIC = 'awClipboard';

    /** clipboard contents; array of model objects */
    var _contents = [];

    var exports = {};

    /**
     * @param {String} valueFromLS - value from local storage
     * @return {String[]} array of UIDs from local storage
     */
    function parseFromLS( valueFromLS ) {
        try {
            return JSON.parse( valueFromLS );
        } catch( e ) {
            return [];
        }
    }

    /**
     * @return {Array} contents of the clipboard
     */
    exports.getContents = function() {
        return _contents;
    };

    /**
     * @param {Array} contentsToSet - array of UIDs or ModelObjects to set clipboard contents to
     */
    var setContents = exports.setContents = function( contentsToSet ) {
        var oldContents = _contents;
        _contents = [];
        var valueForLS = [];
        _.forEach( contentsToSet, function( content ) {

            var resolvedContent = _.isString( content ) && cdm.containsObject( content ) ? cdm.getObject( content )
                : content;
            if( _.isPlainObject( content ) && content.hasOwnProperty( 'uids' ) ) {
                resolvedContent = content;
                _.forEach( content.uids, function( uid ) {
                    if( !cdm.contains( uid ) ) {
                        // Missing model object in CDM, so not set clipboard object into _contents
                        resolvedContent = null;
                    }
                } );
            }
            if( resolvedContent ) {
                _contents.push( resolvedContent );
            }

            if( _.isPlainObject( resolvedContent ) ) {
                if( resolvedContent.hasOwnProperty( 'uid' ) ) {
                    valueForLS.push( resolvedContent.uid );
                } else if( resolvedContent.hasOwnProperty( 'uids' ) ) {
                    valueForLS.push( resolvedContent );
                }
            }
        } );
        if( !_.isEqual( oldContents, _contents ) ) {
            // fire event
            app.eventBus.publishSoa( 'clipboard.update', {
                oldValue: oldContents,
                newValue: _contents
            } );
            app.eventBus.publishLocalStorage( CLIPBOARD_EVENT_TOPIC, JSON.stringify( valueForLS ) );
        }
    };

    /**
     * Ensure the uids on the local storage clipboard are loaded.
     */
    function loadObjectsOnClipboard() {
        var valuesFromLS = app.eventBus.getLocalStorage( CLIPBOARD_EVENT_TOPIC );
        if( valuesFromLS && valuesFromLS.length > 0 ) {
            var fromLS = parseFromLS( valuesFromLS );
            var uidsToLoad = [];
            _.forEach( fromLS, function( content ) {
                if( _.isString( content ) ) {
                    // handle basic UID string
                    uidsToLoad.push( content );
                } else if( _.isPlainObject( content ) && content.hasOwnProperty( 'uids' ) ) {
                    // handle clipboard objects
                    _.forEach( content.uids, function( uid ) {
                        uidsToLoad.push( uid );
                    } );
                }
            } );
            dmSvc.loadObjects( uidsToLoad );
        }
    }

    loadObjectsOnClipboard();

    app.eventBus.subscribeSoa( 'session.signOut', function( data, envelope ) {
        // To support Cucumber testing, clearing clipboard upon sign-out
        localStorage.removeItem( CLIPBOARD_EVENT_TOPIC );
    } );

    // Subscribe for storage events for the clipboard
    app.eventBus.subscribeLocalStorage( CLIPBOARD_EVENT_TOPIC, function( event ) {
        if( event.newValue ) {
            loadObjectsOnClipboard();
            setContents( parseFromLS( event.newValue ) );
        }
    }, false );

    // Listen for when new objects are added to the CDM
    app.eventBus.subscribeSoa( "cdm.new", function( data, envelope ) {
        var valuesFromLS = app.eventBus.getLocalStorage( CLIPBOARD_EVENT_TOPIC );
        if( valuesFromLS && data.newObjects && data.newObjects.length > 0 ) {
            var update = false;
            for( var ii = 0; ii < data.newObjects.length; ii++ ) {
                if( valuesFromLS.indexOf( data.newObjects[ii].uid ) > -1 ) {
                    update = true;
                    break;
                }
            }

            if( update ) {
                setContents( parseFromLS( valuesFromLS ) );
            }
        }
    } );

    // Listen for when objects are deleted to the CDM
    app.eventBus.subscribeSoa( "cdm.deleted", function( data, envelope ) {
        var valuesFromLS = app.eventBus.getLocalStorage( CLIPBOARD_EVENT_TOPIC );
        if( valuesFromLS && data.deletedObjectUids && data.deletedObjectUids.length > 0 ) {
            var update = false;
            for( var ii = 0; ii < data.deletedObjectUids.length; ii++ ) {
                if( valuesFromLS.indexOf( data.deletedObjectUids[ii] ) > -1 ) {
                    update = true;
                    break;
                }
            }

            if( update ) {
                setContents( parseFromLS( valuesFromLS ) );
            }
        }
    } );

    /**
     * @return {Array} array of model objects
     */
    exports.getCachableObjects = function() {
        var modelObjects = [];
        _.forEach( _contents, function( content ) {
            if( _.isString( content ) ) {
                var modelObject = cdm.getObject( content );
                if( modelObject ) {
                    modelObjects.push( modelObject );
                }
            } else if( _.isPlainObject( content ) ) {
                if( content.hasOwnProperty( 'uid' ) && content.hasOwnProperty( 'type' ) ) {
                    modelObjects.push( content );
                } else if( content.hasOwnProperty( 'uids' ) ) {
                    _.forEach( content.uids, function( uid ) {
                        var modelObject = cdm.getObject( uid );
                        if( modelObject ) {
                            modelObjects.push( modelObject );
                        }
                    } );
                }
            }
        } );
        return modelObjects;
    };

    /**
     * Register this service with the AngularJS application.
     *
     * @returns {clipboardService} Reference to this module's API.
     */
    app.factory( 'soa_clipboardService', function() {
        return exports;
    } );

    return exports;
} );