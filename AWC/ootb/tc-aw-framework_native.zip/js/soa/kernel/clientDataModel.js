// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 angular,
 define,
 document
 */

/**
 * The methods provided by this module enable access, control and maintenance of a cache of ModelObjects as well as
 * their member PropertyObjects.
 *
 * @module soa/kernel/clientDataModel
 */
define( [ //
'app', //
'jquery', //
'lodash', //
'assert', //
'js/dateTimeService', //
'soa/kernel/clientMetaModel', //
'js/logService' ], //
function( app, $, _, assert, dateTimeSvc, cmm, logSvc ) {
    'use strict';

    /**
     * HTML 'anchor' regular expression
     *
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var REGEX_FRAGMENT_ANCHOR_SCRIPT = /href="[^"]*?java[^"]*?"/;

    /**
     * HTML 'src=java' regular expression
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var REGEX_FRAGMENT_SRC_SCRIPT = /src=java*/;

    /**
     * HTML 'style="java' regular expression
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var REGEX_FRAGMENT_STYLE_SCRIPT = /style="[^"]*?java[^"]*?"/;

    /**
     * HTML 'style="java' regular expression
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var REGEX_FRAGMENT_STYLE_WEIRD = /style="[^"]*?&[^"]*?"/;

    /**
     * HTML entity regular expression
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var REGEX_HTML_ENTITY = /[a-z]+|#[0-9]+|#x[0-9a-fA-F]+/i;

    /**
     * HTML 'on*' regular expression (e.g. 'onload=', 'onerror=', etc.).
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var REGEX_IMG_ATTR = /\son.*?=".*?"/i;

    /**
     * HTML escaped entity regular expression
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var REGEX_HTML_ESCAPED_ENTITY = /&[a-z]+;|&#[0-9]+;/i;

    /**
     * HTML 'image' regular expression
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var REGEX_INVALID_HTML = new RegExp( REGEX_FRAGMENT_ANCHOR_SCRIPT.source + "|" //
        + REGEX_FRAGMENT_SRC_SCRIPT.source + "|" //
        + REGEX_FRAGMENT_STYLE_SCRIPT.source + "|" //
        + REGEX_FRAGMENT_STYLE_WEIRD.source, 'i' );

    /**
     * Global array of HTML black list tags used for sanitization
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var TAG_BLACKLIST = [ "applet", "audio", "body", "embed", "fieldset", "form", "frame", "frameset", "input",
        "iframe", "meta", "object", "output", "param", "script", "style", "textarea", "video" ];

    /**
     * Marker text within a value used to indicate when a property contains a UTC date/time that needs to be converted
     * to to local time zone and session specfici format.
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var UTC_DATE_TIME_MARKER = "{__UTC_DATE_TIME}"; //$NON-NLS-1$

    /**
     * Global reference to invalid HTML locale string
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var _invalidHtmlMessage = "";

    /**
     * Note: We are holding on to the resolved module now for when we are running NodeJS. However, this variable will be
     * set again when this service is created using AngularJS injection. The reason is that the 'dateTimeService' needs
     * some other AngularJS services injected to do all its work. It will use fallback values when running in NodeJS.
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var _dateTimeSvc = dateTimeSvc;

    /**
     * Object used to implement a UID-to-ModelObject cache map.
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var _uid2modelObject = {};

    /**
     * The array of none flushable object types.
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     */
    var _noFlushableTypes = [ "UserSession", "User", "Group", "GroupMember", "Role", "ImanVolume", "Fnd0Icon",
        "Fnd0ConditionHelper", "Fnd0HomeFolder", "Fnd0Command", "Fnd0CommandCollection", "Fnd0UIConfigCollectionRel",
        "Fnd0ClientScope", "Awb0ProductContextInfo", "Awp0Tile", "Awp0GatewayTileRel", "POM_imc" ];

    /**
     * UID of the current 'User' ModelObject.
     *
     * @memberof module:soa/kernel/clientDataModel
     * @type {String}
     * @private
     */
    var _userUID = '';

    /**
     * UID of the current 'Session' ModelObject.
     *
     * @memberof module:soa/kernel/clientDataModel
     * @type {String}
     * @private
     */
    var _userSessionUID = '';

    /**
     * UID of the current user's 'Group' ModelObject.
     *
     * @memberof module:soa/kernel/clientDataModel
     * @type {String}
     * @private
     */
    var _groupMemberUID = '';

    /**
     * Global reference to dummy text area element, which is used for decoding HTML entity characters before passing it
     * to sanitization routine. Note: This element should NOT be appended to DOM.
     *
     * @memberof module:soa/kernel/clientDataModel
     * @type {Element}
     * @private
     */
    var _dummyTextAreaElem = $( '<textarea/>' );

    /**
     * Replace any occurrences of UTC date/time values with the {@link #UTC_DATE_TIME_MARKER} with the date/time in the
     * local time zone.
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     *
     * @param {StringArray} values - Array of values to consider.
     * @return {StringArray} Array if values after replacement of any strings.
     */
    var _convertUTCTimeValues = function( values ) {
        for( var iNdx = 0; iNdx < values.length; iNdx++ ) {
            var value = values[iNdx];

            var markerNdx = value.indexOf( UTC_DATE_TIME_MARKER );

            if( markerNdx !== -1 ) {
                var prefix = value.substring( 0, markerNdx );
                var utc = value.substring( markerNdx + UTC_DATE_TIME_MARKER.length );

                var date = new Date( utc );

                values[iNdx] = prefix + dateTimeSvc.formatSessionDateTime( date );
            }
        }

        return values;
    };

    /**
     * HTML escapes a character. HTML meta characters will be escaped.
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     *
     * @param {String} unsafe - unsafe HTML String which needs to be escaped.
     *
     * @return {String} Returns escaped and safe HTML String.
     */
    function _escapeHtml( unsafe ) {
        return unsafe.replace( /&/g, "&amp;" ).replace( /</g, "&lt;" ).replace( />/g, "&gt;" ).replace( /"/g, "&quot;" )
            .replace( /'/g, "&#39;" );
    }

    /**
     * HTML meta characters will be un-escaped. This method should be used only after sanitizing the input.
     *
     * @memberof module:soa/kernel/clientDataModel
     * @private
     *
     * @param {String} escapedSafe - escapedSafe HTML String which needs to be un-escaped.
     *
     * @return {String} Returns un-escaped and safe HTML String.
     */
    function _unEscapeHtml( escapedSafe ) {
        return escapedSafe.replace( /&amp;/ig, "&" ).replace( /&lt;/ig, "<" ).replace( /&gt;/ig, ">" ).replace(
            /&quot;/ig, "\"" ).replace( /&#39;/ig, "'" );
    }

    /**
     * This method is set on (augments) all {ModelObject} instance returned by SOA so that it is available for general
     * application use.
     *
     * @memberof module:soa/kernel/clientDataModel
     *
     * @returns {String} Text value that represents a common way to identify the function's context object (i.e. The
     *          'object_string' property) or the JSON 'stringify' version of the content object if the specific common
     *          property if not defined.
     */
    var augModelToString = function() {
        if( this.props && this.props.object_string ) {
            return this.props.object_string.uiValues[0];
        }

        return JSON.stringify( this, null, 2 );
    };

    /**
     * This method is set on (augments) all {PropertyObject} instances returned by SOA so that it is available for
     * general application use.
     *
     * @memberof module:soa/kernel/clientDataModel
     *
     * @returns {Boolean} TRUE if the internal values (aka 'dbValues') of the function's context object are to be
     *          considered 'null' or 'unset'. If the 'isNulls' array is present its 1st value will be used to determine
     *          the result. If 'isNulls' is not present we assume the 'dbValues' are not null.
     *          <P>
     *          Note: The intrinsic data types (boolean, int, double) can have a value (i.e. 'false' or 'zero') but
     *          still be 'unset'. In this case, the SOA server will send back an optional array of booleans named
     *          'isNulls', the 'true/false' values in this array indicate while elements in the 'dbValues' array should
     *          be considered 'unset'.
     *          <P>
     *          Note: We are only looking at the 1st 'isNulls' array entry. It is not clear if/how null values within an
     *          array are being handled by the SOA server at this time.
     */
    var augPropEvaluateIsNull = function() {
        /**
         * Check if the server told us this was to be considered 'null'
         * <P>
         * Note: We are only looking at the 1st
         */
        if( this.isNulls && this.isNulls.length > 0 && this.isNulls[0] ) {
            return true;
        }

        return false;
    };

    /**
     * This method is set on (augments) all {PropertyObject} instances returned by SOA so that it is available for
     * general application use.
     *
     * @memberof module:soa/kernel/clientDataModel
     *
     * @returns {String} Gets the property's display value. If this property has multiple values, this method will
     *          return the first display value.
     */
    var augPropGetDisplayValue = function() {
        if( this.uiValues && this.uiValues.length > 0 ) {
            return this.uiValues[0];
        }

        return '';
    };

    /**
     * This method is set on (augments) all {PropertyObject} instances returned by SOA so that it is available for
     * general application use.
     *
     * @memberof module:soa/kernel/clientDataModel
     *
     * @returns {StringArray} the name of all property's display value. If this property has multiple values, this
     *          method will return the first display value.
     */
    var augModelGetPropertyNames = function() {
        return _.keys( this.props );
    };

    /**
     * Update properties. This includes adding references to meta model & dealing with date conversions.
     *
     * @param {clientDataModel} cdm - Reference to the containing module:soa/kernel/clientDataModel
     * @param {Object} props - model object properties
     * @param {Object} modelType - model type from meta model
     * @private
     */
    var _updateProps = function( cdm, props, modelType ) {
        for( var propName in props ) {
            if( props.hasOwnProperty( propName ) ) {
                var prop = props[propName];

                /**
                 * Add meta model link
                 */
                prop.propertyDescriptor = modelType.propertyDescriptorsMap[propName];

                /**
                 * Assure certain properties are never 'null' or 'undefined'
                 */
                if( !prop.dbValues ) {
                    prop.dbValues = [];
                } else if( prop.isNulls ) {
                    /**
                     * We want to make sure the 'dbValues' match the SOA supplied definition of 'null'.
                     */
                    for( var ndx = prop.isNulls.length - 1; ndx >= 0; ndx-- ) {
                        if( prop.isNulls[ndx] && prop.dbValues.length > ndx ) {
                            prop.dbValues[ndx] = null;
                        }
                    }
                }

                if( !prop.uiValues ) {
                    prop.uiValues = [];
                }

                /**
                 * Set the augmentation methods on all {PropertyObject} instances.
                 */
                prop.evaluateIsNull = augPropEvaluateIsNull;
                prop.getDisplayValue = augPropGetDisplayValue;

                /**
                 * Perform some type specific post processing of the property values.
                 */
                switch( prop.propertyDescriptor.valueType ) {
                case 2: // Date
                    /**
                     * Date processing...Reformat UI value based upon DB value.
                     * <P>
                     * Note: This also makes the UI value be for local time zone instead of the server's time zone.
                     */
                    // Only set if server gave the client a non-empty UI values array
                    if( prop.uiValues && prop.uiValues.length > 0 && prop.uiValues[0] && prop.uiValues[0].length > 0 ) {
                        // Only attempt if we have a DB value...
                        if( prop.dbValues.length > 0 ) {
                            var jqDate = new Date( prop.dbValues[0] );
                            prop.uiValues[0] = _dateTimeSvc.formatSessionDateTime( jqDate );
                        } else {
                            prop.uiValues[0] = '';
                        }
                    }
                    break;
                case 8: // String
                    if( propName !== 'fnd0SVG' ) {
                        // Sanitize the String DB values
                        prop.dbValues = cdm.sanitizeHtmlValues( prop.dbValues );
                        // Sanitize the String UI values
                        prop.uiValues = cdm.sanitizeHtmlValues( prop.uiValues );
                    }

                    if( propName === 'awp0CellProperties' ) {
                        prop.dbValues = _convertUTCTimeValues( prop.dbValues );
                        prop.uiValues = _convertUTCTimeValues( prop.uiValues );
                    }
                    break;
                }
            }
        }
    };

    /**
     * Define the base object used to provide all of this module's external API on.
     *
     * @private
     */
    var exports = {};

    /**
     * @param {String} uid - UID of ModelObject to test for.
     *
     * @return {boolean} TRUE if client data model contains the given ModelObject
     */
    exports.containsObject = function( uid ) {
        return _uid2modelObject.hasOwnProperty( uid );
    };

    /**
     * Get model object.
     *
     * @param {String} uid - UID of ModelObject
     *
     * @return {ModelObject} The ModelObject; null if not cached
     */
    exports.getObject = function( uid ) {
        if( exports.containsObject( uid ) ) {
            return _uid2modelObject[uid];
        }
        return null;
    };

    /**
     * Remove the ModelObject from the cache that have the given UIDs. Publishes the UIDs to the 'soajs/cdm.deleted'
     * eventBus channel/topic.
     *
     * @param {StringArray} deletedUIDs - Array of UIDs to be removed from the cache.
     */
    exports.removeObjects = function( deletedUIDs ) {
        var uids = [];
        _.forEach( deletedUIDs, function( deletedUID ) {
            if( exports.containsObject( deletedUID ) ) {
                delete _uid2modelObject[deletedUID];
                uids.push( deletedUID );
            }
        } );

        if( uids.length > 0 ) {
            app.eventBus.publishSoa( "cdm.deleted", {
                deletedObjectUids: uids
            } );
        }
    };

    /**
     * @param {ModelObject} userSession - user session
     */
    var setUserSession = function( userSession ) {
        _userSessionUID = userSession.uid;

        // For refresh scenario, signin isn't call & these 2 fields need to be set.
        if( userSession.props ) {
            if( userSession.props.user ) {
                _userUID = userSession.props.user.dbValues[0];
            }
            if( userSession.props.fnd0groupmember ) {
                _groupMemberUID = userSession.props.fnd0groupmember.dbValues[0];
            }
        }
    };

    /**
     * Add or replace the given ModelObjects to the cache. Publishes the modelObjects to the 'soajs/cdm.modified'
     * eventBus channel/topic.
     *
     * @param {ModelObjectArray} modelObjects - Array of 'wire' ModelObject to be added to the cache.
     */
    exports.cacheObjects = function( modelObjects ) {
        var newObjects = [];
        var modifiedObjects = [];

        _.forEach( modelObjects, function( modelObject ) {
            var existing = exports.getObject( modelObject.uid );

            if( !existing ) {
                // Add model object to cache
                _uid2modelObject[modelObject.uid] = modelObject;

                if( !modelObject.props ) {
                    modelObject.props = {};
                }

                // add meta model link
                modelObject.modelType = cmm.getType( modelObject.type );

                _updateProps( exports, modelObject.props, modelObject.modelType );

                /**
                 * Set the augmentation methods on all {PropertyObject} instances.
                 */
                modelObject.toString = augModelToString;
                modelObject.getPropertyNames = augModelGetPropertyNames;

                // remove unneeded data
                delete modelObject.className;
                delete modelObject.objectID;

                newObjects.push( modelObject );

                /**
                 * Check before we speand any time creating a message string
                 */
                if( !modelObject.modelType ) {
                    assert( modelObject.modelType, 'model type not found for ' + modelObject.type );
                }
            } else if( modelObject.props ) {
                assert( modelObject.type === existing.type );

                _updateProps( exports, modelObject.props, existing.modelType );

                if( !_.isEqual( existing.props, modelObject.props ) ) {
                    // Update model object already in cache
                    existing.props = modelObject.props;
                    modifiedObjects.push( existing );
                }
            }

            // Set the cache of the UserSession object
            if( modelObject.type === 'UserSession' ) {
                setUserSession( modelObject );
            }
        } );

        if( newObjects.length > 0 ) {
            app.eventBus.publishSoa( "cdm.new", {
                newObjects: newObjects
            } );
        }

        if( modifiedObjects.length > 0 ) {
            app.eventBus.publishSoa( "cdm.modified", {
                modifiedObjects: modifiedObjects
            } );
        }
    };

    /**
     * @returns {ModelObject} The ModelObject of the current user 'Session'.
     */
    exports.getUserSession = function() {
        return exports.getObject( _userSessionUID );
    };

    /**
     * @returns {ModelObject} The ModelObject of the current user's 'Group'.
     */
    exports.getGroupMember = function() {
        return exports.getObject( _groupMemberUID );
    };

    /**
     * @returns {ModelObject} The ModelObject of the current 'User'.
     */
    exports.getUser = function() {
        return exports.getObject( _userUID );
    };

    /**
     * @returns {String} Base URL for the current application's root 'document' without any query or location attributes
     *          and (if otherwise valid) with a trailing '/' assured (e.g. 'http://100.100.100.100:8888/awc/').
     */
    exports.getBaseURL = function() {
        if( !angular ) {
            // Support for non-Angular (NodeJS) run.
            return '/';
        }

        var s = angular.element( document )[0].location.href;

        // Pull off any hash.
        var i = s.indexOf( '#' );
        if( i !== -1 ) {
            s = s.substring( 0, i );
        }

        // Pull off any query string.
        i = s.indexOf( '?' );
        if( i !== -1 ) {
            s = s.substring( 0, i );
        }

        // Rip off everything after the last slash.
        i = s.lastIndexOf( '/' );
        if( i !== -1 ) {
            s = s.substring( 0, i );
        }

        // Ensure a final slash if non-empty.
        return s.length > 0 ? s + '/' : '';
    };

    /**
     * HTML-escapes a string, but does not double-escape HTML-entities already present in the string.
     *
     * @param {String} value - HTML String which needs to be escaped.
     *
     * @return {String} Returns escaped and safe HTML.
     */
    exports.htmlEscapeAllowEntities = function( value ) {
        var escaped = '';

        if( value ) {
            var splitArray = value.split( "&", -1 );

            for( var ndx = 0; ndx < splitArray.length; ndx++ ) {

                var currSegment = splitArray[ndx];

                /**
                 * The first segment is never part of a valid tag;
                 * <P>
                 * Note that if the input string starts with a tag, we will get an empty segment at the beginning.
                 */
                if( ndx === 0 ) {
                    escaped = escaped.concat( _escapeHtml( currSegment ) );
                    continue;
                }

                var entityEnd = currSegment.indexOf( ';' );

                if( entityEnd > 0 && REGEX_HTML_ENTITY.test( currSegment.substring( 0, entityEnd ) ) ) {
                    // Concatenate the entity without escaping.
                    escaped = escaped.concat( "&" ).concat( currSegment.substring( 0, entityEnd + 1 ) );

                    // Concatenate the rest of the segment, escaped.
                    escaped = escaped.concat( _escapeHtml( currSegment.substring( entityEnd + 1 ) ) );

                } else {
                    // The segment did not start with an entity reference, so escape the whole segment.
                    escaped = escaped.concat( "&amp;" ).concat( _escapeHtml( currSegment ) );
                }
            }
        }

        return escaped;
    };

    /**
     * Simple and inexpensive HTML Sanitizer which accepts the subset of TAG_WHITELIST array of HTML white list tags.
     *
     * @param {StringArray} values - Array of HTML Strings which needs to be sanitized.
     *
     * @return {StringArray} Returns sanitized HTML string array.
     */
    exports.sanitizeHtmlValues = function( values ) {
        if( values && values.length > 0 ) {
            for( var ii = values.length - 1; ii >= 0; ii-- ) {
                var originalHtml = values[ii];
                var sanitizedHtml = exports.sanitizeHtmlValue( originalHtml );
                if( sanitizedHtml && originalHtml !== sanitizedHtml ) {
                    values[ii] = sanitizedHtml;
                }
            }
        }

        return values;
    };

    /**
     * Simple and inexpensive HTML Sanitizer which detects and/or eliniates HTML that can cause potential cross-site
     * scripting and other UI issues.
     *
     * @param {String} rawValue - HTML String which needs to be sanitized.
     *
     * @return {String} Returns sanitized HTML or Invalid HTML string when there is malicious string.
     */
    exports.sanitizeHtmlValue = function( rawValue ) {
        var sanitized = '';
        var decodedValue = '';

        if( rawValue ) {
            /**
             * Decode html escaped entity characters before applying sanitization, so that it will also catch escaped
             * XSS vulnerability attacks.
             */
            if( REGEX_HTML_ESCAPED_ENTITY.test( rawValue ) ) {
                decodedValue = _dummyTextAreaElem.html( rawValue ).val();
            } else {
                decodedValue = rawValue;
            }

            /**
             * Break the string into n+1 segments based on any HTML tags
             * <P>
             * Loop for each of these segments.
             */
            var splitArray = decodedValue.split( '<', -1 );

            for( var ndx = 0; ndx < splitArray.length; ndx++ ) {
                var currSegment = splitArray[ndx];

                /**
                 * The first segment is never part of a valid tag;
                 * <P>
                 * Note that if the input string starts with a tag, we will get an empty segment at the beginning.
                 */
                if( ndx === 0 ) {
                    sanitized = sanitized.concat( exports.htmlEscapeAllowEntities( currSegment ) );
                    continue;
                }

                /**
                 * Determine if the current segment is the start of an attribute-free tag or end-tag in our whitelist.
                 */
                var tagStart = 0; // will be 1 if this turns out to be an end tag.
                var tagEnd = currSegment.indexOf( '>' );
                var tag = null;
                var isValidTag = true;
                var selfClosingTag = false;

                if( tagEnd > 0 ) {
                    if( currSegment.charAt( 0 ) === '/' ) {
                        tagStart = 1;
                    }

                    // for self closing tags ex: '<br />'
                    if( currSegment.charAt( tagEnd - 1 ) === '/' ) {
                        selfClosingTag = true;
                        tagEnd = tagEnd - 1;
                    }

                    tag = currSegment.substring( tagStart, tagEnd );

                    var exist = tag.replace( /\s\w.*/ig, '' ); // for attributes

                    if( TAG_BLACKLIST.indexOf( exist.trim() ) !== -1 ) {
                        isValidTag = false;
                    }

                    if( isValidTag ) {
                        // concat the tag, not escaping it
                        if( tagStart === 0 ) {
                            sanitized = sanitized.concat( '<' );
                        } else {
                            // we had seen an end-tag
                            sanitized = sanitized.concat( "</" );
                        }

                        if( selfClosingTag ) {
                            sanitized = sanitized.concat( tag ).concat( '/>' );

                            // concat the rest of the segment, escaping it
                            sanitized = sanitized.concat( exports.htmlEscapeAllowEntities( currSegment
                                .substring( tagEnd + 2 ) ) );
                        } else {
                            sanitized = sanitized.concat( tag ).concat( '>' );

                            // concat the rest of the segment, escaping it
                            sanitized = sanitized.concat( exports.htmlEscapeAllowEntities( currSegment
                                .substring( tagEnd + 1 ) ) );
                        }

                        /**
                         * Check for image attribute script <BR>
                         * <img src="" onerror="alert('securityIssue_img');"/>
                         */
                        if( REGEX_IMG_ATTR.test( currSegment ) ) {
                            return _invalidHtmlMessage;
                        }
                    } else {
                        return _invalidHtmlMessage;
                    }
                } else {
                    sanitized = sanitized.concat( '<' );
                    sanitized = sanitized.concat( exports.htmlEscapeAllowEntities( currSegment ) );
                }
            }

            /**
             * Check for weird style stuff
             */
            if( REGEX_INVALID_HTML.test( sanitized ) ) {
                return _invalidHtmlMessage;
            }

            // unescape html after sanitization is done
            sanitized = _unEscapeHtml( sanitized );
        }

        return sanitized;
    };

    /**
     * Set the message that is seen when invalid HTML content is found.
     * <P>
     * Note: This message is normally set based on the value returned by the 'localeService'. This method is marked
     * 'private' and is intended to be used during testing to allow a preditable value to be returned.
     *
     * @private
     *
     * @param {String} message - Localized text to return from 'sanitizeHtmlValue' when some issue is found.
     *
     * @returns {Void}
     */
    exports.setInvalidHtmlMessage = function( message ) {
        _invalidHtmlMessage = message;
    };

    /**
     * Return an array of all IModelObjects currently in the cache that match the given model type.
     *
     * @param {String} typeName - Name of the model type to search for.
     * @return {StringArray} An array of all IModelObjects currently in the cache that match the given model type.
     */
    exports.getObjectsOfType = function( typeName ) {
        var objs = [];

        _.forEach( _uid2modelObject, function( modelObject, uid ) {
            if( modelObject.type && modelObject.type === typeName ) {
                objs.push( modelObject );
            }
        } );

        return objs;
    };

    /**
     * -----------------------------------------------<BR>
     * Definition complete...No do some initialzation<BR>
     * -----------------------------------------------<BR>
     *
     * @param data
     * @param envelope
     */
    app.eventBus.subscribeSoa( "cdm.cleanCache", function( data, envelope ) {
        // collect the flushable objects, keep the escaped objects in cache
        _.forEach( _uid2modelObject, function( modelObject, uid ) {
            if( !modelObject.type ) {
                return;
            }

            if( _noFlushableTypes.indexOf( modelObject.type ) === -1 && data.escapedObjUids.indexOf( uid ) === -1 ) {
                modelObject.props = {};
            }
        } );
    } );

    /**
     * Register this service with the AngularJS application.
     *
     * @param dateTimeSvcIn
     * @param localeSvc
     * @return {Void}
     */
    app.factory( 'soa_kernel_clientDataModel', [ 'dateTimeService', 'localeService',
        function( dateTimeSvcIn, localeSvc ) {
            _dateTimeSvc = dateTimeSvcIn;

            /**
             * Load localized text for when we encounter cases of invalid (failed sanitization) HTML.
             *
             * @param localTextBundle
             */
            localeSvc.getTextPromise().then( function( localTextBundle ) {
                _invalidHtmlMessage = localTextBundle.INVALID_HTML;
            } );

            return exports;
        } ] );

    return exports;
} );