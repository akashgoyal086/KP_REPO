// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/**
 * Note: The purpose of this JS file is to define some namespaces used when building JSDoc structure. These namespaces
 * are used to gather together implementations like 'controllers' and 'directives' that other wise require the code to
 * be available to document.
 */

/**
 * The collection of lover-level modules used to provide server access and caching services to the host client.
 *
 * @module soa/kernel
 */
