// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 atob,
 define
 */

define( [ 'app', 'hostInterop', 'q', 'js/logService', 'hostInfServiceConstants' ], function( app, hostInterop, $q,
    logSvc, hostInfServiceConstants ) {
    'use strict';

    /**
     * {Function} GWT-side Function to call to encode/decode SOA message contents.
     */
    var _encodingApi = null;

    /**
     * {String} What encoding to use for JSON payloads being sent to (or returned from) the host.
     *
     * <PRE>
     * hostInfServiceConstants.VERSION_2014_02 - Use older BASE64 encoding
     * hostInfServiceConstants.VERSION_2014_07 - Use newer BASE64 encoding (compatible with JavaScript 'atob' and 'btoa')
     * hostInfServiceConstants.VERSION_2015_10 - Use no encoding
     * </PRE>
     */
    var _encodingVersion = hostInfServiceConstants.VERSION_2015_10;

    /**
     * @private
     */
    var _internalCount = 1;

    /**
     * Map of ID of an SOA request and the 'deferred' being used to track the request's lifecycle.
     *
     * @private
     */
    var _mapCacheId2Deferred = {};

    /**
     * Object who's properties are the various configuration options selected by the host during 'handShake'.
     *
     * @private
     */
    var _hostConfig = {};

    /**
     * Called by the client to have the host process a SOA call
     *
     * @see SoaJsonRequestSvc
     */
    var REQUEST_SERVICE = new hostInterop.ServiceDescriptor2( hostInfServiceConstants.HS_ASYNC_SOA_JSON_MESSAGE_SVC,
        hostInfServiceConstants.VERSION_2014_02 );

    /** Response service description */
    var RESPONSE_SERVICE = new hostInterop.ServiceDescriptor2( hostInfServiceConstants.CS_SOA_JSON_REQUEST_SVC,
        hostInfServiceConstants.VERSION_2014_02 );

    var RESPONSE_SERVICE_JSON = JSON.stringify( RESPONSE_SERVICE );

    var exports = {};

    /**
     * @returns {Boolean} TRUE if the client is being hosted AND that host supports processing SOA service/operation
     *          requests.
     */
    exports.isSoaHosted = function() {
        return hostInterop.isHostServiceAvailable( REQUEST_SERVICE );
    };

    /**
     * @param {String} serviceName - Name of the SOA service to invoke.
     *
     * @param {String} operationName - Name of the operation in the service to invoke.
     *
     * @param {Object} jsonData - Object containing the 'header' and 'body' properties of the input to the given
     *            operation.
     *
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.post = function( serviceName, operationName, jsonData ) {
        var deferred = $q.defer();

        var now = new Date();
        var nextId = _internalCount++;
        var cacheId = nextId.toString() + '_' + now.getTime();

        _mapCacheId2Deferred[cacheId] = deferred;

        var soaMessage = new hostInterop.SoaJsonRequestMessage( _encodingVersion, cacheId, RESPONSE_SERVICE_JSON,
            serviceName, operationName, JSON.stringify( jsonData ) );

        hostInterop.callHostEvent( REQUEST_SERVICE, JSON.stringify( soaMessage ) );

        return deferred.promise.then( function( data ) {
            return data;
        }, function() {
            throw "Post to " + serviceName + ":" + operationName + " Failed" + "\n" + jsonData;
        } );
    };

    /**
     * This function is called by the client-side service (SoaJsonRequestSvc) to resolve a previous call to 'post' to
     * access SOA service operations.
     *
     * @param {String} jsonResponseMsg - JSON encoding of a SoaJsonResponseMessage object.
     */
    exports.handleEventResponse = function( jsonResponseMsg ) {
        // logSvc.info( 'handleEventResponse: ' + jsonResponseMsg );

        var soaJsonResponseMessage = JSON.parse( jsonResponseMsg );

        var deferred = _mapCacheId2Deferred[soaJsonResponseMessage.CacheId];

        if( deferred ) {
            delete _mapCacheId2Deferred[soaJsonResponseMessage.CacheId];

            if( soaJsonResponseMessage.Exception ) {
                deferred.reject( soaJsonResponseMessage.Exception.message );
            } else {
                var soaResponseJSON = null;
                var soaResponseObj = null;

                if( soaJsonResponseMessage.Version === hostInfServiceConstants.VERSION_2014_02 ) {
                    if( _encodingApi ) {
                        soaResponseJSON = _encodingApi( soaJsonResponseMessage.SoaResponse, true );
                        soaResponseObj = JSON.parse( soaResponseJSON );
                    } else {
                        deferred.reject( 'Encoding API not set: ' + soaJsonResponseMessage.Version );
                    }
                } else if( soaJsonResponseMessage.Version === hostInfServiceConstants.VERSION_2014_07 ) {
                    if( _encodingApi ) {
                        soaResponseJSON = _encodingApi( soaJsonResponseMessage.SoaResponse, false );
                        soaResponseObj = JSON.parse( soaResponseJSON );
                    } else {
                        deferred.reject( 'Encoding API not set: ' + soaJsonResponseMessage.Version );
                    }
                } else if( soaJsonResponseMessage.Version === hostInfServiceConstants.VERSION_2015_10 ) {
                    soaResponseObj = soaJsonResponseMessage.SoaResponse;
                } else {
                    deferred.reject( 'Unsupported response encoding: ' + soaJsonResponseMessage.Version );
                }

                // exports.log( "SoaResponse:\n" + soaJsonResponseMessage.SoaResponse );
                // exports.log( "soaResponseObj:\n" + JSON.stringify( soaResponseObj ) );

                if( soaResponseObj ) {
                    deferred.resolve( soaResponseObj );
                } else {
                    deferred.reject( 'No reponse object resulted: ' + soaJsonResponseMessage.Version );
                }
            }
        }
    };

    /**
     * This function is called by the client-side service to resolve a previous 'post' event.
     *
     * @param {SoaJsonResponseMessage} responseMsg -
     */
    exports.handleMethodResponse = function( responseMsg ) {
        logSvc.info( 'handleMethodResponse: ' + responseMsg );
    };

    /**
     * This function is called by the client-side service to log a message back at the host.
     *
     * @param {String} message -
     */
    exports.log = function( message ) {
        var loggerForwardService = new hostInterop.ServiceDescriptor2( hostInfServiceConstants.HS_LOGGER_FORWARD_SVC,
            hostInfServiceConstants.VERSION_2014_02 );

        var logMessage = {
            Version: "",
            FormatMessage: message,
            Level: ""
        };

        hostInterop.callHostEvent( loggerForwardService, JSON.stringify( logMessage ) );
    };

    /**
     * @param {Function} encodingApi -
     */
    exports.setEncodingAPI = function( encodingApi ) {
        _encodingApi = encodingApi;
    };

    /**
     * @param {Object} hostConfig -
     */
    exports.setHostConfiguration = function( hostConfig ) {
        _hostConfig = hostConfig;

        if( _hostConfig.USE_2015_10_SOA ) {
            _encodingVersion = hostInfServiceConstants.VERSION_2015_10;
        } else if( _hostConfig.USE_2014_07_SOA ) {
            _encodingVersion = hostInfServiceConstants.VERSION_2014_07;
        } else {
            _encodingVersion = hostInfServiceConstants.VERSION_2014_02;
        }
    };

    /**
     * Register this service with the AngularJS application.
     *
     * @returns {Object} Reference to this module's API.
     */
    app.factory( 'soa_kernel_hostSupportService', function() {
        return exports;
    } );

    return exports;
} );