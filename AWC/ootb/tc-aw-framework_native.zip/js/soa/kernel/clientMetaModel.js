// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * Note: Many of the the functions defined in this module return a {@linkcode module:angujar~Promise|Promise} object.
 * The caller should provide callback function(s) to the 'then' method of this returned object (e.g. successCallback,
 * [errorCallback, [notifyCallback]]). These methods will be invoked when the associated service result is known.
 *
 * @module soa/kernel/clientMetaModel
 */
define( [ 'app', 'assert', 'js/iconService' ], function( app, assert, iconSvc ) {
    'use strict';

    /**
     * Object used to implement a typeName-to-PropertyType cache map.
     *
     * @memberof module:soa/kernel/clientMetaModel
     * @private
     */
    var _name2modelType = {};

    /**
     * Regular expression used to test if a string starts with "TYPE::"
     */
    var REGEX_TYPE_PREFIX = /^TYPE::/i;

    var exports = {};

    /**
     * Does client meta model contain type?
     *
     * @param {String} name - property type name.
     * @return {boolean|*}
     */
    exports.containsType = function( name ) {
        assert( name !== null, 'Null type name provided!' );
        return _name2modelType.hasOwnProperty( name );
    };

    /**
     * Get model type by type name.
     *
     * @param name type name
     * @return {*} model type
     */
    exports.getType = function( name ) {
        if( exports.containsType( name ) ) {
            return _name2modelType[name];
        }
        return null;
    };

    /**
     * @param {ModelObject} modelObject - ModelObject to test.
     * @return {Boolean} TRUE if the given ModelObject represents a 'type' object.
     */
    exports.isTypeObject = function( modelObject ) {
        /**
         * Note: We do not want to cache 'types' in the model object cache.
         */
        if( exports.isTypeUid( modelObject.uid ) ) {
            return true;
        }

        return false;
    };

    /**
     * @param {String} uid - UID of a ModelObject to test.
     * @return {Boolean} TRUE if the given ModelObject UID represents a 'type' object.
     */
    exports.isTypeUid = function( uid ) {
        /**
         * Note: We do not want to cache 'types' in the model object cache.
         */
        if( REGEX_TYPE_PREFIX.test( uid ) ) {
            return true;
        }

        return false;
    };

    /**
     * Cache model types into client meta model.
     *
     * @param {ModelTypeArray} modelTypes - Array of {ModelType} objects.
     */
    exports.cacheTypes = function( modelTypes ) {
        var ii, jj, kk, constant;
        for( ii = modelTypes.length - 1; ii >= 0; ii-- ) {
            var modelType = modelTypes[ii];
            // Don't update cache if a model type comes across again
            if( !exports.containsType( modelType.name ) ) {
                var validModelType = modelType.displayName && //
                modelType.parentTypeName !== null && modelType.parentTypeName !== undefined && // empty string for BusinessObject
                modelType.typeHierarchy && //
                modelType.typeUid && //
                modelType.uid;

                if( !validModelType ) {
                    assert( validModelType, 'Invalid model type for ' + modelType.name );
                }

                // To support property processing in CDM during model object caching, create a map of the property descriptors.
                if( !modelType.propertyDescriptors ) {
                    modelType.propertyDescriptors = [];
                }
                modelType.propertyDescriptorsMap = {};
                if( modelType.propertyDescriptors ) {
                    for( jj = modelType.propertyDescriptors.length - 1; jj >= 0; jj-- ) {
                        var propertyDescriptor = modelType.propertyDescriptors[jj];
                        modelType.propertyDescriptorsMap[propertyDescriptor.name] = propertyDescriptor;

                        propertyDescriptor.constantsMap = {};
                        if( propertyDescriptor.constants ) {
                            for( kk = propertyDescriptor.constants.length - 1; kk >= 0; kk-- ) {
                                constant = propertyDescriptor.constants[kk];
                                propertyDescriptor.constantsMap[constant.name] = constant.value;
                            }
                            delete propertyDescriptor.constants; // not used
                        }
                    }
                    delete modelType.propertyDescriptors; // not used
                }

                modelType.constantsMap = {};
                if( modelType.constants ) {
                    for( jj = modelType.constants.length - 1; jj >= 0; jj-- ) {
                        constant = modelType.constants[jj];
                        modelType.constantsMap[constant.name] = constant.value;
                    }
                    delete modelType.constants; // not used
                }

                modelType.typeHierarchyArray = modelType.typeHierarchy.split( ',' );
                delete modelType.typeHierarchy;

                if( !modelType.constantsMap.IconFileName ) {
                    modelType.constantsMap.IconFileName = iconSvc.getTypeIconFileName( modelType );
                }

                delete modelType.className; // not used

                _name2modelType[modelType.name] = modelType;
            }
        }
    };

    /**
     * Register this service with the AngularJS application.
     *
     * @returns {Object} Reference to this module's API.
     */
    app.factory( 'soa_kernel_clientMetaModel', function() {
        return exports;
    } );

    return exports;
} );