// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define,
 defaultAndValidateElementRecurse
 */

/**
 * Note: defaultAndValidateElementRecurse is actually not a global but is part of a recursive algorithm that requires it to be references before it is defined in this module.
 */

/**
 * This is the Teamcenter SOA Service. It's the central pipeline for invoking JSON SOA APIs & FMS APIs from the client.
 *
 * Note: Many of the the functions defined in this module return a {@linkcode module:angujar~Promise|Promise} object.
 * The caller should provide callback function(s) to the 'then' method of this returned object (e.g. successCallback,
 * [errorCallback, [notifyCallback]]). These methods will be invoked when the associated service result is known.
 *
 * @module soa/kernel/soaService
 */
define(
    [ 'app', //
    'lodash', //
    'assert', //
    'httpWrapper', //
    'soaSchema', //
    'soa/kernel/clientDataModel', //
    'soa/kernel/clientMetaModel', //
    'soa/kernel/propertyPolicyService', //
    'js/logService' ], //
    function( app, _, assert, httpWrapper, soaSchema, cdm, cmm, propPolicySvc, logSvc ) {
        'use strict';

        var exports = {};

        /**
         * Boolean to indicate if we're signed into the server.
         *
         * @private
         */
        var _signedIn = false;

        /**
         * Date/Time of the last progress 'start'. This is used to compute the amount of time a single SOA post takes.
         *
         * @private
         */
        var _lastStartDate = {};

        /**
         * Regular expression used to test if a string ends with "[]"
         */
        var REGEX_ARRAY_SUFFIX = /\[\]$/i;

        /**
         * @private
         *
         * @param {Object} state - state object
         * @param {String} typeName - type name
         * @param {Object} bodyElement - body element
         * @param {String} key - key
         * @param {boolean} deleted - was the key just deleted?
         * @return {Void}
         */
        function initializeField( state, typeName, bodyElement, key, deleted ) {
            switch( typeName ) {
            case 'String':
            case 'Date':
                bodyElement[key] = '';
                break;
            case 'int':
            case 'float':
            case 'double':
                bodyElement[key] = 0;
                break;
            case 'boolean':
                bodyElement[key] = false;
                break;
            case 'ModelObj':
            case 'ModelObject':
                bodyElement[key] = {
                    uid: deleted ? 'AAAAAAAAAAAAAA' : '',
                    type: deleted ? 'unknownType' : ''
                };
                break;
            default:
                if( REGEX_ARRAY_SUFFIX.test( typeName ) ) {
                    // Array
                    bodyElement[key] = [];
                } else if( state.schemaService.hasOwnProperty( typeName ) && _.isArray( state.schemaService[typeName] ) ) {
                    // Enum support... default to first entry
                    bodyElement[key] = state.schemaService[typeName][0];
                } else {
                    // Object or map
                    bodyElement[key] = {};
                }
            }
        }

        /**
         * @private
         *
         * @param {Object} state - state object
         * @param {Object} schemaElement - schema element to evaluate to determine if element should be a map
         *
         * @returns {Boolean} TRUE if the given element is in the schema.
         */
        function isMap( state, schemaElement ) {
            if( Object.keys( schemaElement ).length === 2 ) {
                if( schemaElement.hasOwnProperty( 'key' ) && schemaElement.hasOwnProperty( 'value' ) &&
                    !state.schemaService.hasOwnProperty( schemaElement.key ) ) {
                    return true;
                }
            }
            return false;
        }

        /**
         * Validate element type & recurse if non-trivial type.
         *
         * @private
         *
         * @param {Object} state - state object
         * @param {String} typeName - type name
         * @param {Object} bodyElement - body element
         * @returns {Object}
         */
        function validateElementType( state, typeName, bodyElement ) {
            switch( typeName ) {
            case 'String':
            case 'Date':
                if( !_.isString( bodyElement ) ) {
                    state.issues.push( 'INVALID FIELD: Expected string, not ' + typeof bodyElement + ' --' +
                        state.stack.join( '.' ) );
                }
                break;
            case 'int':
            case 'float':
            case 'double':
                if( !_.isNumber( bodyElement ) ) {
                    state.issues.push( 'INVALID FIELD: Expected number, not ' + typeof bodyElement + ' --' +
                        state.stack.join( '.' ) );
                }
                break;
            case 'boolean':
                if( !_.isBoolean( bodyElement ) ) {
                    state.issues.push( 'INVALID FIELD: Expected boolean, not ' + typeof bodyElement + ' --' +
                        state.stack.join( '.' ) );
                }
                break;
            case 'ModelObj':
            case 'ModelObject':
                if( !bodyElement || !bodyElement.uid || !bodyElement.type ) {
                    return {
                        uid: !bodyElement || !bodyElement.uid ? 'AAAAAAAAAAAAAA' : bodyElement.uid,
                        type: !bodyElement || !bodyElement.type ? 'unknownType' : bodyElement.type
                    };
                }
                if( Object.keys( bodyElement ).length !== 2 ) {
                    // replace with new object if it's not already uid & type only
                    return {
                        uid: bodyElement.uid,
                        type: bodyElement.type
                    };
                }
                break;
            default:
                var typeName2 = null;
                if( state.schemaService.hasOwnProperty( typeName ) ) {
                    if( _.isArray( state.schemaService[typeName] ) ) {
                        // Enum
                        if( state.schemaService[typeName].indexOf( bodyElement ) === -1 ) {
                            state.issues.push( 'INVALID FIELD VALUE: Not valid enum value ' + typeName + ' expected ' +
                                state.schemaService[typeName].toString() + ' --' + state.stack.join( '.' ) );
                        }
                    } else {
                        // Object processing
                        defaultAndValidateElementRecurse( state, state.schemaService[typeName], bodyElement );
                    }
                } else if( REGEX_ARRAY_SUFFIX.test( typeName ) ) {
                    // Array processing
                    if( !_.isArray( bodyElement ) ) {
                        state.issues.push( 'INVALID FIELD: Expected array, not ' + typeof bodyElement + ' --' +
                            state.stack.join( '.' ) );
                        return;
                    }
                    typeName2 = typeName.substring( 0, typeName.length - 2 );
                    var replacementArray = null;
                    for( var ii = bodyElement.length - 1; ii >= 0; ii-- ) {
                        state.stack.push( ii );
                        var replacement = validateElementType( state, typeName2, bodyElement[ii] );
                        if( replacement ) {
                            if( !replacementArray ) {
                                // we should probably replace the array in case caller is using for something else...
                                replacementArray = bodyElement.slice( 0 );
                            }
                            replacementArray[ii] = replacement;
                        }
                        state.stack.pop();
                    }
                    if( replacementArray ) {
                        return replacementArray;
                    }
                } else if( typeName.search( /^(String|Int|Bool|Double|Float|Date|Tag)(|Vector)Map/ ) > -1 ) {
                    // Map processing
                    typeName2 = null;
                    if( typeName.indexOf( 'String' ) === 0 ) {
                        typeName2 = 'String';
                    } else if( typeName.indexOf( 'Date' ) === 0 ) {
                        typeName2 = 'Date';
                    } else if( typeName.indexOf( 'Int' ) === 0 ) {
                        typeName2 = 'int';
                    } else if( typeName.indexOf( 'Float' ) === 0 ) {
                        typeName2 = 'float';
                    } else if( typeName.indexOf( 'Double' ) === 0 ) {
                        typeName2 = 'double';
                    } else if( typeName.indexOf( 'Bool' ) === 0 ) {
                        typeName2 = 'boolean';
                    } else if( typeName.indexOf( 'Tag' ) === 0 ) {
                        typeName2 = 'ModelObject';
                    }
                    if( typeName.search( /VectorMap/g ) > -1 ) {
                        typeName2 += '[]';
                    }
                    _.forEach( bodyElement, function( value, key ) {
                        var valueFinal = value;

                        if( !_.isString( key ) ) {
                            state.issues.push( 'INVALID FIELD: Expected string, not ' + typeof key + ' --' +
                                state.stack.join( '.' ) );
                            return;
                        }
                        if( typeName2 ) {
                            if( !bodyElement[key] ) {
                                initializeField( state, typeName2, bodyElement, key, false );
                                valueFinal = bodyElement[key];
                            }
                            state.stack.push( key );
                            var replacement = validateElementType( state, typeName2, valueFinal );
                            if( replacement ) {
                                bodyElement[key] = replacement;
                            }
                            state.stack.pop();
                        } else {
                            state.issues.push( 'INVALID FIELD: Unsupported map type of ' + typeName + ' --' +
                                state.stack.join( '.' ) );
                        }
                    } );
                } else {
                    state.issues.push( 'INVALID FIELD: Unsupported type of ' + typeName + ' --' +
                        state.stack.join( '.' ) );
                }
            }
        }

        /**
         * Recursive method for default & validate SOA operation body.
         *
         * @param {Object} state - state object
         * @param {Object} schemaElement - schema element/cursor for the walk
         * @param {Object} bodyElement - body element/cursor for the walk
         * @private
         */
        function defaultAndValidateElementRecurse( state, schemaElement, bodyElement ) {

            // Walk schema to add any missing fields
            var isMapLcl = isMap( state, schemaElement );

            if( !isMapLcl ) {
                _.forEach( schemaElement, function( typeName, key2 ) {
                    var deleted = false;
                    if( bodyElement.hasOwnProperty( key2 ) ) {
                        if( bodyElement[key2] === null ) {
                            delete bodyElement[key2];
                            deleted = true;
                        }
                    }

                    if( !bodyElement.hasOwnProperty( key2 ) || !bodyElement[key2] ) {
                        initializeField( state, typeName, bodyElement, key2, deleted );
                    }
                } );
            }

            // Walk body element to validate against schema & recurse
            var replacement = null;

            _.forEach( bodyElement, function forEachdefaultAndValidateElementRecurse( value, key2 ) {
                if( isMapLcl ) {
                    if( _.isArray( bodyElement ) ) {
                        for( var ii = 0; ii < bodyElement[0].length; ii++ ) {
                            state.stack.push( ii );
                            replacement = validateElementType( state, schemaElement.key, bodyElement[0][ii] );
                            if( replacement ) {
                                bodyElement[0][ii] = replacement;
                            }
                            replacement = validateElementType( state, schemaElement.value, bodyElement[1][ii] );
                            if( replacement ) {
                                bodyElement[1][ii] = replacement;
                            }
                            state.stack.pop();
                        }
                    } else {
                        for( var mapKey in bodyElement ) {
                            if( bodyElement.hasOwnProperty( key2 ) ) {
                                state.stack.push( key2 );
                                replacement = validateElementType( state, schemaElement.key, mapKey );
                                if( replacement ) {
                                    var oldValue = bodyElement[mapKey];
                                    delete bodyElement[mapKey];
                                    bodyElement[replacement] = oldValue;
                                }
                                replacement = validateElementType( state, schemaElement.value, bodyElement[mapKey] );
                                if( replacement ) {
                                    bodyElement[mapKey] = replacement;
                                }
                                state.stack.pop();
                            }
                        }
                    }
                } else if( schemaElement.hasOwnProperty( key2 ) ) {
                    state.stack.push( key2 );
                    replacement = validateElementType( state, schemaElement[key2], value );
                    if( replacement ) {
                        bodyElement[key2] = replacement;
                    }
                    state.stack.pop();
                } else {
                    state.issues.push( 'INVALID FIELD: Unexpected type of ' + state.stack.join( '.' ) + '.' + key2 );
                    delete bodyElement[key2];
                }
            } );
        }

        /**
         * Default & validate SOA operation body.
         *
         * @param {String} serviceName - service name
         * @param {String} operationName - operation name
         * @param {Object} body - request body
         * @returns {Object} request body with defaulting & validation complete
         * @private
         */
        function defaultAndValidateElement( serviceName, operationName, body ) {
            assert( soaSchema, 'No SOA schema definition found!' );

            var state = {
                // If caller has passed null, they've indicated that there's an empty body.
                body: body ? body : {},
                serviceName: serviceName,
                operationName: operationName,
                schemaService: soaSchema[serviceName],
                issues: [],
                stack: []
            };

            if( state.schemaService ) {
                state.operation = state.schemaService[state.operationName];
                if( state.operation ) {
                    // Walk body make sure it aligns to the soaSchema
                    defaultAndValidateElementRecurse( state, state.operation, state.body );

                    if( state.issues.length > 0 ) {
                        logSvc.error( 'Invalid SOA request body!\n' + state.issues.join( '\n' ) + '\n\nInput body:',
                            state.body );
                    }
                } else {
                    logSvc.error( 'No SOA operation for ' + state.serviceName + ' ' + state.operationName +
                        '! Skipping validation & default of SOA input.' );
                }
            } else {
                logSvc.error( 'No SOA service for ' + state.serviceName +
                    '! Skipping validation & default of SOA input.' );
            }
            return state.body;
        }

        /**
         * Process an array of objects to create a single string of messages.
         *
         * @param {Object} messages - array of objects containing message fields
         * @param {Object} msg - string for messages
         *
         * @returns {Object} msg string with each message on a new line.
         */
        function getMessageString( messages, msg ) {
            _.forEach( messages, function( object ) {
                if( msg.length > 0 ) {
                    msg += '\n';
                }
                msg += object.message;
            } );
            return msg;
        }

        // Response processing

        /**
         * @param {Object} errIn - error in
         *
         * @returns {Object} ...
         */
        function createError( errIn ) {
            var msg = '';
            if( errIn.message ) {
                msg = errIn.message;
            } else if( errIn.status || errIn.statusText ) {
                msg = errIn.status + ' ' + errIn.statusText;
            } else if( errIn.PartialErrors ) {
                _.forEach( errIn.PartialErrors, function( partialError ) {
                    msg = getMessageString( partialError.errorValues, msg );
                } );
            } else if( errIn.partialErrors ) {
                _.forEach( errIn.partialErrors, function( partialError ) {
                    msg = getMessageString( partialError.errorValues, msg );
                } );
            } else if( errIn.messages ) {
                msg = getMessageString( errIn.messages, msg );

            } else {
                msg = errIn.toString();
            }
            if( errIn.data && errIn.data.messages ) {
                msg = getMessageString( errIn.data.messages, msg );
            }
            var error = new Error( msg );
            error.cause = errIn;
            return error;
        }

        /**
         * Process SOA partial exceptions in response.
         *
         * @param {Object} response JSON response data
         * @param {String} serviceName - service name
         * @param {String} operationName - operation name
         * @param {Object} body - response body
         * @return {Object} response JSON response data
         */
        function processExceptions( response, serviceName, operationName, body ) {
            // Should we search for 'Exception' in QName?
            if( response && response.hasOwnProperty( '.QName' ) ) {
                if( response['.QName'].search( 'InvalidUserException$' ) > -1 ) {
                    if( operationName === 'getTCSessionInfo3' ) {
                        // This is the trivial case of initial connection to the server.
                        throw createError( response );
                    }

                    if( _signedIn ) {
                        app.eventBus.publishSoa( "session.stale", {} );

                        // Need to re-authenticate the session & redo the server call
                        // May need to pass the post args into this to handle that & return a promise
                        // How to call getTCSessionInfo3 from here?
                        // Need to move business logic from TCSessionData to JS to support this, including session change event firing
                        return exports.getTCSessionInfo().then( function( response2 ) {
                            return exports.post( serviceName, operationName, body );
                        } );
                    }
                }
                // FIXME this should be conditioned with a QName check...
                if( response['.QName'].search( 'Exception$' ) > -1 ) {
                    throw createError( response );
                }
            }
            return response;
        }

        /**
         * @private
         * @param {Object} parent - parent element
         * @param {ModelObjectArray} modelObjs - Array of {ModelObject} found in response
         * @param {Object} typeNames - array of referenced type names
         */
        function extractModelObjAndTypeFromResponse( parent, modelObjs, typeNames ) {
            _.forEach( parent, function( child, key ) {
//            if( key !== 'ServiceData' ) {
                if( _.isPlainObject( child ) ) {
                    if( child.hasOwnProperty( 'uid' ) && child.hasOwnProperty( 'type' ) ) {
                        if( child.uid && child.uid !== 'AAAAAAAAAAAAAA' ) {
                            modelObjs.push( child );
                        }
                        if( child.type && child.type !== 'unknownType' ) {
                            typeNames[child.type.toString()] = null;
                        }
                    } else {
                        extractModelObjAndTypeFromResponse( child, modelObjs, typeNames );
                    }
                } else if( _.isArray( child ) ) {
                    extractModelObjAndTypeFromResponse( child, modelObjs, typeNames );
                }
//            }
            } );
        }

        /**
         * @private
         * @param {Object} response - Response from SOA service.
         * @param {ModelObjectArray} modelObjs - Array of {ModelObject} from SOA service.
         * @returns {Object} ...
         */
        function processResponseObjects( response, modelObjs ) {
            var serviceData = null;
            if( response ) {
                if( response.hasOwnProperty( '.QName' ) && response['.QName'].search( /\.ServiceData$/ ) > -1 ) {
                    serviceData = response;
                } else if( response.ServiceData ) {
                    // If the service data is a member field, update the service data reference
                    serviceData = response.ServiceData;
                }
            }

            if( modelObjs ) {
                // Add objects to CDM
                cdm.cacheObjects( modelObjs );
            }

            if( serviceData ) {
                if( serviceData.created ) {
                    var createdObjects = [];
                    for( var ii = 0; ii < serviceData.created.length; ii++ ) {
                        var createdObject = cdm.getObject( serviceData.created[ii] );
                        if( createdObject ) {
                            createdObjects.push( createdObject );
                        }
                    }

                    if( createdObjects.length ) {
                        app.eventBus.publishSoa( "cdm.created", {
                            createdObjects: createdObjects
                        } );
                    }
                }

                if( serviceData.updated ) {
                    var updatedObjects = [];
                    for( var ii2 = 0; ii2 < serviceData.updated.length; ii2++ ) {
                        var updatedUid = serviceData.updated[ii2];

                        if( !cmm.isTypeUid( updatedUid ) ) {
                            var updatedObject = cdm.getObject( updatedUid );
                            if( updatedObject ) {
                                updatedObjects.push( updatedObject );
                            }
                        }
                    }

                    if( updatedObjects.length ) {
                        app.eventBus.publishSoa( "cdm.updated", {
                            updatedObjects: updatedObjects
                        } );
                    }
                }

                if( serviceData.deleted ) {
                    // Remove objects from CDM
                    cdm.removeObjects( serviceData.deleted );
                }
            }

            return response;
        }

        /**
         * Process service data in HTTP response.
         *
         * @param {Object} response - JSON response data
         * @param {String} operationName - operation name
         * @return {*} Promise if types were loaded OR response object
         */
        function processResponseTypes( response, operationName ) {
            if( response ) {
                var modelObjs = [], typeNamesObj = {};
                if( response['.QName'] !== 'http://teamcenter.com/Schemas/Soa/2011-06/MetaModel.TypeSchema' ) {
                    extractModelObjAndTypeFromResponse( response, modelObjs, typeNamesObj );
                }

                var typeNames = Object.keys( typeNamesObj );
                if( operationName === 'login' || operationName === 'getTCSessionInfo3' ) {
                    typeNames = typeNames.concat( [ 'AW2_Prop_SupportRevision', 'Awp0FullTextSavedSearch',
                        'Awp0GatewayTileRel', 'Awp0Tile', 'Awp0TileCollection', 'Awp0TileTemplate', 'Awp0XRTObjectSet',
                        'Awp0XRTObjectSetColumn', 'Awp0XRTObjectSetRow', 'Dataset', 'DocumentRevision', 'EPMTask',
                        'Fnd0ConditionHelper', 'Fnd0HomeFolder', 'Group', 'GroupMember', 'ImanType', 'ImanVolume',
                        'ItemRevision', 'Mail Folder', 'Newstuff Folder', 'POM_application_object', 'POM_imc',
                        'ProposedResponsibleParty', 'ProposedReviewer', 'Role', 'Signoff', 'User', 'UserSession',
                        'WorkspaceObject', 'Fnd0ClientScope', 'Fnd0Command', 'Fnd0CommandCollection', 'Fnd0Icon',
                        'Fnd0UIConfigCollectionRel' ] );
                }
                var promise = null;
                if( typeNames.length > 0 ) {
                    promise = exports.ensureModelTypesLoaded( typeNames, response );
                }

                if( promise ) {
                    promise.then( function() {
                        // Just in case we have more types, let's go get them...
                        return processResponseObjects( response, modelObjs );
                    } );
                    return promise;
                }
                return processResponseObjects( response, modelObjs );
            }
            return response;
        }

        /**
         * SOA post unchecked.
         *
         * @param {String} serviceName - SOA service name
         * @param {String} operationName - SOA operation name
         * @param {String} body - JSON body
         * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
         *          data is available.
         */
        exports.postUnchecked = function( serviceName, operationName, body ) {
            assert( serviceName, 'Service name not provided!' );
            assert( operationName, 'Operation name not provided!' );

            var hosted = app.hostSupportService && app.hostSupportService.isSoaHosted();

            var jsonData = {
                header: {
                    state: {
                        /**
                         * The ID used for identification of this client
                         *
                         *        D-30368 This value must be kept in sync in all instances where it is used.  See defect
                         *        if change is required.
                         *
                         */
                        clientID: 'ActiveWorkspaceClient',
                        clientVersion: '10000.1.2',
                        /**
                         * Correlation ID for logging purposes (debug).
                         */
                        logCorrelationID: logSvc.getCorrelationID() + '-' + _.now(),
                        /**
                         * Permanent ID/recipes are used for the runtime business object’s (BOMLine objects) opaque UIDs
                         * in requests/responses.
                         * <p>
                         * If the unloadObjects key is not in the request headers, all business objects are unloaded at
                         * the top of each request; see the processTagManager ITK for more information.
                         */
                        stateless: true,
                        /**
                         * If true, All business objects are unloaded at the top of each request; see the
                         * processTagManager ITK for more information. Previously controlled through the stateless flag.
                         * <p>
                         * When is stateless=true mode this value must be explicitly set to false to keep objects
                         * loaded.
                         */
                        unloadObjects: '{{soaCacheUnloadFlag}}',
                        /**
                         * If true, process server-session state key/value pairs found in the request headers. This
                         * turns all session state into client-session data. The standalone AW client should set this to
                         * true, while the hosted AW client should set it false (or not send it at all).
                         */
                        enableServerStateHeaders: !hosted,
                        /**
                         */
                        formatProperties: true
                    },
                    policy: propPolicySvc.getEffectivePolicy()
                },
                body: defaultAndValidateElement( serviceName, operationName, body )
            };

            var userSession = cdm.getUserSession();
            var groupMember = cdm.getGroupMember();

            if( groupMember ) {
                jsonData.header.state.groupMember = groupMember.uid;
            }

            if( userSession && userSession.props ) {
                if( userSession.props.role_name ) {
                    jsonData.header.state.role = userSession.props.role_name.dbValues[0];
                }
                if( userSession.props.fnd0locale ) {
                    jsonData.header.state.locale = userSession.props.fnd0locale.dbValues[0];
                }
            }

            var endPt = serviceName + '/' + operationName;

            if( logSvc.isTraceEnabled() ) {
                logSvc.trace( '\n' + 'soaService.post to ' + endPt, jsonData );
            }

            app.eventBus.publishSoa( 'progress.start', {
                endPoint: endPt
            } );

            /**
             * Check if there is a 'host' process that is handling SOA processing<BR>
             * If so: Send the 'endPt' and data to that service.
             */
            var promise;
            if( hosted ) {
                promise = app.hostSupportService.post( serviceName, operationName, jsonData );
            } else {
                promise = httpWrapper.post( cdm.getBaseURL() + 'tc/JsonRestServices/' + endPt, jsonData );
            }

            return promise.then( function( response ) {
                app.eventBus.publishSoa( 'progress.end', {
                    endPoint: endPt
                } );
                if( logSvc.isTraceEnabled() ) {
                    logSvc.trace( 'endPt=' + endPt, response );
                }
                return processExceptions( response, serviceName, operationName, body );
            }, function( err ) {
                app.eventBus.publishSoa( 'progress.end', {
                    endPoint: endPt
                } );
                throw createError( err );
            } ).then( function( response ) {
                if( endPt.indexOf( '/logout' ) > -1 ) {
                    httpWrapper.clearJSessionID();
                }
                return response;
            } ).then( function( response ) {
                return processResponseTypes( response, operationName );
            } );
        };

        /**
         * SOA post.
         *
         * If the response contains partial errors, it will be treated as an exception & thrown. If this isn't desired,
         * use postUnchecked.
         *
         * @param {String} serviceName - SOA service name
         * @param {String} operationName - SOA operation name
         * @param {String} body - JSON body
         * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
         *          data is available.
         */
        exports.post = function( serviceName, operationName, body ) {
            return exports.postUnchecked( serviceName, operationName, body ).then( function( response ) {
                if( response ) {
                    if( response.partialErrors || response.PartialErrors ) {
                        throw createError( response );
                    }
                    if( response.ServiceData && response.ServiceData.partialErrors ) {
                        throw createError( response.ServiceData );
                    }
                }
                return response;
            } );
        };

        /**
         * @param {String} serviceName - SOA service name
         * @param {String} operationName - SOA operation name.
         * @param {Object} body - The object that represents the operation request. It is optional and may be partial.
         */
        exports.Operation = function( serviceName, operationName, body ) {
            /**
             * SOA service name
             *
             * @private
             */
            this._serviceName = serviceName;

            /**
             * SOA operation name
             *
             * @private
             */
            this._operationName = operationName;

            /**
             * The object that represents the operation request body.
             *
             * @private
             */
            this._body = body ? body : {};

            /**
             * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its
             *          response data is available.
             */
            this.execute = function() {
                return exports.post( this._serviceName, this._operationName, this._body );
            };

            /**
             * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its
             *          response data is available.
             */
            this.executeUnchecked = function() {
                return exports.postUnchecked( this._serviceName, this._operationName, this._body );
            };

            return this;
        };

        /**
         * Set session information into local storage (if needed)
         *
         * @param {Boolean} signOut - sign out
         */
        exports.setSessionInfo = function( signOut ) {
            var userSession = signOut ? null : cdm.getUserSession();
            if( userSession && userSession.props ) {
                var awSession = userSession.props.group_name.dbValues[0] + ',' //
                    + userSession.props.role_name.dbValues[0] + ',' //
                    + userSession.props.fnd0locale.dbValues[0];
                app.eventBus.publishLocalStorage( 'awSession', awSession );
            } else {
                app.eventBus.publishLocalStorage( 'awSession' );
            }
        };

        /**
         * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
         *          data is available.
         */
        exports.getTCSessionInfo = function() {
            // Ensure we have the required properties for the UserSession.
            var policyId = propPolicySvc.register( {
                types: [ {
                    name: 'UserSession',
                    properties: [ {
                        name: 'user'
                    }, {
                        name: 'group'
                    }, {
                        name: 'role'
                    }, {
                        name: 'role_name'
                    }, {
                        name: 'fnd0locale'
                    }, {
                        name: 'fnd0groupmember'
                    } ]
                } ]
            } );
            return exports.post( 'Internal-AWS2-2013-12-DataManagement', 'getTCSessionInfo3' ).then(
                function( response ) {
                    propPolicySvc.unregister( policyId );
                    exports.setSessionInfo();
                    return response;
                } );
        };

        /**
         * Get Type Descriptions from server.
         *
         * Note, this is hidden in this file to avoid anyone else directly calling this.
         *
         * @param typeNames array of type names
         * @return {deferred.promise|*}
         * @private
         */
        function getTypeDescriptions( typeNames ) {
            assert( typeNames && typeNames.length > 0, 'No type names provided!' );
            typeNames.sort();
            var typeNamesFinal = _.unique( typeNames, true );
            return exports.post( 'Core-2015-10-Session', 'getTypeDescriptions2', {
                typeNames: typeNamesFinal,
                options: {
                    TypeExclusions: [ "ToolInfo", "DirectChildTypesInfo", "RevisionNamingRules" ],
                    PropertyExclusions: [ "RendererReferences", "NamingRules" ]
                }
            } );
        }

        /**
         * List of type names which have been deemed invalid based upon the previous server responses.
         *
         * @private
         */
        var _invalidTypeNames = [ 'contents' ];

        /**
         * @param typeNames array of type names to ensure cached
         * @param response JSON response data
         * @return {Promise} promise
         */
        exports.ensureModelTypesLoaded = function( typeNames, response ) {
            if( !typeNames || typeNames.length === 0 ) {
                // trivial case
                return;
            }

            // From the input list of type names, get a list of unique type names not in the CMM already.
            var missingTypeNames = [];
            _.forEach( typeNames, function( typeName ) {
                if( !cmm.containsType( typeName ) && _invalidTypeNames.indexOf( typeName ) === -1 ) {
                    missingTypeNames.push( typeName );
                }
            } );
            var promise = null;
            if( missingTypeNames.length > 0 ) {
                promise = getTypeDescriptions( missingTypeNames ).then( function( responseGetTypeDescriptions ) {
                    // Cache the types
                    if( responseGetTypeDescriptions && responseGetTypeDescriptions.types ) {
                        cmm.cacheTypes( responseGetTypeDescriptions.types );
                    }
                    return response;
                } ).then( function() {
                    // Capture invalid type names
                    _.forEach( missingTypeNames, function( typeName ) {
                        if( !cmm.containsType( typeName ) ) {
                            // add empty type to avoid future server calls
                            _invalidTypeNames.push( typeName );
                            _invalidTypeNames.sort();
                            _invalidTypeNames = _.unique( _invalidTypeNames, true );
                        }
                    } );
                    return response;
                } );
            }

            return promise;
        };

        app.eventBus.subscribeSoa( 'session.signIn', function( data, envelope ) {
            _signedIn = true;
        } );

        app.eventBus.subscribeSoa( 'session.signOut', function( data, envelope ) {
            _signedIn = false;
        } );

        /**
         * Setup to log all events fired on the 'soajs' eventBus event channel.
         */
        if( logSvc && logSvc.isTraceEnabled() ) {
            app.eventBus.subscribeSoa( '#', function( data, envelope ) {
                var msg = 'eventBus: ' + envelope.topic + ' @ ' + envelope.timeStamp;

                if( envelope.topic === 'progress.start' ) {
                    _lastStartDate[data.endPoint] = envelope.timeStamp;
                } else if( envelope.topic === 'progress.end' && _lastStartDate[data.endPoint] ) {
                    var msDelta = envelope.timeStamp.getTime() - _lastStartDate[data.endPoint].getTime();

                    msg = msg + '\n' + '          Time: ' + msDelta + 'ms' + '    ' + data.endPoint;

                    _lastStartDate[data.endPoint] = null;
                }

                if( logSvc.isTraceEnabled() ) {
                    logSvc.trace( msg, envelope );
                }
            } );
        }

        /**
         * Register this service with the A *
         *
         * @returns {Object} Reference to this module's API. to this module's API.
         */
        app.factory( 'soa_kernel_soaService', function() {
            return exports;
        } );

        return exports;
    } );
