// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * This module is used to aggregate all the other modules at this API level. This aggregate is used during the war
 * build's 'optimization' step.
 */
define( [ //
'soa/kernel/clientDataModel', //
'soa/kernel/clientMetaModel', //
'soa/kernel/hostSupportService', //
'soa/kernel/propertyPolicyService', //
'soa/kernel/soaService' //
], function() {
    'use strict';
} );
