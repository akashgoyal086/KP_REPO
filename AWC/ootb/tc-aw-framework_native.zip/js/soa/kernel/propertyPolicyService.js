// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * Note: Many of the the functions defined in this module return a {@linkcode module:angujar~Promise|Promise} object.
 * The caller should provide callback function(s) to the 'then' method of this returned object (e.g. successCallback,
 * [errorCallback, [notifyCallback]]). These methods will be invoked when the associated service result is known.
 *
 * @module soa/kernel/propertyPolicyService
 */
define( [ 'app', 'lodash', 'assert', 'js/logService', 'js/dateTimeService' ], function( app, _, assert, logSvc,
    dateTimeSvc ) {
    'use strict';

    var exports = {};

    /**
     * Map of policy id to registered policy.
     *
     * @private
     */
    exports._policyId2policy = {};

    /**
     * Registration of time stamp for property policies.
     *
     * @private
     */

    var policyId2registrationTimeStamp = {};

    /**
     * Registration counter for property policies.
     *
     * @private
     */
    exports._policyCount = 0;

    /**
     * Effective property policy for subsequent server calls.
     *
     * @private
     */
    exports._effectivePolicy = {};

    /**
     * Sort input array by name field of elements.
     *
     * @param array array to sort
     * @private
     */
    function sort( array ) {
        if( array ) {
            array.sort( function( a, b ) {
                return a.name.localeCompare( b.name );
            } );
        }
    }

    /**
     * Merge modifier into modifier array.
     *
     * @param {Array} modifiers - array of modifiers
     * @param {Object} modifierToMerge - modifier to merge into array
     * @private
     */
    function mergeModifier( modifiers, modifierToMerge ) {
        var modifier = _.find( modifiers, _.matchesProperty( 'name', modifierToMerge.name ) );
        if( !modifier ) {
            modifier = {
                name: modifierToMerge.name,
                Value: modifierToMerge.Value
            };
            modifiers.push( modifier );
        } else {
            assert( modifier.Value === modifierToMerge.Value, 'Modifier conflict!' );
        }
    }

    /**
     * Merge property into property array.
     *
     * @param {Array} properties - array of properties
     * @param {Object} propertyToMerge - property to merge into array
     * @private
     */
    function mergeProperty( properties, propertyToMerge ) {
        var property = _.find( properties, _.matchesProperty( 'name', propertyToMerge.name ) );
        if( !property ) {
            property = {
                name: propertyToMerge.name
            };
            properties.push( property );
        }
        if( propertyToMerge.modifiers && propertyToMerge.modifiers.length > 0 ) {
            if( !property.modifiers ) {
                property.modifiers = [];
            }
            _.forEach( propertyToMerge.modifiers, function( modifier ) {
                mergeModifier( property.modifiers, modifier );
            } );
        }
    }

    /**
     * Merge type into type array.
     *
     * @param {Array} types - array of types
     * @param {Object} typeToMerge - type to merge into array
     * @private
     */
    function mergeType( types, typeToMerge ) {
        var type = _.find( types, _.matchesProperty( 'name', typeToMerge.name ) );
        if( !type ) {
            type = {
                name: typeToMerge.name
            };
            types.push( type );
        }
        if( typeToMerge.properties && typeToMerge.properties.length > 0 ) {
            if( !type.properties ) {
                type.properties = [];
            }
            _.forEach( typeToMerge.properties, function( property ) {
                mergeProperty( type.properties, property );
            } );
        }
        if( typeToMerge.modifiers && typeToMerge.modifiers.length > 0 ) {
            if( !type.modifiers ) {
                type.modifiers = [];
            }
            _.forEach( typeToMerge.modifiers, function( modifier ) {
                mergeModifier( type.modifiers, modifier );
            } );
        }
    }

    /**
     * Effective property policy for use by Teamcenter SOA server call header.
     *
     * @return {Object} effective property policy
     */
    exports.getEffectivePolicy = function() {
        if( !exports._effectivePolicy ) {
            var effectivePolicy = {
                useRefCount: false
            // do we need to set this? ie does the server default to zero anyway?
            };

            _.forEach( exports._policyId2policy, function( policy, policyId ) {
                if( policy.types ) {
                    if( !effectivePolicy.types ) {
                        effectivePolicy.types = [];
                    }
                    _.forEach( policy.types, function( type ) {
                        mergeType( effectivePolicy.types, type );
                    } );
                }

                if( policy.modifiers && policy.modifiers.length > 0 ) {
                    if( !effectivePolicy.modifiers ) {
                        effectivePolicy.modifiers = [];
                    }
                    _.forEach( policy.modifiers, function( modifier ) {
                        mergeModifier( effectivePolicy.modifiers, policy.modifier );
                    } );
                }
            } );

//            // Sort the effective policy for debug purposes
//            sort( effectivePolicy.types );
//            if( effectivePolicy.types ) {
//                _.forEach( effectivePolicy.types, function( type ) {
//                    sort( type.modifiers );
//                    if( type.properties ) {
//                        sort( type.properties );
//                        _.forEach( type.properties, function( property ) {
//                            sort( property.modifiers );
//                        } );
//                    }
//                } );
//            }
//            sort( effectivePolicy.modifiers );

            exports._effectivePolicy = effectivePolicy;
        }
        return exports._effectivePolicy;
    };

    /**
     * Register property policy.
     *
     * @param {Object} policy - property policy
     * @param {String} policyString - property policy string
     * @return {string} property policy ID
     */
    exports.register = function( policy, policyString ) {
        var policyFinal = policy;

        var timeS = _.now();

        if( !policyFinal ) {
            policyFinal = JSON.parse( policyString );
        }

        var nextId = ++exports._policyCount;

        // Create policy id
        var policyId = 'policy' + nextId;

        // Cache policy
        exports._policyId2policy[policyId] = policyFinal;

        // Clear cache of effective policy
        exports._effectivePolicy = null;

        var currentTime = dateTimeSvc.formatTime( timeS );

        if( logSvc.isTraceEnabled() ) {
            logSvc.trace( 'Register Property Policy Id: ' + policyId + ' TimeStamp: ' + currentTime + ' Policy data:',
                policyFinal );
        }

        if( policyString ) {
            policyId2registrationTimeStamp[policyId] = {
                time: currentTime,
                policy: policyFinal
            };
        }

        // Return new cached policy id
        return policyId;
    };

    /**
     * Register property policy.
     *
     * @param {String} policyId - cached property policy ID
     */
    exports.unregister = function( policyId ) {
        if( exports._policyId2policy.hasOwnProperty( policyId ) ) {
            delete exports._policyId2policy[policyId];

            if( logSvc.isTraceEnabled() ) {
                logSvc.trace( 'Unregister Property Policy Id: ' + policyId + ' TimeStamp: ' +
                    dateTimeSvc.formatTime( _.now() ) );
            }

            delete policyId2registrationTimeStamp[policyId];
            // Clear cache of effective policy
            exports._effectivePolicy = null;
        }
    };

    /**
     * Register property policy.
     *
     * @param {String} policyId - existing registered property policy ID
     * @param {Object} policy - property policy
     * @param {String} policyString - property policy string
     */
    exports.addToObjectPropertyPolicy = function( policyId, policy, policyString ) {
        var policyFinal = policy;

        if( !policyFinal ) {
            policyFinal = JSON.parse( policyString );
        }

        if( exports._policyId2policy.hasOwnProperty( policyId ) ) {
            var existingPolicy = exports._policyId2policy[policyId];

            if( policyFinal.types ) {
                if( !existingPolicy.types ) {
                    existingPolicy.types = [];
                }

                _.forEach( policyFinal.types, function( type ) {
                    mergeType( existingPolicy.types, type );
                } );
            }

            if( policyFinal.modifiers ) {
                if( !existingPolicy.modifiers ) {
                    existingPolicy.modifiers = [];
                }

                _.forEach( policyFinal.modifiers, function( modifier ) {
                    mergeModifier( existingPolicy.modifiers, policyFinal.modifier );
                } );
            }

            // Clear cache of effective policy
            exports._effectivePolicy = null;
        }
    };
    /**
     * Remove content from cached object property policy.
     *
     * @param {String} policyId - cached property policy ID
     * @param {Object} policy - property policy to modify cached property policy
     */
    exports.removeFromObjectPropertyPolicy = function( policyId, policy ) {
        if( exports._policyId2policy.hasOwnProperty( policyId ) ) {
            var existingPolicy = exports._policyId2policy[policyId];
            if( policy.types ) {
                _.forEach( policy.types, function( type ) {
                    var existingType = _.find( existingPolicy.types, _.matchesProperty( 'name', type.name ) );
                    if( existingType ) {
                        if( type.properties ) {
                            _.forEach( type.properties, function( property ) {
                                if( property ) {
                                    var existingProp = _.find( existingType.properties, _.matchesProperty( 'name',
                                        property.name ) );
                                    if( property.modifiers ) {
                                        _.forEach( property.modifiers, function( modifier ) {
                                            _
                                                .remove( existingProp.modifiers, _.matchesProperty( 'name',
                                                    modifier.name ) );
                                        } );
                                    } else {
                                        _.remove( existingType.properties, _
                                            .matchesProperty( 'name', existingProp.name ) );
                                    }
                                }
                            } );
                        }
                        if( type.modifiers ) {
                            _.forEach( type.modifiers, function( modifier ) {
                                _.remove( existingType.modifiers, _.matchesProperty( 'name', modifier.name ) );
                            } );
                        }
                    } else {
                        logSvc.error( 'Attempt to remove modifiers from a missing type: ' + type.name );
                    }
                } );
            }
            if( policy.modifiers ) {
                _.forEach( policy.modifiers, function( modifier ) {
                    _.remove( existingPolicy.modifiers, _.matchesProperty( 'name', modifier.name ) );
                } );
            }
            // Clear cache of effective policy
            exports._effectivePolicy = null;
        }
    };

    /**
     * Catch the event for logging all registered policies in the current session and logging the effective policy in
     * the session
     */

    app.eventBus.subscribeSoa( "cdm.logDiagnostics", function( data, envelope ) {
        _.forEach( policyId2registrationTimeStamp, function( times, policyId ) {
            logSvc.debug( 'Registered Property Policy Id "' + policyId + '" @ ' + times.time + ':', times.policy );
        } );

        logSvc.debug( 'Effective Property Policy in session:', exports.getEffectivePolicy() );
    } );

    /**
     * @param modelObjects array of model objects
     * @param propNames array of property names
     */
    exports.validatePropertyRegistration = function( modelObjects, propNames ) {
        var policy = exports.getEffectivePolicy();
        var msg = '';
        _.forEach( modelObjects, function( modelObject ) {
            if( modelObject ) {
                var modelType = modelObject.modelType;
                _.forEach( propNames, function( propName ) {
                    if( modelType.propertyDescriptorsMap.hasOwnProperty( propName ) && policy.types ) {
                        var found = false;
                        for( var kk = 0; kk < policy.types.length && !found; kk++ ) {
                            var type = policy.types[kk];
                            if( type.properties && modelType.typeHierarchyArray.indexOf( type.name ) > -1 ) {
                                for( var ll = 0; ll < type.properties.length && !found; ll++ ) {
                                    var property = type.properties[ll];
                                    if( property.name === propName ) {
                                        found = true;
                                    }
                                }
                            }
                        }
                        if( !found ) {
                            msg += '\n\tType [' + modelType.displayName + '] PropertyName [' + propName + ']';
                        }
                    }
                } );
            }
        } );

        if( msg ) {
            logSvc.debug( 'Property Policy registration is missing for the following:' + msg );
        }
    };

    /**
     * Register this service with the AngularJS application.
     *
     * @returns {Object} Reference to this module's API.
     */
    app.factory( 'soa_kernel_propertyPolicyService', function() {
        return exports;
    } );

    return exports;
} );
