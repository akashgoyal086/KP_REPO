// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 localStorage
 */

/**
 * Note: Many of the the functions defined in this module return a {@linkcode module:angujar~Promise|Promise} object.
 * The caller should provide callback function(s) to the 'then' method of this returned object (e.g. successCallback,
 * [errorCallback, [notifyCallback]]). These methods will be invoked when the associated service result is known.
 *
 * @module soa/favoritesService
 */
define( [ 'app', 'lodash', 'q', 'soa/kernel/clientDataModel', 'soa/kernel/soaService' ], function( app, _, Q, cdm,
    soaSvc ) {
    'use strict';

    var exports = {};

    /**
     * Cache of favorites.
     */
    var _favs = null;

    /**
     * Current promise to get favorites. To avoid multiple calls.
     */
    var _currentPromise = null;

    /**
     * Fire event to indicate change in favorites.
     */
    function fireChangeEvent() {
        app.eventBus.publishSoa( 'favorites.changed', {} );
    }

    /**
     * Query the server for the favorites.
     *
     * @param {Boolean} force - force server call to refresh list
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.getFavorites = function( force ) {
        if( _currentPromise ) {
            return _currentPromise;
        }

        var firstCall = _favs === null;
        if( _favs !== null ) {
            if( !force ) {
                var deferred = Q.defer();
                deferred.resolve( _favs );
                return deferred.promise;
            }
        } else {
            _favs = [];
        }
        _currentPromise = soaSvc.post( 'Core-2010-04-Session', 'getShortcuts', {
            'shortcutInputs': {
                'FavoritesSection': 'My Favorites'
            }
        } ).then( function( response ) {
            _currentPromise = null;

            var newFavs = [];
            if( response.favorites && response.favorites.objects ) {
                for( var ii = 0; ii < response.favorites.objects.length; ii++ ) {
                    newFavs.push( cdm.getObject( response.favorites.objects[ii].objectTag.uid ) );
                }
            }

            if( firstCall || !_.isEqual( _favs, newFavs ) ) {
                _favs = newFavs;
                fireChangeEvent();
            }

            return _favs;
        } );

        return _currentPromise;
    };

    /**
     * Query the server for the favorites.
     *
     * @returns {Promise} This promise will be 'resolved' or 'rejected' when the service is invoked and its response
     *          data is available.
     */
    exports.getCachedFavorites = function() {
        if( _favs === null ) {
            exports.getFavorites();
        }
        return _favs;
    };

    /**
     * Update the favorites on the server.
     */
    function updateFavorites() {
        var input = {
            input: {
                newFavorites: {
                    objects: []
                }
            }
        };
        _.forEach( _favs, function( modelObj ) {
            input.input.newFavorites.objects.push( {
                objectTag: modelObj,
                displayName: modelObj.props.object_string.uiValues[0],
                parentId: '0000'
            } );
        } );
        soaSvc.post( 'Core-2008-03-Session', 'setFavorites', input ).then( function() {
            fireChangeEvent();
        } );
    }

    /**
     * @param {Array} modelObjs - array of model objects to add to favorites
     */
    exports.addFavorites = function( modelObjs ) {
        if( modelObjs && modelObjs.length > 0 ) {
            var updated = false;
            _.forEach( modelObjs, function( modelObj ) {
                if( modelObj && _favs.indexOf( modelObj ) === -1 ) {
                    _favs.push( modelObj );
                    updated = true;
                }
            } );
            if( updated ) {
                updateFavorites();
            }
        }
    };

    /**
     * @param {Array} modelObjs - array of model objects to remove from favorites
     */
    exports.removeFavorites = function( modelObjs ) {
        if( modelObjs && modelObjs.length > 0 ) {
            var updated = false;
            _.forEach( modelObjs, function( modelObj ) {
                if( modelObj && _favs.indexOf( modelObj ) > -1 ) {
                    _favs.splice( _favs.indexOf( modelObj ), 1 );
                    updated = true;
                }
            } );
            if( updated ) {
                updateFavorites();
            }
        }
    };

    // Listen for when objects are deleted to the CDM
    app.eventBus.subscribeSoa( "cdm.deleted", function( data, envelope ) {
        // If deleted objects are in the history, remove them now.
        if( _favs && _favs.length > 0 && data.deletedObjectUids && data.deletedObjectUids.length > 0 ) {
            var update = false;
            _.forEach( _favs, function( modelObj ) {
                if( data.deletedObjectUids.indexOf( modelObj.uid ) > -1 ) {
                    update = true;
                }
            } );
            if( update ) {
                // clear the cache to ensure we query the server to refresh
                _favs = null;
            }
        }
    } );

    /**
     * Register this service with the AngularJS application.
     *
     * @returns {favoritesService} Reference to this module's API.
     */
    app.factory( 'soa_favoritesService', function() {
        return exports;
    } );

    return exports;
} );