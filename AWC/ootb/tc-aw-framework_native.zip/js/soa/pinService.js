// @<COPYRIGHT>@
// ==================================================
// Copyright 2015.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */

/**
 * Note: Many of the the functions defined in this module return a {@linkcode module:angujar~Promise|Promise} object.
 * The caller should provide callback function(s) to the 'then' method of this returned object (e.g. successCallback,
 * [errorCallback, [notifyCallback]]). These methods will be invoked when the associated service result is known.
 *
 * @module soa/preferenceService
 */
define( [ 'app', 'soa/kernel/clientDataModel', 'soa/kernel/propertyPolicyService', 'soa/dataManagementService' ],
    function( app, cdm, propPolicySvc, dmSvc ) {
        'use strict';

        var exports = {};

        /** business obj name for Tile */
        var TILE_BO_NAME = 'Awp0Tile';

        /** tile template ID for pinning objects */
        var PINNED_OBJ_TEMPLATE_ID = 'Awp0PinnedObjectTemplate';

        /** tile template ID for pinning saved search objects */
        var PINNED_SAVEDSEARCH_TEMPLATE_ID = 'Awp0PinnedSavedSearchTemplate';

        /** object type for saved search */
        var SAVEDSEARCH_OBJ_TYPE = 'SavedSearch';

        /** business object name for the tile relation */
        var RELATION_BO_NAME = 'Awp0GatewayTileRel';

        /** Object name property */
        var OBJECT_NAME = 'object_name';

        /**
         * @param {Object} gatewayPropertyPolicy - gateway property policy
         * @param {ModelObject} lastRelation - last relation modelobject (JSO)
         * @param {ModelObjectArray} modelObjs - Array of Model Objects
         * @param {StringArray} params - passed in params
         * @param {String} objType - passed in object type
         *
         * @return {Promise} Promise that will be resolved or rejected.
         */
        exports.pinObjects = function( gatewayPropertyPolicy, lastRelation, modelObjs, params, objType ) {
            var paramsFinal = params;

            if( lastRelation && modelObjs && modelObjs.length > 0 ) {
                var gatewayPolicyName = propPolicySvc.register( null, gatewayPropertyPolicy );

                var modelObject = modelObjs[0];
                var templateId = PINNED_OBJ_TEMPLATE_ID;
                var tileName = modelObject.props[OBJECT_NAME].uiValues[0];

                if( objType && SAVEDSEARCH_OBJ_TYPE === objType ) {
                    templateId = PINNED_SAVEDSEARCH_TEMPLATE_ID;
                }

                if( !paramsFinal || paramsFinal.length === 0 ) {
                    paramsFinal = ';uid=' + modelObject.uid;
                }

                return dmSvc.createObjects( [ {
                    data: {
                        boName: TILE_BO_NAME,
                        stringProps: {
                            awp0TileTemplateId: templateId,
                            object_name: tileName,
                            awp0DisplayName: tileName,
                            awp0Params: paramsFinal
                        },
                        tagProps: {
                            awp0ObjectRef: modelObject
                        }
                    }
                } ] ).then( function( response ) {

                    propPolicySvc.unregister( gatewayPolicyName );

                    var tileCollection = null;
                    var newTile = cdm.getObject( response.output[0].objects[0].uid );
                    var relType = cdm.getObject( lastRelation.props.relation_type.dbValues[0] );
                    if( lastRelation && lastRelation.props && lastRelation.props.primary_object ) {
                        tileCollection = cdm.getObject( lastRelation.props.primary_object.dbValues[0] );
                    }

                    if( !tileCollection ) {
                        return;
                    }

                    return dmSvc.createObjects( [ {
                        data: {
                            boName: RELATION_BO_NAME,
                            stringProps: {
                                awp0Group: 'Pinnedtiles'
                            },
                            intProps: {
                                awp0OrderNo: parseInt( lastRelation.props.awp0OrderNo.uiValues[0], 10 ) + 1,
                                awp0Size: 0
                            },
                            tagProps: {
                                relation_type: relType,
                                primary_object: tileCollection,
                                secondary_object: newTile
                            }
                        }
                    } ] );
                } );
            }
        };

        /**
         * Register this service with the AngularJS application.
         *
         * @returns {pinService} Reference to this module's API.
         */
        app.factory( 'soa_pinService', function() {
            return exports;
        } );

        return exports;
    } );