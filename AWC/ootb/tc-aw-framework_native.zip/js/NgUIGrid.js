//@<COPYRIGHT>@
//==================================================
//Copyright 2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 awInclude
 */

/**
 * @module js/NgUiGrid - ng ui-grid implementation for table properties (used only by NgTableProperty.js)
 */
define(
    [ 'app', 'angular', 'jquery', 'ui.grid', 'js/NgProperty' ],
    function( app, ngModule, $ ) {
        'use strict';

        var exports = {};

        /**
         * Defines the grid controller
         *
         * @constructor awPropertyController
         *
         * @memberof NgControllers
         */
        app
            .controller(
                'awGridController',
                [
                    '$scope',
                    '$timeout',
                    'uiGridConstants',
                    'rowSorter',
                    function( $scope, $timeout, uiGridConstants, rowSorter ) {
                        var self = this;
                        self.rowSorter = rowSorter;
                        var firstColumn = {
                            name: "",
                            field: "Select",
                            displayName: '', // empty
                            cellTemplate: '<div><aw-matrix-row-header context="row.entity"/></div>',
                            pinnedLeft: true,
                            enableColumnMenu: false, // hides all the column header stuff in this field - should be blank.
                            enableSorting: true,
                            width: 21,
                            visible: true
                        };
                        var columnDefinitions = [];

                        self.createColDef = function( field ) {
                            var colDef = {};
                            colDef.field = field.name;
                            colDef.name = field.name;
                            colDef.type = field.dataType;
                            colDef.displayName = field.displayName;
                            if( field.cellTemplateStr ) {
                                colDef.cellTemplate = field.cellTemplateStr;
                            } else {
                                colDef.cellTemplate = '<aw-property-native-table-prop-val prop="row.entity[col.field]" edit="gridOverlay.editable" />';
                            }
                            if( field.name === $scope.gridOverlay.sortBy ) {
                                var defaultSort = {};
                                if( $scope.gridOverlay.sortDirection === "ascending" ) {
                                    defaultSort.direction = uiGridConstants.ASC;
                                } else {
                                    defaultSort.direction = uiGridConstants.DESC;
                                }
                                colDef.sort = defaultSort;
                            }
                            colDef.sortingAlgorithm = function( a, b ) {
                                var nulls = rowSorter.handleNulls( a, b );
                                if( nulls !== null ) {
                                    return nulls;
                                }
                                if( colDef.type === "INTEGER" || colDef.type === "FLOAT" || colDef.type === "DOUBLE" ) {
                                    if( Number(a.uiValue) === Number(b.uiValue) ) {
                                        return 0;
                                    }
                                    if( Number(a.uiValue) < Number(b.uiValue) ) {
                                        return -1;
                                    }
                                    return 1;
                                }
                                ///// for other data types
                                var strA = a.uiValue.toString().toLowerCase(), strB = b.uiValue.toString()
                                    .toLowerCase();
                                return strA === strB ? 0 : ( strA < strB ? -1 : 1 );

                            };
                            colDef.enableColumnMenu = false;
                            colDef.enableFiltering = false;
                            colDef.enableColumnResizing = true;
                            colDef.minWidth = 180;
                            colDef.visible = true;
                            return colDef;
                        };
                        self.rowdata = [];

                        /**
                         * @memberof NgControllers.awGridController
                         *
                         * @param {Object} gridOverlay - the gridVM
                         */
                        self.setData = function( gridOverlay ) {
                            //ssu set the gridOverlay (gridOverlay) onto the scope?
                            $scope.gridOverlay = gridOverlay;
                            var colDefs = [ firstColumn ];
                            for( var inx = 0; inx < gridOverlay.fields.length; inx++ ) {
                                colDefs.push( self.createColDef( gridOverlay.fields[inx] ) );
                            }
                            columnDefinitions = colDefs;
                            // create the options object on the scope
                            $scope.gridTableOptions = {
                                enableColumnMoving: true,
                                enableCellSelection: true,
                                enableCellEditOnFocus: true,
                                rowHeight: 40,
                                enableRowSelection: true,
                                enableRowHeaderSelection: false,
                                enableSelectAll: false,
                                multiSelect: true,
                                enableColumnResizing: true,
                                enableGridMenu: false,
                                columnDefs: columnDefinitions,
                                data: gridOverlay.uiDataAdapter.dataPage,
                                rowdata: gridOverlay.uiDataAdapter.dataPage,

                                // register the api interaction and callback
                                onRegisterApi: function( gridApi ) {
                                    $scope.gridApi = gridApi;
                                    gridApi.selection.on.rowSelectionChanged( $scope, function( row ) {
                                        if( $scope.gridOverlay && $scope.gridOverlay.events &&
                                            $scope.gridOverlay.events.onRowSelectionChange ) {
                                            if( row.isSelected ) {
                                                $scope.gridOverlay.selectedUids.push( row.entity.uid );
                                            } else {
                                                if( $scope.gridOverlay.selectedUids &&
                                                    $scope.gridOverlay.selectedUids.length > 0 ) {
                                                    for( var i = 0; i < $scope.gridOverlay.selectedUids.length; i++ ) {
                                                        if( $scope.gridOverlay.selectedUids[i] === row.entity.uid ) {
                                                            $scope.gridOverlay.selectedUids.splice( i, 1 );
                                                        }
                                                    }
                                                }
                                            }
                                            $scope.gridOverlay.events.onRowSelectionChange( row.entity.uid,
                                                row.isSelected );
                                        }
                                    } );
                                }
                            }; // end gridOptions

                            self.rowdata = gridOverlay.uiDataAdapter.dataPage;

                            // a bit strange... but needed for now to get updates from forceDataUpdate() on the overlay
                            gridOverlay.gridOptions = $scope.gridTableOptions;
                            $scope.gridTableOptions.data = gridOverlay.uiDataAdapter.dataPage;
                            $scope.gridTableOptions.flatEntityAccess = true;
                        }; // setData

                        $scope.refreshData = function( gridOverlay ) {
                            // update the scope cache
                            self.rowdata = gridOverlay.uiDataAdapter.dataPage;
                            gridOverlay.gridOptions.data = gridOverlay.uiDataAdapter.dataPage;
                            gridOverlay.selectedUids = [];
                        };

                        /**
                         * Trigger an update of the property list info from the VM column list.
                         *
                         * @memberof NgControllers.awGridController
                         *
                         * @param {Object} gridOverlay - the grid VM
                         */
                        $scope.updateColumnDefs = function( gridOverlay ) {
                            if( gridOverlay.fields && gridOverlay.fields.length > 0 ) {
                                // empty existing
                                var colDefs = [ firstColumn ];
                                for( var inx = 0; inx < gridOverlay.fields.length; inx++ ) {
                                    colDefs.push( self.createColDef( gridOverlay.fields[inx] ) );
                                }
                                gridOverlay.gridOptions.columnDefs = colDefs;
                            }
                        };
                    }

                ] ); // awGridController

        app.directive( 'awMatrixRowHeader', function() {
            return {
                restrict: "E",
                link: function( scope, elt, attrs ) {
                    // column definition and data context for the row
                    var content = '<p>no callback</p>'; // debug TODO
                    content = "";
                    elt.html( content );
                }
            };
        } );

        app.directive( 'awNgUiGrid', function() {
            return {
                restrict: 'E',
                controller: 'awGridController',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwUIGrid.html'
            };
        } );

        /**
         * Initialize ('bootstrap') the angular system and create an angular controller on a new 'child' of the given
         * 'parent' element.
         *
         * @param {Element} parentElement - The DOM element the controller and 'inner' HTML content will be added to.
         *            <P>
         *            Note: All existing 'child' elements of this 'parent' will be removed.
         *
         * @param {String} innerHtml - String that defines the exact HTML content that will be added to the 'parent'
         *            element.
         *
         * @param {Object} gridOverlay - Arbitrary object to be set as the primary 'scope' of the new angular
         *            controller.
         *            <P>
         *            Note: This object will have the 'rootScopeElement' property set on this object with the new
         *            AngularJS Element created to hold the compiled given 'innerHtml' and attached as a child to the
         *            given 'parentElement'.
         */
        exports.insertGrid = function( parentElement, innerHtml, gridOverlay ) {
            /**
             * Create an 'outer' <DIV> (to hold the given 'inner' HTML) and create the angular controller on it.
             * <P>
             * Remove any existing 'children' of the given 'parent'
             * <P>
             * Add this new element as a 'child' of the given 'parent'
             */
            var ctrlElement = ngModule
                .element( '<div class="aw-jswidgets-grid aw-jswidgets-tablePropGrid" ng-controller="awGridController"/>' );

            var inner = '<div id="grid" ui-grid="gridTableOptions" ui-grid-selection ui-grid-resize-columns ui-grid-move-columns />';
            ctrlElement.html( inner );

            $( parentElement ).append( ctrlElement );

            var ctrlFn = awInclude( parentElement, ctrlElement );
            if( ctrlFn ) {
                ctrlFn.setData( gridOverlay );
            }
        };

        // utility function to get the scope (if set) on the controller under the parent element.
        var getScopeForParent = function( parentElement ) {
            var scope = null;
            // assumes that the first child of parent is the controller element
            if( parentElement && parentElement.lastChild ) {
                scope = ngModule.element( parentElement.lastChild ).scope();
            }
            return scope;
        };

        exports.forceRefresh = function( parentElement, gridOverlay ) {
            var ngScope = getScopeForParent( parentElement );
            if( ngScope && !ngScope.$$destroyed ) {
                checkChanged( parentElement, gridOverlay );
                ngScope.updateColumnDefs( gridOverlay );
                ngScope.gridApi.grid.scrollToIfNecessary(ngScope.gridOverlay.gridOptions.data[0], ngScope.gridApi.grid.columns[1]);
                ngScope.refreshData( gridOverlay );

                ngScope.$evalAsync( function() {
//                    console.log( 'trigger digest?' );
                } );
            }
        };
        var checkChanged = function( parentElement, gridOverlay ) {
            var elements = parentElement.getElementsByClassName( "changed" );
            var length = elements.length;
            if( length > 0 ) {
                for( var i = 0; i < length; i++ ) {
                    elements[0].classList.remove( 'ng-dirty' );
                    elements[0].classList.remove( 'changed' );
                }
            }
            if( gridOverlay.editable && gridOverlay.isDirty ) {
                if( !parentElement.lastChild.querySelector( '.ui-grid-viewport' ).classList
                    .contains( 'aw-jswidgets-tablePropertyContentChanged' ) ) {
                    parentElement.lastChild.querySelector( '.ui-grid-viewport' ).classList
                        .add( 'aw-jswidgets-tablePropertyContentChanged' );
                }
            } else {
                var elementTable = parentElement.getElementsByClassName( "aw-jswidgets-tablePropertyContentChanged" );
                var size = elementTable.length;
                if( size > 0 ) {
                    for( var i = 0; i < size; i++ ) {
                        elementTable[0].classList.remove( 'aw-jswidgets-tablePropertyContentChanged' );
                    }
                }
            }
        };

        exports.forceupdateColumnDefs = function( parentElement, gridOverlay ) {
            var ngScope = getScopeForParent( parentElement );
            if( ngScope && !ngScope.$$destroyed ) {
                ngScope.updateColumnDefs( gridOverlay );
            }
        };

        return exports;
    } ); // End RequireJS Define
