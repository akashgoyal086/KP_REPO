//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define
 */

/**
 * @module js/NgI18ns
 */
define([ 'app', 'js/localeService' ], function(app) {
    'use strict';

    /**
     * This attribute directive is used to display 'localized' Text. The value of the attribute on the directive's
     * Element is used as a 'key' in the 'localTextBundle' map (set into the directive's $scope). If the attribute
     * directive is not found, the code assumes the directive is attached to an element and will attempt to use the
     * value of the 'key' attribute on the element.
     *
     * @member aw-i18n
     * @memberof NgMixedDirectives
     */
    app.directive('awI18n', [ 'localeService', function(localeSvc) {
        return {
            restrict : 'AE',
            link : function(scope, elem, attrs) {
                localeSvc.getTextPromise().then(function(localTextBundle) {
                    var keyValue = attrs.awI18n? attrs.awI18n: attrs.key;
                    elem.text(localTextBundle[keyValue]);
                });
            }
        };
    } ]);
    // End RequireJS Define
});
