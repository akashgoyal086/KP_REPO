//@<COPYRIGHT>@
//==================================================
//Copyright 2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 document,
 awInclude
 */

/**
 * @module js/NgUICompare - ui-grid usage for the Compare view.
 *
 * The require define formatting is tied to the karma test script, don't change the format!
 */
define(['app', 'angular', 'jquery', 'js/NgDataProvider', 'ui.grid'],
    function(app, ngModule, $, dataProviderModule) {
        'use strict';

        // the ui-grid css is shared by several modules, check before adding it
        var cssCheck = $("head:first > link").filter("[href='" + app.getBaseUrlPath() +  "/lib/uigrid/ui-grid.min.css']").length;
        if (cssCheck === 0) {
            // add the CSS for 'ui-grid' module.
            var link = document.createElement("link");
            link.type = "text/css";
            link.rel = "stylesheet";
            link.href = app.getBaseUrlPath() + "/lib/uigrid/ui-grid.min.css";
            document.getElementsByTagName("head")[0].appendChild(link);
        }

        var exports = {};

        /**
         * Defines the compare controller
         *
         * @constructor awCompareController
         * @memberof NgControllers
         *
         * @param $scope
         * @param $timeout
         * @param uiGridConstants
         */
        app
            .controller(
                'awCompareController', [
                    '$scope',
                    '$timeout',
                    'uiGridConstants',
                    function($scope, $timeout, uiGridConstants) {
                        var self = this;

                        // little facet structure - (basically the prop lookup key and the display name for the "row")
                        var facetFactory = function(key, displayName) {
                            var facet = {};
                            facet.key = key;
                            facet.displayName = displayName;
                            return facet;
                        };

                        // factory method to create a rowMaster instance
                        // the rowMaster is what the grid uses to represent the data. The cellData for the row
                        // will have a property from each column data object instance.
                        var rowMasterFactory = function(facet) {
                            var rowMaster = {};
                            rowMaster.facet = facet;
                            rowMaster.rowDisplayName = function() {
                                return facet.displayName;
                            };
                            rowMaster.cellData = {}; // cell storage for the cellVMs of this row, one per column.

                            // RMB event - pass in on to the registered event handler
                            rowMaster.onRMBEvent = function(event) {
                                self.containerVM.events.onRMB(event.clientX, event.clientY);
                            };

                            // on click event on cell which has already focused with cellNav event
                            // main behavior is in cellNav handling, this only has to deal with clicks
                            // on the currently "Nav'd" cell
                            rowMaster.onClickEvent = function(event) {
                                var $currentCell = $(event.currentTarget);
                                // click on cell that already has focus should toggle OFF the selection.
                                if ($currentCell.hasClass('ui-grid-cell-focus')) {
                                    // is the focus cell already selected?
                                    var isCurrentlySelected = $currentCell.hasClass('aw-jswidgets-selectedObject');
                                    var myColKey = $currentCell.attr("__colid");

                                    // get the master instance
                                    if (_columnsById[myColKey]) {
                                        var master = _columnsById[myColKey];
                                        if (master) {
                                            var isCurrentlySelected2 = master.objInfo.selected;

                                            if (isCurrentlySelected) {
                                                clearSelectedColumns();
                                                master.objInfo.selected = false;
                                                selectNotification(myColKey, false);
                                            } else {
                                                // clear current selection first
                                                clearSelectedColumns();
                                                master.objInfo.selected = true;
                                                selectNotification(myColKey, true);
                                            }
                                        }
                                    }
                                }
                            };

                            return rowMaster;
                        };

                        // take the current list of field definitions, and the current column set and
                        // populate or update the cell data structures within the rows
                        var populateRowDataCells = function() {
                            for (var colIdx = 0; colIdx < columnMasterList.length; colIdx++) {
                                var colMaster = columnMasterList[colIdx];
                                var sharedColObj = colMaster.objInfo; // shared state for every row with this column
                                for (var rowIdx = 0; rowIdx < rowMasterMatrix.length; rowIdx++) {
                                    var rowMstr = rowMasterMatrix[rowIdx];
                                    var rowKey = rowMstr.facet.key;

                                    // if there is already a cellData instance, update it.  (If we skipped updating,
                                    // the binding gets out of date, and the UI doesn't update.)
                                    // if there is no cellData instance yet -- create one.
                                    var cellVM;
                                    if (rowMstr.cellData[colMaster.key]) {
                                        // already have the cellVM, just replace it's contents
                                        cellVM = rowMstr.cellData[colMaster.key];
                                    } else {
                                        cellVM = {};
                                    }

                                    cellVM.objInfo = sharedColObj; // shared state
                                    if (colMaster.data && colMaster.data.props[rowKey]) {
                                        //                                        cellVM.prop = colMaster.data.props[rowKey];
                                        cellVM.data = colMaster.data;
                                    } else {
                                        cellVM.data = {}; // no data
                                    }

                                    rowMstr.cellData[colMaster.key] = cellVM;
                                }
                            }
                        };

                        // when compare items get unselected, the columns go away, but the row cellData instances
                        // won't be automatically cleaned up - use this function to check for and remove any
                        // cellData that no longer corresponds to a column
                        var cleanDataCellsForDeletedColumns = function() {
                            var numColumns = columnMasterList.length ? columnMasterList.length : 0;
                            var colKeyList;
                            if (rowMasterMatrix && rowMasterMatrix.length) {
                                for (var rowIdx = 0; rowIdx < rowMasterMatrix.length; rowIdx++) {
                                    var rowMstr = rowMasterMatrix[rowIdx];
                                    if (rowMstr && rowMstr.cellData && Object.keys(rowMstr.cellData).length > numColumns) {
                                        // the cellData count is larger than the column count, need to cleanup

                                        // create the colKeyList on first need
                                        if (!colKeyList) {
                                            colKeyList = [];
                                            for (var colIdx = 0; colIdx < columnMasterList.length; colIdx++) {
                                                colKeyList.push(columnMasterList[colIdx].key);
                                            }
                                        }
                                        var propKeys = Object.keys(rowMstr.cellData);
                                        // iterate thru the cellData js props, cross check against the current
                                        // set of column keys, if the cellData prop key is not in that list, remove it
                                        for (var cellKeyidx = 0; cellKeyidx < propKeys.length; cellKeyidx++) {
                                            var cellKey = propKeys[cellKeyidx];
                                            if (colKeyList.indexOf(cellKey) === -1) {
                                                // not a valid columnn anymore, remove the data to avoid a leak
                                                delete rowMstr.cellData[cellKey];
                                            }
                                        }
                                    }
                                }
                            }
                        };

                        // function to sanitize the uid string to remove any characters (especially periods)
                        // that cause issues with ui grid evaluation.   UI Grid logic was processing
                        // the dot as an object reference notation.   The dynamic or bom line uid strings
                        // contained various odd characters - dots, comma, etc which normal uids don't have.
                        // for now just replace the dots/periods with dash
                        var genSafeUid = function(uid) {
                            if (uid) {
                                return uid.replace(/\./g, '-');
                            }
                            return '';
                        };


                        // factory method to create a columnmaster instance.  Each column is one distinct object.
                        // The column key uniquely identifies the columnMaster.   In some cases we have to sanitize the uid string
                        // to avoid special characters (dot, period, etc)
                        var columnMasterFactory = function(data) {
                            var columnMaster = {};
                            columnMaster.data = data; // keep a ref to the data object
                            // shared info for all the rows under this column.  Provides a common shared binding source
                            // ui state + references.
                            columnMaster.objInfo = {
                                selected: false
                                    // dataObj : data,  // may want the object data available for future binding?
                            };
                            columnMaster.key = genSafeUid(data.uid);
                            return columnMaster;
                        };

                        // define the compare fixed first column - shows the properties for each row.
                        var firstColumn = {
                            // placeholder - this is the first column which holds the "row" names, no title or column
                            // level interaction.
                            name: "",
                            field: "rowDisplayName()",
                            displayName: '', // empty
                            cellTemplate: '<div aw-compare-right-click class="ui-grid-cell-contents" > {{row.entity.facet.displayName}} </div>',
                            pinnedLeft: true,
                            enableColumnMenu: false, // hides all the column header stuff in this field - should be blank.
                            enableColumnMoving: false,
                            enableSorting: false,
                            allowCellFocus: false,
                            width: 125
                        };

                        // the column definitions - single row header (prop name) to start with
                        var columnDefinitions = [firstColumn];

                        // utility function to create the columnMaster object - one per data object.
                        var generateColumnMastersForObjs = function(objData) {
                            var masterList = [];
                            _columnsById = {}; // clear the list
                            // generate column master bound to each data object.
                            if (objData && objData.length) {
                                for (var idx = 0; idx < objData.length; idx = idx + 1) {
                                    var cm = columnMasterFactory(objData[idx]);
                                    masterList.push(cm);
                                    _columnsById[cm.key] = cm;
                                }
                            }
                            return masterList;
                        };

                        // used to generate the column header cell template.  It is given the data object (ModelObject) as input.
                        // presently there is not always an image URL available, so it calls back into the viewmodel to retrieve an image URL to display.
                        // for the display name, if the object_string property is available, we will bind to that, otherwise show an empty string.
                        var getColumnHeaderTemplate = function(obj) {
                            var image;
                            var vm = self.containerVM;
                            if (vm) {
                                image = vm.api.getImageForId(obj.uid);
                            }

                            var safeName = genSafeUid(obj.uid);

                            // the data object (native model object) is chained off the uigrid col object via the colDef, colMaster.data
                            // priority is to use object_string, if that is not available
                            // try object_name,  otherwise use blank.  So ternary binding expression
                            // line limit length led to multi line string.
                            var response = '<div class="aw-jswidgets-compareHeader ui-grid-cell-contents" aw-compare-header-click __colid = "' + safeName +
                                '" ng-class="{\'aw-jswidgets-selectedObject\' : col.colDef.awColMaster.objInfo.selected}"  >' + image + '</div>' +
                                '<div class="aw-jswidgets-headerTitle ui-grid-cell-contents" ng-class="{\'aw-jswidgets-selectedObject\' : col.colDef.awColMaster.objInfo.selected}" ' +
                                ' aw-compare-header-click __colid = "' + safeName + '" >' +
                                '{{ col.colDef.awColMaster.data.props.object_string ? col.colDef.awColMaster.data.props.object_string.uiValues[0] : ' +
                                'col.colDef.awColMaster.data.props.object_name ? col.colDef.awColMaster.data.props.object_name.uiValues[0] : "  "  }}</div>';

                            return response;
                        };

                        // function to clear selection state on all columnMasters.
                        // used when changing selection
                        var clearSelectedColumns = function() {
                            if (columnMasterList) {
                                for (var idx = 0; idx < columnMasterList.length; idx = idx + 1) {
                                    if (columnMasterList[idx].objInfo && columnMasterList[idx].objInfo.selected) {
                                        columnMasterList[idx].objInfo.selected = false;
                                    }
                                }
                            }
                        };

                        // create the uiGrid column for each object. Create a unique column per object.
                        var generateColumns = function(objData) {
                            var masterList = generateColumnMastersForObjs(objData);
                            columnMasterList = masterList;

                            var columns = [firstColumn];
                            for (var idx = 0; idx < masterList.length; idx = idx + 1) {
                                var clMaster = masterList[idx];
                                var safeName = clMaster.key; // genSafeUid(clMaster.data.uid);

                                var cdef = {};
                                cdef.name = safeName;
                                cdef.awColMaster = clMaster; // hold a ref to the columnMaster
                                cdef.field = safeName; // id key

                                // pretty ugly cell template - the first part is binding the selection state, the __colid attribute provides
                                // the column/object matching key for any lookup requirements.
                                // The actual cell/prop value binding has to go from the row, then the column in that row via the cellData.
                                // that cell then points back to the corresponding model object, and we need the property from that object
                                // which corresponds to the row being displayed - so the entity.facet.key is the property name for the
                                // property to be bound.   It looks a bit circular, but in order to see edit value updates we have to go back
                                // through the model object reference since the property instances get replaced.
                                cdef.cellTemplate = '<div class="ng-binding ng-scope ui-grid-cell-contents" ' +
                                    ' ng-class="{\'aw-jswidgets-selectedObject\' : row.entity.cellData[col.colDef.field].objInfo.selected}" ' +
                                    ' aw-compare-click __colid = "' + safeName + '"><ul class="aw-jswidgets-compareVal">' +
                                    '<li ng-repeat="val in row.entity.cellData[col.colDef.field].data.props[row.entity.facet.key].uiValues">{{val}}</li></ul></div>';
                                cdef.displayName = clMaster.displayName;
                                cdef.headerCellTemplate = getColumnHeaderTemplate(clMaster.data);
                                cdef.minWidth = 100;
                                cdef.enablePinning = false;
                                // on click event on header to toggle select for entire column
                                cdef.onHeaderClickEvent = function(event) {
                                    var $currentCell = $(event.currentTarget);
                                    var myColKey = $currentCell.attr("__colid");

                                    // get the column def which matches the target colid value
                                    var thisColDef;
                                    for(var idx=0; idx < columnDefinitions.length; idx++) {
                                        if (columnDefinitions[idx].field === myColKey) {
                                            thisColDef = columnDefinitions[idx];
                                            break;
                                        }
                                    }

                                    // get the column master instance
                                    if (_columnsById[myColKey]) {
                                        var master = _columnsById[myColKey];
                                        if (master) {
                                            var isCurrentlySelected = master.objInfo.selected;
                                            if (isCurrentlySelected) {
                                                // toggle it off - unselecting this column
                                                self.gridApi.grid.cellNav.clearFocus();
                                                clearSelectedColumns();
                                                $scope.$evalAsync();

                                            } else {
                                                // want to set this column as selected.  Have to check current focusCell
                                                // as that will determine if the cellNav handles selection or we have to
                                                // do it explicitly here.
                                                var navrc = self.gridApi.cellNav.getFocusedCell();
                                                if (navrc && navrc.col.field === myColKey) {
                                                    // focused cell in same column - Nav won't fire, so set explicitly
                                                    master.objInfo.selected = true;
                                                }


                                                // last row that was clicked or within scroll range.
                                                var scrollRow = _lastNavRow;
                                                if (!scrollRow && self.gridApi.grid.getVisibleRowCount()){
                                                    // if there is no last nav row then get first visible (we haven't CellNavigated yet}
                                                    var visRows = self.gridApi.grid.getVisibleRows();
                                                    scrollRow = visRows[0];
                                                }

                                                if (scrollRow) {
                                                    // set focus somewhere in the column and allow the cellNav logic to manage selection
                                                    self.gridApi.cellNav.scrollToFocus(scrollRow.entity, thisColDef);
                                                }
                                            }
                                        }
                                    }


                                };
                                columns.push(cdef);
                            }

                            columnDefinitions = columns;
                            return columns;
                        };

                        // functions to support selection interaction

                        // Method to single selection change to selection
                        var selectNotification = function(columnName, selState) {
                            self.containerVM.events.handleSingleSelection(columnName, selState);
                        };


                        // these become the backing store for the column definitions.
                        var columnMasterList = [];
                        // the column Masters with a key lookup
                        var _columnsById = {};

                        // track the last row object to be Navigated to or scrolled to.  Use this for Header
                        // selection interaction to mark the row within the selected column.
                        var _lastNavRow;

                        // created list of rowMasters (for grid binding)
                        var rowMasterMatrix = [];

                        var gridOptions = {
                            enableSorting: false, // skip the header sort interaction
                            enableColumnMenus: false, // no menus
                            enableRowSelection: false,
                            data: rowMasterMatrix,
                            columnDefs: columnDefinitions,
                            onRegisterApi: function(gridApi) {
                                self.gridApi = gridApi;

                                gridApi.core.on.scrollEnd(gridApi.grid.appScope, function (scrollData) {
                                    // on a vertical scroll, we want to track what the visible range is
                                    // so that if a header selection is done, we keep the ui showing that
                                    // range of objects and we don't set ui focus somewhere else in the list
                                    // of rows.   Note that the visible row set used here is more than just
                                    // what is shown in the DOM.
                                    // get the visible row count and relative scroll percent to determine
                                    // the row index to set during header click.  Watch out for the upper bound.
                                    if (scrollData && scrollData.grid && scrollData.y) {
                                        var rowCount = scrollData.grid.getVisibleRowCount();
                                        var vertPercent = scrollData.y.percentage;
                                        var rowToSet = Math.ceil(rowCount * vertPercent );
                                        // adjust at upper bound point, don't want selection right at the bottom
                                        if ((rowToSet >= rowCount) && (rowToSet > 3)) {
                                            rowToSet -= 2;
                                        }
                                        // sanity check for out of range
                                        if (rowToSet > rowCount -1) {
                                            rowToSet = rowCount-1;
                                        }
                                        _lastNavRow = scrollData.grid.getVisibleRows()[rowToSet];
                                    }

                                });


                                // enable the cellNav module
                                if (gridApi.cellNav) {
                                    gridApi.cellNav.on.navigate(gridApi.grid.appScope, function(newRc, oldRc) {
                                        var colid = newRc.col.colDef.name; // key
                                        var master;

                                        // get the master instance
                                        if (_columnsById[colid]) {
                                            var master = _columnsById[colid];

                                            if (master) {
                                                var isCurrentlySelected = master.objInfo.selected;
                                                // no old Rc, add the highlight on column and select the object
                                                if (!oldRc) {
                                                    if (isCurrentlySelected) {
                                                        //if there is no old header and is already selected, unselect the object
                                                        master.objInfo.selected = false;
                                                        selectNotification(colid, false);
                                                    } else {
                                                        // clear the old selection
                                                        clearSelectedColumns();
                                                        master.objInfo.selected = true;
                                                        selectNotification(colid, true);
                                                    }
                                                } else {
                                                    // have an oldRc
                                                    // if the old Rc column and new Rc col are different, then remove the highlight on old col and add highlight to new column and select new object
                                                    if (oldRc.col !== newRc.col) {
                                                        _lastNavRow = newRc.row; // cell Nav horizontal
                                                        if (isCurrentlySelected) {
                                                            //if there is  old header and is already selected, unselect the object
                                                            clearSelectedColumns();
                                                            selectNotification(colid, false);
                                                        } else {
                                                            clearSelectedColumns();
                                                            // select the new ones
                                                            master.objInfo.selected = true;
                                                            selectNotification(colid, true);
                                                        }
                                                    }
                                                    // highlight the column during the scroll bar clear focus for selected object
                                                    else if (oldRc.row.uid === newRc.row.uid) {
                                                        // this may be a scroll triggered Nav event.
                                                        // this path is hit during scrolling, also if you select a cell via Nav, then do a header click
                                                        // and then come back to the same row
                                                        if (!_lastNavRow) {
                                                            clearSelectedColumns(); // no scroll info, valid navigation,
                                                            master.objInfo.selected = true;
                                                            // No event notification
                                                        }
                                                    }
                                                    // if the old Rc column and new Rc col are same and object is selected . then remove the highlight on old col and unselect object
                                                    else if (isCurrentlySelected) {
                                                        _lastNavRow = newRc.row; // same column different row
                                                        master.objInfo.selected = false;
                                                        selectNotification(colid, false);
                                                    }
                                                    // if the old Rc column and new Rc col are same and object is unselected . then add the highlight on new col and select object
                                                    else {
                                                        _lastNavRow = newRc.row; // same column different row
                                                        clearSelectedColumns();
                                                        // select the new ones
                                                        master.objInfo.selected = true;
                                                        selectNotification(colid, true);
                                                    }
                                                }
                                            }
                                        }

                                    });
                                }

                                if (gridApi.colMovable) {
                                    gridApi.colMovable.on.columnPositionChanged(gridApi.grid.appScope, function(colDef, originalPosition, newPosition) {
                                        self.containerVM.events.columnPositionChanged(colDef.name, originalPosition, newPosition);
                                    });
                                }
                            }
                        }; // end gridOptions

                        $scope.gridCompareOptions = gridOptions;

                        // reference to the gridOptions object (bound to ui grid via scope)
                        self.gridOpts = gridOptions;

                        $scope.hideTheWidget = false; // normally show the grid

                        /**
                         * Set the View Model reference.  The VM is the source object for all the information
                         *
                         * @memberof NgControllers.awCompareController
                         *
                         * @param {Object} containerVM - the containerVM
                         */
                        self.setContainerVM = function(containerVM) {
                            // keep a reference to the containerVM
                            self.containerVM = containerVM;
                            containerVM.gridOptions = self.gridOpts;
                            $scope.$evalAsync(function() {
                                // ensure we update to the latest VM data
                                $scope.updateFieldDefs(containerVM);
                                $scope.setDataAdapter(containerVM);
                            }); // evalAsync
                        };


                        /**
                         * get a new data adapter - set the displayed data content based on this adapter.
                         * For compare - the data objects become the columns
                         *
                         * @param {Object} containerVM - the containerVM
                         */
                        $scope.setDataAdapter = function(containerVM) {
                            // trigger the loading of the initial data
                            if (containerVM.uiDataAdapter && containerVM.uiDataAdapter.bindingCollection && containerVM.uiDataAdapter.bindingCollection.data) {
                                var columns = generateColumns(containerVM.uiDataAdapter.bindingCollection.data);
                                populateRowDataCells();
                                // this would be the point we could check for old data in the rowDataCells -
                                cleanDataCellsForDeletedColumns();
                                // update the instances (Columns) for the compare case.
                                if (containerVM.gridOptions) {
                                    containerVM.gridOptions.columnDefs = columns;
                                }
                            }
                        };


                        /**
                         * simple utility function that checks if the grid field list doesn't match the VM
                         * and triggers an update.  Due to async timing differences this may happen during
                         * data updates.
                         */
                        $scope.checkFieldDefUpdates = function(containerVM) {
                            if (containerVM && containerVM.fields && self.gridOpts && self.gridOpts.data) {
                                if (containerVM.fields.length !== self.gridOpts.data.length) {
                                    $scope.updateFieldDefs(containerVM);
                                }
                            }
                        };


                        /**
                         * Trigger an update of the property list info from the VM column list. In the compare case, the
                         * columns drive the row master definitions. In order to allow for empty XRT Object sets, if
                         * there is no object data (dataPage), then we won't display the rows.
                         *
                         * @memberof NgControllers.awCompareController
                         *
                         * @param {Object} containerVM - the containerVM
                         */
                        $scope.updateFieldDefs = function(containerVM) {
                            var fieldList = containerVM.fields;
                            if (fieldList && fieldList.length > 0) {
                                // empty existing
                                rowMasterMatrix.length = 0;

                                // if there are no objects (XRT case for empty set), don't show rowMasters
                                if (containerVM.uiDataAdapter && containerVM.uiDataAdapter.bindingCollection && containerVM.uiDataAdapter.bindingCollection.data &&
                                    containerVM.uiDataAdapter.bindingCollection.data.length) {
                                    $scope.hideTheWidget = false; // render the grid
                                    for (var idx = 0; idx < fieldList.length; idx++) {
                                        rowMasterMatrix.push(rowMasterFactory(facetFactory(fieldList[idx].name,
                                            fieldList[idx].displayName)));
                                    }
                                    populateRowDataCells();
                                } else {
                                    // no data to show
                                    $scope.hideTheWidget = true; // don't render the grid
                                }
                            }
                        };


                        /**
                         * take the input list of uids and sync the column master selection state
                         * have to check & potentially adjust the selection state of every column master
                         * may include clearing a current selection
                         */
                        $scope.syncSelectionList = function(selectedIdList) {
                            if (selectedIdList && selectedIdList.length >= 0 &&
                                columnMasterList && columnMasterList.length) {
                                for (var cIdx = 0; cIdx < columnMasterList.length; cIdx++) {
                                    var master = columnMasterList[cIdx];
                                    var selKey = master.data.uid;

                                    if (selectedIdList.indexOf(selKey) !== -1) {
                                        // it should be selected
                                        master.objInfo.selected = true;
                                    } else {
                                        // should NOT be selected
                                        master.objInfo.selected = false;
                                    }
                                }

                                if (self.gridApi) {
                                    // tell uiGrid to redraw
                                    self.gridApi.core.notifyDataChange(uiGridConstants.dataChange.ALL);
                                }
                            }
                        };

                    }
                ]); // awCompareController

        /**
         * Directive for right click
         *
         * @returns {Void}
         */
        app.directive('awCompareRightClick', function() {
            return function(scope, element, attrs) {
                element.bind('contextmenu', function(event) {
                    var rowRef = scope.row.entity;
                    event.preventDefault();
                    rowRef.onRMBEvent(event);
                });
            };
        });

        /**
         * Directive for mouse left click
         */
        app.directive('awCompareClick', function() {
            return function(scope, element, attrs) {
                element.bind('click', function(event) {
                    var rowRef = scope.row.entity;
                    rowRef.onClickEvent(event);
                });
            };
        });

        /**
         * Directive for header click
         */
        app.directive('awCompareHeaderClick', function() {
            return function(scope, element, attrs) {
                element.bind('click', function(event) {
                    var headRef = scope.col.colDef;
                    headRef.onHeaderClickEvent(event);
                });
            };
        });


        /**
         * utility function to get the scope reference (if set) on the controller under the parent element.
         */
        var getScopeForParent = function(parentElement) {
            var scope = null;

            // assumes that the first child of parent is the controller element
            if (parentElement && parentElement.firstChild) {
                scope = ngModule.element(parentElement.firstChild).scope();
            }

            return scope;
        };

        /**
         * insertCompareGrid ('bootstrap') the angular system and create an angular controller on a new 'child' of the
         * given 'parent' element.
         *
         * @param {Element} parentElement - The DOM element the controller and 'inner' HTML content will be added to.
         *            <P>
         *            Note: All existing 'child' elements of this 'parent' will be removed.
         *
         *
         * @param {Object} containerVM - compare container View Model
         *            <P>
         *            Note: This object will have the 'rootScopeElement' property set on this object with the new
         *            AngularJS Element created to hold the compiled given 'innerHtml' and attached as a child to the
         *            given 'parentElement'.
         */
        exports.insertCompareGrid = function(parentElement, containerVM) {
            /**
             * Create an 'outer' <DIV> (to hold the given 'inner' HTML) and create the angular controller on it.
             * <P>
             * Remove any existing 'children' of the given 'parent'
             * <P>
             * Add this new element as a 'child' of the given 'parent'
             */
            var ctrlElement = ngModule
                .element('<div class="aw-jswidgets-grid aw-jswidgets-compareContainer" ng-controller="awCompareController" />');

            // add the required ui-grid directives for compare widget behavior.
            var inner = '<div id="grid" ng-hide="hideTheWidget" ui-grid="gridCompareOptions" ui-grid-resize-columns ui-grid-pinning ui-grid-cellNav ui-grid-auto-resize  ui-grid-move-columns />';
            ctrlElement.html(inner);

            $(parentElement).empty();
            $(parentElement).append(ctrlElement);

            var ctrlFn = awInclude(parentElement, ctrlElement);
            if (ctrlFn) {
                ctrlFn.setContainerVM(containerVM);
            }
        };


        /**
         * provide a new or updated data adapter reference via the VM.
         * trigger a recalc of the data to be displayed.
         *
         * @param {Element} parentElement - The element above the element the controller was created on.
         * @param {Object} containerVM - compare container View Model
         */
        exports.setDataAdapter = function(parentElement, containerVM) {
            var ngScope = getScopeForParent(parentElement);
            if (ngScope && !ngScope.$$destroyed) {
                ngScope.setDataAdapter(containerVM);
                // may be cases where we need to update the field list.
                ngScope.checkFieldDefUpdates(containerVM);
            }
        };

        exports.removeFocus = function(parentElement) {
            $(parentElement).find("div[class*='aw-jswidgets-selectedObject']").removeClass('aw-jswidgets-selectedObject');
            $(parentElement).find("div[class*='ui-grid-cell-focus']").addClass('aw-jswidgets-unselectedObject');
        };

        /**
         * Update the field list/column definitions - these are the compare rows
         *
         * @param {Element} parentElement - The element above the element the controller was created on.
         * @param {Object} containerVM - compare container View Model
         */
        exports.forceUpdateFieldDefs = function(parentElement, containerVM) {
            var ngScope = getScopeForParent(parentElement);
            if (ngScope && !ngScope.$$destroyed) {
                ngScope.updateFieldDefs(containerVM);
            }
        };


        /**
         * Update the selected object list
         *
         * @param {Element} parentElement - The DOM element for finding scope.
         * @param {Object} selectedIdList - The list of ids to be selected
         */
        exports.syncSelectionList = function(parentElement, selectedIdList) {
            var ngScope = getScopeForParent(parentElement);
            if (ngScope && !ngScope.$$destroyed) {
                ngScope.syncSelectionList(selectedIdList);
            }
        };

        /**
         * This is the factory function for the native View Model
         */
        var UICompareViewModel = function() {
            var self = this;

            self.whatamI = "UICompareVM"; // debug aid

            // members
            self.fields = [{
                name: 'object_name',
                displayName: 'name'
            }];

            self.objData = [];
            self.editable = false; // default to non-edit
            self.uiDataAdapter = {}; // will get initialized later


            // sub structure/ references
            self.api = {};
            self.events = {};


            // operations
            self.getAPIObject = function() {
                return self.api;
            };

            self.getEventAPIObject = function() {
                return self.events;
            };

            self.api.getImageForId = function(id) {
                return "";
            };

            self.events.onRowSelectionChange = function(dc, selected) {
                var id = dc.uid;
                console.log(' UICompareVM onRowSelChg ' + id);
            };


            self.events.onColumnSizeChange = function(name, deltaChange, currentSize) {
                var msg = 'UICompareVM col size chg: ' + name + " chg: " + deltaChange + '  size: ' + currentSize;
                console.log(msg);
            };


            self.events.onRMB = function(positionX, positionY) {
                var msg = 'UICompareVM RMB event in UICompareVM: ' + positionX + positionY;
                console.log(msg);
            };

            self.events.handleSingleSelection = function(id, selectionState) {
                console.log(' UICompareVM handleSingleSelection ' + id);
            };

            self.events.columnPositionChanged = function(id, orgPos, newPos) {
                console.log(' UICompareVM columnPositionChanged ' + id);
            };
        };

        /**
         * angular factory registration
         */
        app.factory('UICompareViewModelService', function() {
            return new UICompareViewModel();
        });

        exports.getUICompareViewModel = function() {
            return new UICompareViewModel();
        };



        /**
         * export function to retrieve a native data adapter
         */
        exports.getDataAdapter = function() {
            return dataProviderModule.getDataAdapter();
        };

        /**
         * export function to retrieve a native paging data provider
         */
        exports.getPagingDataProvider = function() {
            return dataProviderModule.getNativePagingDataProvider();
        };

        /**
         * export function to retrieve a native fixed data provider
         */
        exports.getFixedDataProvider = function() {
            return dataProviderModule.getFixedDataProvider();
        };



        return exports;
        // End RequireJS Define
    });
