//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 window,
 enableDrag,
 startDrag,
 storeTilesCoordinates,
 storeNewGroupsCoordinates,
 storeAllNecessaryCoordinates,
 dragTile,
 dragStop,
 findPlace,
 findTileUnderCursor,
 clearPlaceForTile,
 findNewGroupUnderCursor,
 showNewGroupPhantom
 */

/**
 * Note: Some of the above are actually local functions that are defined after they are being referenced. They are
 * include here just to minimize JSLint warnings.
 */

/**
 * drag'n'drop plugin
 *
 * this plugin allows to drag tiles between groups
 *
 * this plugin auto enabled to 'tile-group' elements or elements with attribute data-role="tile-group"
 *
 * to handle drag/drop events use next code
 *
 * <pre>
 *  $(function(){
 *      $('#tile_group_id').on('drag', function(e, draggingTile, parentGroup){
 *      ... your code ...
 *      });
 *      $('#tile_group_id').on('drop', function(e, draggingTile, targetGroup){
 *      ... your code ...
 *      });
 *  });
 * </pre>
 *
 * @module js/tile-drag
 */
define(
        [ 'jquery' ],
        function($) {
            'use strict';

            $.TileDrag = function(element, options) {

                var defaults = {};
                var startedDrag = false;
                var $tile;

                var plugin = this;

                plugin.settings = {};

                var $element = $(element), $startMenu, $groups, settings, tiles, $draggingTile, $parentGroup, // parent
                // group
                // for
                // dragging
                // tile
                draggingTileWidth, draggingTileHeight, $phantomTile, tileDeltaX, tileDeltaY, tilesCoordinates, tileSearchCount = 0, // uses
                // for
                // findTileUnderCursor
                // function
                tileUnderCursorIndex, tileUnderCursorSide, newGroupsCoordinates, newGroupSearchCount = 0, newGroupPhantom, targetType, // 'new'
                // or
                // 'existing'
                // group
                groupsMaxHeight, mouseMoved, tileDragTimer;

                plugin.init = function() {
                    settings = plugin.settings = $.extend({}, defaults, options);

                    $startMenu = $('.tiles');

                    // search other 'tile-group' elements
                    $groups = $('[data-role=tile-group], .tile-group');

                    // select all tiles within group
                    tiles = $groups.children('.tile');

                    // tiles.on( 'mousedown', startDrag );
                    tiles.on('setDragMode', enableDrag);
                    // tiles.on( 'holdDrag', holdDrag );
                };

                var enableDrag = function(event, tile, enable) {
                    if (enable) {
                        if (window.navigator.msPointerEnabled) {
                            $(tile).off('MSPointerDown', startDrag);
                            $(tile).on('MSPointerDown', startDrag);
                        }
                        $(tile).off('vmousedown', startDrag);
                        $(tile).on('vmousedown', startDrag);
                    } else {
                        if (window.navigator.msPointerEnabled) {
                            $(tile).off('MSPointerDown', startDrag);
                        }
                        $(tile).off('vmousedown', startDrag);
                    }
                };

                /**
                 * <pre>
                 * var holdDrag = function(event, tile, ev) {
                 *     // ev is the taphold event... which unfortunately is missing pageX/pageY
                 *     console.log('in holdDrag');
                 *     newevent = $.Event('vmousedown');
                 *     newevent.which = 1;
                 *     newevent.target = this;
                 *     newevent.pageX = this.offsetLeft; // ev.pageX;
                 *     newevent.pageY = this.offsetHeight; // ev.pageY;
                 *
                 *     $(this).trigger(newevent);
                 *     // startDrag.call( tile, event );
                 * };
                 * </pre>
                 */

                var startDrag = function(event) {
                    // currently dragging tile
                    $tile = $draggingTile = $(this);

                    // dragging tile dimentions
                    draggingTileWidth = $tile.outerWidth();
                    draggingTileHeight = $tile.outerHeight();

                    // hidden tile to place it where dragging tile will dropped
                    $phantomTile = $('<div></div>');
                    $phantomTile.css({
                        'background' : 'none',
                        'border' : 'thin solid #000000'
                    });
                    $phantomTile.addClass('tile');
                    if ($tile.hasClass('double')) {
                        $phantomTile.addClass('double');
                    } else if ($tile.hasClass('triple')) {
                        $phantomTile.addClass('triple');
                    } else if ($tile.hasClass('quadro')) {
                        $phantomTile.addClass('quadro');
                    }
                    if ($tile.hasClass('double-vertical')) {
                        $phantomTile.addClass('double-vertical');
                    } else if ($tile.hasClass('triple-vertical')) {
                        $phantomTile.addClass('triple-vertical');
                    } else if ($tile.hasClass('quadro-vertical')) {
                        $phantomTile.addClass('quadro-vertical');
                    }

                    // search parent group
                    $parentGroup = $tile.parents('.tile-group');

                    // some necessary event handlers
                    if (window.navigator.msPointerEnabled) {
                        $(document).on('MSPointerMove.tiledrag', dragTile);
                        $(document).one('MSPointerUp.tiledrag', dragStop);
                    }
                    $(document).on('vmousemove.tiledrag', dragTile);
                    $(document).one('vmouseup.tiledrag', dragStop);

                    mouseMoved = false;
                    startedDrag = true;
                };

                /**
                 * it function called on every mousemove event
                 */
                var dragTile = function(event) {
                    var targetGroup;
                    if (startedDrag) {
                        var tilePosition,
                        tilePositionX,
                        tilePositionY;

                        // In IE 10 the event does not contain the page and client coordinate information.
                        // This information is present in the originalEvent
                        // which is a native event created by browser.
                        // Hence replacing the event with originalEvent if the coordinate data is not present.
                        if ((!event.pageX && !event.pageY) && (!event.clientX && !event.clientY)) {
                            event = event.originalEvent;
                            // If the coordinates are not present in originalEvent,
                            // then do not start drag.
                            if ((!event.pageX && !event.pageY) && (!event.clientX && !event.clientY)) {
                                clearTimeout(tileDragTimer);
                                cleanupDrag(targetGroup);
                                return;
                            }
                        }

                        // dragging tile position within group
                        tilePosition = $tile.offset();
                        tilePositionX = tilePosition.left - (event.pageX - event.clientX);
                        tilePositionY = tilePosition.top - (event.pageY - event.clientY);

                        // pixels count between cursor and dragging tile border
                        tileDeltaX = event.clientX - tilePositionX;
                        tileDeltaY = event.clientY - tilePositionY;

                        // place phantom tile instead dragging one
                        $phantomTile.insertAfter($tile);
                        targetType = 'existing';

                        // move tile element to $draggingTileContainer
                        $tile.detach();
                        $tile.insertAfter($($groups.get(-1))); // it need for invalid IE z-index

                        // from now it fixed positioned
                        $tile.css({
                            'position' : 'fixed',
                            'left' : tilePositionX,
                            'top' : tilePositionY,
                            'z-index' : 100000
                        });

                        // store it for future
                        $tile.data('dragging', true);
                        storeTilesCoordinates();
                        storeNewGroupsCoordinates();

                        startedDrag = false;
                    }

                    // move dragging tile
                    $draggingTile.css({
                        'left' : event.clientX - tileDeltaX,
                        'top' : event.clientY - tileDeltaY
                    });

                    mouseMoved = true;
                    event.preventDefault();

                    // scroll panel when tile hits page edge
                    var scrollPanel = $('.aw-gateway-gatewayPanel');
                    if (event.pageX + 75 > document.body.scrollWidth) {
                        // scroll right
                        scrollPanel.scrollLeft(scrollPanel.scrollLeft() + 10);
                    } else if (event.pageX < 75) {
                        // scroll left
                        scrollPanel.scrollLeft(scrollPanel.scrollLeft() - 10);
                    }
                    if (event.pageY + 75 > document.body.scrollHeight) {
                        // scroll right
                        scrollPanel.scrollTop(scrollPanel.scrollTop() + 10);
                    } else if (event.pageY < 75) {
                        // scroll left
                        scrollPanel.scrollTop(scrollPanel.scrollTop() - 10);
                    }

                    clearTimeout(tileDragTimer);
                    tileDragTimer = setTimeout(function() {
                        findPlace(event);
                    }, 50);
                };

                // finding place where put dragging tile
                var findPlace = function(event) {
                    // all we need is index of tile under cursor (and under dragging tile) if it exists
                    var findTileIndex, findNewGroup;

                    // If IE 10 replacing the event with originalEvent if the coordinate data is not present.
                    if ((!event.pageX && !event.pageY) || (!event.clientX && !event.clientY)) {
                        event = event.originalEvent;
                    }

                    findTileIndex = findTileUnderCursor(event);
                    if (findTileIndex) {
                        clearPlaceForTile($(tiles[findTileIndex]));
                    } else {
                        findNewGroup = findNewGroupUnderCursor(event);
                        if (findNewGroup) {
                            showNewGroupPhantom(findNewGroup.group, findNewGroup.side);
                        }
                    }
                };

                /**
                 * when this function called dragging tile dropping to clear place (instead phantom tile) removing
                 * events and some other necessary changes
                 */
                var dragStop = function(event) {
                    var targetGroup;
                    startedDrag = false;

                    if (!mouseMoved) {
                        // emulate default click behavior
                        if ($draggingTile.is('a')) {
                            if ($draggingTile.prop('target') === '_blank') {
                                window.open($draggingTile.attr('href'));
                            } else {
                                window.location.href = $draggingTile.attr('href');
                            }
                        }
                        else
                        {
                            clearTimeout(tileDragTimer);
                            cleanupDrag(targetGroup);
                            return;
                        }
                    } else {
                        event.preventDefault();
                    }

                    // In IE 10, for same mouse-click event
                    // this method is executed more than once.
                    // because of this the targetGroup is overridden and set as blank
                    // and the tile is not added to the group.
                    // Hence validate if the parent tile-group information
                    // is present or if it is a new group, only then drop it to the group.
                    if (($phantomTile.parents('.tile-group') && $phantomTile.parents('.tile-group').length !== 0) || newGroupPhantom) {
                        clearTimeout(tileDragTimer);
                        findPlace(event);

                        $draggingTile.detach();
                        // it is two way now: drop to existing group or drop to new group
                        // first drop to existing group
                        if (targetType === 'existing') {
                            $draggingTile.insertAfter($phantomTile);
                            targetGroup = $phantomTile.parents('.tile-group');
                            $phantomTile.remove();
                        } else {
                            newGroupPhantom.css({
                                'backgroundColor' : '',
                                'width' : 'auto',
                                'max-width' : '322px',
                                'height' : ''
                            });
                            $draggingTile.appendTo(newGroupPhantom);
                            targetGroup = newGroupPhantom;
                            newGroupPhantom = undefined;
                        }
                        cleanupDrag(targetGroup);
                    }
                };

                var cleanupDrag = function(targetGroup) {
                    // remove parent group if it was a last tile there
                    if ($parentGroup.find('.tile').length === 0) {
                        $parentGroup.remove();
                    }

                    $draggingTile.css({
                        'position' : '',
                        'left' : '',
                        'top' : '',
                        'z-index' : ''
                    });

                    $draggingTile.data('dragging', false);

                    if (window.navigator.msPointerEnabled) {
                        $(document).off('MSPointerMove.tiledrag');
                    }
                    $(document).off('vmousemove.tiledrag');

                    $groups = $('[data-role=tile-group], .tile-group');
                    if (targetGroup !== undefined) {
                        $groups.trigger('drop', [ $draggingTile, targetGroup ]);
                    }

                    $startMenu.trigger('changed');
                };

                /*
                 * stores tiles coordinates for future finding one tile under cursor excluding current dragging tile
                 */
                var storeTilesCoordinates = function() {
                    tilesCoordinates = {};
                    var xOffset = tileDeltaX - draggingTileWidth / 2;
                    var yOffset = tileDeltaY - draggingTileHeight / 2;

                    tiles.each(function(index, tile) {
                        var $curTile, offset;

                        $curTile = $(tile);

                        // we dont need dragging tile coordinates
                        if ($curTile.data('dragging')) {
                            return;
                        }

                        offset = $curTile.offset();

                        // it is not real coordinates related to document border
                        // but corrected for less computing during dragging (tile moving)
                        tilesCoordinates[index] = {
                            x1 : offset.left + xOffset,
                            y1 : offset.top + yOffset,
                            x2: offset.left + $curTile.outerWidth() + xOffset,
                            y2: offset.top + $curTile.outerHeight() + yOffset
                        };
                    });
                };

                /**
                 * if tile dragging under this place it will creating new group there
                 */
                var storeNewGroupsCoordinates = function() {
                    groupsMaxHeight = 0;
                    newGroupsCoordinates = [];
                    $groups.each(function(index) {
                        var offset, width, height, $group;

                        $group = $(this);

                        offset = $group.offset();

                        width = $group.width();
                        height = $group.height();

                        // make it possible to insert new group before first one
                        if (index === 0) {
                            newGroupsCoordinates.push({
                                x1 : offset.left - 70 + tileDeltaX - draggingTileWidth / 2,
                                x2 : offset.left + tileDeltaX - draggingTileWidth / 2,
                                y1 : offset.top + tileDeltaY - draggingTileHeight / 2,
                                y2 : offset.top + height + tileDeltaY - draggingTileHeight / 2,
                                side : 'before',
                                group : $group
                            });
                        }

                        newGroupsCoordinates.push({
                            x1 : offset.left + width + tileDeltaX - draggingTileWidth / 2,
                            x2 : offset.left + width + 70 + tileDeltaX - draggingTileWidth / 2,
                            y1 : offset.top + tileDeltaY - draggingTileHeight / 2,
                            y2 : offset.top + height + tileDeltaY - draggingTileHeight / 2,
                            side : 'after',
                            group : $group
                        });

                        if (groupsMaxHeight < height) {
                            groupsMaxHeight = height;
                        }

                    });
                };

                /**
                 * search tile under cursor using tileCoordinates from storeTilesCoordinates function search occurred
                 * only one time per ten times for less load and more smooth
                 */
                var findTileUnderCursor = function(event) {
                    var i, coord, tileIndex = false, tileSide;

                    for (i in tilesCoordinates) {
                        if (tilesCoordinates.hasOwnProperty(i)) {
                            coord = tilesCoordinates[i];
                            if (coord.x1 < event.pageX && event.pageX < coord.x2 && coord.y1 < event.pageY &&
                                    event.pageY < coord.y2) {
                                tileIndex = i;
                                break;
                            }
                        } else {
                            return;
                        }
                    }

                    // detect side of tile (left or right) to clear place before or after tile
                    if (tileIndex) {
                        if (event.pageX < coord.x1 + $(tiles[tileIndex]).outerWidth() / 2) {
                            tileSide = 'before';
                        } else {
                            tileSide = 'after';
                        }
                    }
                    if (tileSide === tileUnderCursorSide && tileIndex === tileUnderCursorIndex) {
                        return false;
                    }
                    tileUnderCursorSide = tileSide;
                    tileUnderCursorIndex = tileIndex;

                    return tileIndex;
                };

                var findNewGroupUnderCursor = function(event) {
                    var i, coord, newGroup = false;

                    for (i in newGroupsCoordinates) {
                        if (newGroupsCoordinates.hasOwnProperty(i)) {
                            coord = newGroupsCoordinates[i];
                            if (coord.x1 < event.pageX && event.pageX < coord.x2 && coord.y1 < event.pageY &&
                                    event.pageY < coord.y2) {
                                newGroup = coord;
                                break;
                            }
                        } else {
                            return;
                        }
                    }

                    if (!newGroup) {
                        return false;
                    } else {
                        return newGroup;
                    }
                };

                /**
                 * just put phantom tile near tile under cursor (before or after) and remove previous phantom tile
                 */
                var clearPlaceForTile = function($tileUnderCursor) {
                    var $oldPhantomTile, $newParentGroup;

                    $oldPhantomTile = $phantomTile;
                    $phantomTile = $oldPhantomTile.clone();
                    targetType = 'existing';

                    // before or after, this is question ...
                    if (tileUnderCursorSide === 'before') {
                        $phantomTile.insertBefore($tileUnderCursor);
                    } else {
                        $phantomTile.insertAfter($tileUnderCursor);
                    }

                    if (newGroupPhantom) {
                        newGroupPhantom.remove();
                    }

                    $oldPhantomTile.remove();

                    // check if it was last tile in group and it drag out
                    if ($parentGroup.find('.tile').length === 0) {
                        $newParentGroup = $tileUnderCursor.parent('.tile-group');
                        if ($parentGroup[0] !== $newParentGroup[0]) {
                            // and if it true, make parent group invisible
                            $parentGroup.css({
                                'width' : 0,
                                'margin' : 0
                            });
                        }
                    }

                    $startMenu.trigger('changed');
                    storeAllNecessaryCoordinates();
                };

                /**
                 * makes visible new group place
                 *
                 * @param relGroup
                 *            relative group
                 *
                 *
                 * @param side
                 *            'after' or 'before'
                 */
                var showNewGroupPhantom = function(relGroup, side) {
                    if ($phantomTile) {
                        $phantomTile.remove();
                    }
                    if (newGroupPhantom) {
                        newGroupPhantom.remove();
                    }

                    newGroupPhantom = $('<div class="tile-group"></div>');
                    newGroupPhantom.css({
                        'height' : groupsMaxHeight,
                        'width' : '70px',
                        'backgroundColor' : '#333333',
                        'position' : 'relative'
                    });
                    relGroup[side](newGroupPhantom);
                    targetType = 'new';

                    // check if it was last tile in group and it drag out
                    if ($parentGroup.find('.tile').length === 0) {
                        $parentGroup.css({
                            'width' : 0,
                            'margin' : 0
                        });
                    }

                    $startMenu.trigger('changed');
                    storeAllNecessaryCoordinates();
                };

                var storeAllNecessaryCoordinates = function() {
                    storeTilesCoordinates();
                    storeNewGroupsCoordinates();
                };

                // return all groups involved to this plugin
                plugin.getGroups = function() {
                    return $groups;
                };

                plugin.init();

                plugin.destroy = function() {
                    var $groups = plugin.getGroups();
                    $.removeData($groups, 'TileDrag');
                    $groups.remove();

                    $element.remove();

                    if ($draggingTile) {
                        $draggingTile.remove();
                    }
                };
            };

            /**
             * Setup for Jquery to access this API later.
             */
            $.fn.TileDrag = function(options) {

                // this.each(function() {
                var group = $(this[0]);
                if (undefined === group.data('TileDrag')) {
                    var plugin = new $.TileDrag(group, options);
                    var $groups = plugin.getGroups();
                    $groups.data('TileDrag', plugin);
                }
                // });

            };

            var exports = {};

            exports.TileDrag = $.TileDrag;

            return exports;
        });
