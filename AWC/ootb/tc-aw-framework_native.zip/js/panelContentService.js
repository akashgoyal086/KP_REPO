// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 */
define( [ 'app' ], function( app ) {
    'use strict';

    var exports = {};

    /**
     * Get View artifact for given Cmd
     *
     * @param {String} cmdId - Cmd Id for the Panel
     *
     * @return {String} View
     */
    exports.getPanelContent = function( cmdId ) {

        // Mock out access to the View/ViewModel which will be pulled from the server

        return { view: app.getBaseUrlPath() + '/html/' + cmdId + 'View.html',
                 viewModel: app.getBaseUrlPath() + '/viewmodel/' + cmdId + 'ViewModel.json'};
    };


    /**
     * Register this service with the AngularJS application.
     */
    app.factory( 'panelContentService', [ function( ) {

        return exports;
    } ] );

    return exports;
} );