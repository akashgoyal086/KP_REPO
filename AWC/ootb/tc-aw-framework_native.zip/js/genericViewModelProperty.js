// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 angular,
 define,
 requirejs,
 document
 */

/**
 * A Generic View Model Property. Views can create custom view models by creating an view model object and adding this
 * property to it.
 *
 * @module js/genericViewModelProperty
 */
define( [ //
'app', //
'angular', //
'jquery', //
'lodash', //
'js/logService' ], //
function( app, ngModule, $, _, logSvc ) {
    'use strict';

    /**
     * Define the base object used to provide all of this module's external API on.
     *
     * @private
     */
    var exports = {};

    /**
     * Editable State of the property object
     *
     * @private
     */
    var PROP_EDITABLE = 'editable';

    /**
     * Value of the property object
     *
     * @private
     */
    var PROP_VALUE = 'value';

    /**
     * Validation error of property object
     *
     * @private
     */
    var PROP_ERROR = 'error';

    /**
     * Required state of property object
     *
     * @private
     */
    var PROP_REQUIRED = 'required';

    /**
     * Overlay type 'viewModelPropertyOverlay', which defines that the overlay has real data(i.e IViewModelProperty).
     *
     * @private
     */
    var VIEW_MODEL_PROPERTY = 'viewModelPropertyOverlay';

    /**
     * Overlay type 'widgetOverlay', which defines that the overlay has widget data.
     *
     * @private
     */
    var WIDGET = 'widgetOverlay';

    /**
     * Integer minimum value, which is equal to Java Integer's minimum value
     */
    var _integerMinValue = -2147483648;

    /**
     * Integer maximum value, which is equal to Java Integer's maximum value
     */
    var _integerMaxValue = 2147483647;

    /**
     * Cache document ng element to retrieve the scope and trigger digest cycle.
     *
     * @private
     */
    var docNgElement = ngModule.element( document.body );

    /**
     * Constructor for a GenericViewModelProperty used to hold all Teamcenter property description and view state.
     * <P>
     * Note: Unless otherwise noted, the various parameters are simply set, unmodified and with the same name, as
     * properties on the resulting object created by this constructor. Parameters what have a suffix of 'In' are
     * modified in some way before being set as properties.
     *
     * @param {String} propertyName - the name/id of the property. Has to be unique within the object
     * @param {String} propertyDisplayName - user displayable name of the property
     * @param {String} dataType - data type of the property
     * @param {Object} value - real value of the property. The internal (database) representation of the
     *          property's value.
     * @param {StringArray} displayValuesIn - display value of the property. Arrays of string representing the
     *          current user displayable value(s) of the property.
     *
     * @return {NativeGenericViewModelProperty} A new instance of this class.
     */
    exports.createViewModelProperty = function( propertyName, propertyDisplayName, dataType, value, displayValuesIn ) {
        var propOverlay = {};
        var displayValuesFinal = ( displayValuesIn === null ? [ '' ] : displayValuesIn );

        propOverlay.propertyName = propertyName;
        propOverlay.propertyDisplayName = propertyDisplayName;
        propOverlay.type = dataType;

        propOverlay.dbValue = value;
        propOverlay.displayValues = displayValuesFinal;

        propOverlay.isNull = false;
        propOverlay.editable = true;
        propOverlay.isEnabled = true;
        propOverlay.isRichText = false;
        propOverlay.isRequired = false;
        propOverlay.isLocalizable = false;
        propOverlay.isDisplayable = true;
        propOverlay.isAutoAssignable = false;
        propOverlay.isArray = false;
        propOverlay.valueUpdated = false;
        propOverlay.displayValueUpdated = false;
        propOverlay.editableInViewModel = false;
        propOverlay.isPropertyModifiable = true;

        propOverlay.isEditable = propOverlay.editable && propOverlay.editableInViewModel && propOverlay.isPropertyModifiable;

        propOverlay.arrayLength = -1;
        propOverlay.error = null;

        propOverlay.propertyLabelDisplay = "PROPERTY_LABEL_AT_SIDE";
        propOverlay.editLayoutSide = false;

        propOverlay.uiValue = displayValuesFinal.join( ', ' );
        propOverlay.overlayType = VIEW_MODEL_PROPERTY;

        if( _.isArray( value ) ) {
            propOverlay.value = value.slice(0);
        } else {
            propOverlay.value = value;
        }

        if( _.isArray( displayValuesFinal ) ) {
            propOverlay.prevDisplayValues = displayValuesFinal.slice(0);
        } else {
            propOverlay.prevDisplayValues = displayValuesFinal;
        }

        propOverlay.dateApi = {};
        propOverlay.dateApi.isDateEnabled = true;
        propOverlay.dateApi.isTimeEnabled = true;

        propOverlay.radioBtnApi = {};

        return propOverlay;
    };

    /**
     * Update the model data. The view model should use this method to update property data
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Object} value - real value of the property. The internal (database) representation of the
     *          property's value.
     * @param {StringArray} displayValues - display value of the property. Array of strings representing the
     *          current user displayable value(s) of the property.
     * @param {Boolean} isNull - is the property value null
     * @param {Boolean} isEditable - TRUE if the user should have the ability to change the property's value. FALSE
     *          if the value is read-only.
     */
    exports.updateModelData = function( propOverlay, value, displayValues, isNull, isEditable ) {
        var displayValuesFinal = ( displayValues === null ? [ '' ] : displayValues );

        propOverlay.dbValue = value;
        propOverlay.displayValues = displayValuesFinal;
        propOverlay.isNull = isNull;
        propOverlay.editable = isEditable;
        propOverlay.uiValue = displayValuesFinal.join( ', ' );

        if( _.isArray( value ) ) {
            propOverlay.value = value.slice(0);
        } else {
            propOverlay.value = value;
        }

        if( _.isArray( displayValuesFinal ) ) {
            propOverlay.prevDisplayValues = displayValuesFinal.slice(0);
        } else {
            propOverlay.prevDisplayValues = displayValuesFinal;
        }

        if( propOverlay.isArray ) {
            propOverlay.displayValsModel = [];
            for( var i = 0; i < propOverlay.displayValues.length; i++ ) {
                propOverlay.displayValsModel.push( {
                    displayValue: propOverlay.displayValues[ i ],
                    selected: false
                } );
            }
        }
    };

    /**
     * Trigger digest cycle of root scope so that widgets get reflected to the overlay object updates.
     */
    exports.triggerDigestCycle = function() {
        // trigger angular digest cycle on root scope so that value updates get reflected
        if( docNgElement && docNgElement.scope() ) {
            docNgElement.scope().$evalAsync();
        }
    };

    /**
     * Set the internal value of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Object} value - real value of the property. The internal (database) representation of the
     *          property's value.
     */
    exports.setValue = function( propOverlay, value ) {
        var sameAsOriginal = _.isEqual( value, propOverlay.value );

        if( (!propOverlay.valueUpdated && !sameAsOriginal) ||
            (propOverlay.valueUpdated && !_.isEqual(value, propOverlay.newValue)) ) {
            propOverlay.valueUpdated = !sameAsOriginal;
            propOverlay.dbValue = value;

            if( _.isArray( value ) ) {
                propOverlay.newValue = value.slice(0);
            } else {
                propOverlay.newValue = value;
            }

            propOverlay.error = null;

            if( propOverlay.propApi && propOverlay.propApi.notifyPropChange ) {
                propOverlay.propApi.notifyPropChange( PROP_VALUE );
            }

            exports.triggerDigestCycle();
        }
    };

    /**
     * Set the old value of the view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Object} oldValues - Old Value of property.
     */
    exports.setOldValues = function( propOverlay, oldValues ) {
        var oldValuesFinal = ( oldValues === null ? [ '' ] : oldValues );
        propOverlay.oldValues = oldValuesFinal;
        propOverlay.oldValue = oldValuesFinal.join( ', ' );
    };

    /**
     * Set display values of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {StringArray} displayValues - display value of the property. Array of strings representing the
     *          current user displayable value(s) of the property.
     */
    exports.setDisplayValue = function( propOverlay, displayValues ) {
        var sameAsOriginal = _.isEqual( displayValues, propOverlay.prevDisplayValues );

        if( (!propOverlay.displayValueUpdated && !sameAsOriginal) ||
            (propOverlay.displayValueUpdated && !_.isEqual(displayValues, propOverlay.newDisplayValues)) ) {
            propOverlay.displayValueUpdated = !sameAsOriginal;
            propOverlay.error = null;

            exports.updateDisplayValues( propOverlay, displayValues );

            if( propOverlay.propApi && propOverlay.propApi.notifyPropChange ) {
                propOverlay.propApi.notifyPropChange( PROP_VALUE );
            }

            exports.triggerDigestCycle();
        }
    };

    /**
     * Set widget display values of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {StringArray} displayValues - display value of the property. Array of strings representing the
     *          current user displayable value(s) of the property.
     */
    exports.setWidgetDisplayValue = function( propOverlay, displayValues ) {
        var sameAsOriginal = _.isEqual( displayValues, propOverlay.displayValues );

        if( !sameAsOriginal ) {
            exports.updateDisplayValues( propOverlay, displayValues );
            exports.triggerDigestCycle();
        }
    };

    /**
     * Set 'isEnabled' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} isEnabled - TRUE if the property's value should be shown normally and (if also editable)
     *           react to user input. FALSE if the property's value should be shown 'greyed out' and not react to
     *           user input (even if editable).
     */
    exports.setIsEnabled = function( propOverlay, isEnabled ) {
        if( propOverlay.isEnabled !== isEnabled ) {
            propOverlay.isEnabled = isEnabled;
            exports.triggerDigestCycle();
        }
    };

    /**
     * Set 'isRichText' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} isRichText - TRUE if the string value of the property is in HTML format and should be
     *           displayed using HTML formatting rules and edited with the 'rich text' editor.
     */
    exports.setIsRichText = function( propOverlay, isRichText ) {
        if( propOverlay.isRichText !== isRichText ) {
            propOverlay.isRichText = isRichText;
            exports.triggerDigestCycle();
        }
    };

    /**
     * Set 'isNull' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} isNull - TRUE if the current property value is 'no value'. FALSE if the value is valid as is.
     */
    exports.setIsNull = function( propOverlay, isNull ) {
        if( propOverlay.isNull !== isNull ) {
            propOverlay.isNull = isNull;
        }
    };

    /**
     * Set 'isRequired' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} isRequired - TRUE if the property's value is required to sucessfully complete some operation
     *           that uses it. FALSE if the property's value is optional.
     */
    exports.setIsRequired = function( propOverlay, isRequired ) {
        if( propOverlay.isRequired !== isRequired ) {
            propOverlay.isRequired = isRequired;
            if( propOverlay.propApi && propOverlay.propApi.notifyPropChange ) {
                propOverlay.propApi.notifyPropChange( PROP_REQUIRED );
            }

            // Set required place holder text if 'isRequired' flag is true
            if( propOverlay.isRequired ) {
                app.localeSvc.getTextPromise().then( function( localTextBundle ) {
                    propOverlay.propertyRequiredText = localTextBundle.REQUIRED_TEXT;
                } );
            } else {
                propOverlay.propertyRequiredText = '';
            }

            exports.triggerDigestCycle();
        }
    };

    /**
     * Set 'isLocalizable' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} isLocalizable - TRUE if the property value's UI should include the option to alow any user
     *            entered value to be converted from local language (as entered) into some other system language.
     */
    exports.setIsLocalizable = function( propOverlay, isLocalizable ) {
        if( propOverlay.isLocalizable !== isLocalizable ) {
            propOverlay.isLocalizable = isLocalizable;
        }
    };

    /**
     * Set 'isDisplayable' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} isDisplayable - isDisplayable state of view model property.
     */
    exports.setIsDisplayable = function( propOverlay, isDisplayable ) {
        if( propOverlay.isDisplayable !== isDisplayable ) {
            propOverlay.isDisplayable = isDisplayable;
        }
    };

    /**
     * Set 'isAutoAssignable' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} isAutoAssignable - TRUE if the property's value can/should be assigned automatically by
     *           Teamcenter. FALSE if the property's value is not normally assigned/controlled by Teamcenter.
     */
    exports.setIsAutoAssignable = function( propOverlay, isAutoAssignable ) {
        if( propOverlay.isAutoAssignable !== isAutoAssignable ) {
            propOverlay.isAutoAssignable = isAutoAssignable;
        }
    };

    /**
     * Set 'maxLength' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Number} maxLength - If not equal to '-1' or '0', this parameter specifies the maximum number of
     *           characters allowed in a string type property.
     */
    exports.setLength = function( propOverlay, maxLength ) {
        if( maxLength !== -1 && maxLength !== 0 ) {
            propOverlay.maxLength = maxLength;
            exports.triggerDigestCycle();
        }
    };

    /**
     * Set 'numberOfCharacters' of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Number} numberOfCharacters - If not equal to '-1' or '0', this parameter specifies the number of
     *           characters in a string type property.
     */
    exports.setNumberOfCharacters = function( propOverlay, numberOfCharacters ) {
        if( numberOfCharacters !== -1 && numberOfCharacters !== 0 ) {
            propOverlay.numberOfCharacters = numberOfCharacters;
        }
    };

    /**
     * Set 'numerOfLines' of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Number} numerOfLines - If not equal to '-1' or '0', this parameter specifies the number of
     *           lines allowed in a property.
     */
    exports.setNumberOfLines = function( propOverlay, numerOfLines ) {
        if( numerOfLines !== -1 && numerOfLines !== 0 ) {
            propOverlay.numerOfLines = numerOfLines;
        }
    };

    /**
     * Set 'isArray' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} isArray - TRUE if the property can have more than one value in an ordered list. FALSE if the
     *            property can have only a single value.
     */
    exports.setIsArray = function( propOverlay, isArray ) {
        if( propOverlay.isArray !== isArray ) {
            propOverlay.isArray = isArray;

            propOverlay.displayValsModel = [];
            for( var i = 0; i < propOverlay.displayValues.length; i++ ) {
                propOverlay.displayValsModel.push( {
                    displayValue: propOverlay.displayValues[ i ],
                    selected: false
                } );
            }

            // Set array place holder text if 'isArray' flag is true and the property is not required.
            if( propOverlay.isArray ) {
                app.localeSvc.getTextPromise().then( function( localTextBundle ) {
                    if( !propOverlay.isRequired ) {
                        propOverlay.propertyRequiredText = localTextBundle.ARRAY_PLACEHOLDER_TEXT;
                    }

                    // Set array button's tool tips
                    propOverlay.moveUpButtonTitle = localTextBundle.MOVE_UP_BUTTON_TITLE;
                    propOverlay.moveDownButtonTitle = localTextBundle.MOVE_DOWN_BUTTON_TITLE;
                    propOverlay.removeButtonTitle = localTextBundle.REMOVE_BUTTON_TITLE;
                } );
            }

            exports.triggerDigestCycle();
        }
    };

    /**
     * Set 'arrayLength' state of view model property. Applies only if the property is an array
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Number} arrayLength - set the array length. Set "-1" if unlimited array.
     */
    exports.setArrayLength = function( propOverlay, arrayLength ) {
        if( propOverlay.arrayLength !== arrayLength ) {
            propOverlay.arrayLength = arrayLength;
        }
    };

    /**
     * Set 'referenceTypeName' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {String} typeName - set reference type name of view model property.
     */
    exports.setReferenceType = function( propOverlay, typeName ) {
        if( propOverlay.referenceTypeName !== typeName ) {
            propOverlay.referenceTypeName = typeName;
        }
    };

    /**
     * Set data type of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {String} dataType - data type of view model property.
     */
    exports.setDataType = function( propOverlay, dataType ) {
        if( propOverlay.type !== dataType ) {
            propOverlay.type = dataType;
        }
    };

    /**
     * Set 'error' of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {String} error - The message that should be displayed when some aspect of the property's value is not
     *            correct. This value must be 'null' or an empty string to not have the error be displayed.
     */
    exports.setError = function( propOverlay, error ) {
        if( propOverlay.error !== error ) {
            propOverlay.error = error;
            if( propOverlay.propApi && propOverlay.propApi.notifyPropChange ) {
                propOverlay.propApi.notifyPropChange( PROP_ERROR );
            }
        }
    };

    /**
     * Set client validation error of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {String} clientValidationError - set client validation error of view model property.
     */
    exports.setClientValidationError = function( propOverlay, clientValidationError ) {
        if( propOverlay.clientValidationError !== clientValidationError ) {
            propOverlay.clientValidationError = clientValidationError;
            exports.triggerDigestCycle();
        }
    };

    /**
     * Set server validation error flag of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {String} hasServerValidationError - set server validation error flag of view model property.
     */
    exports.setServerValidationError = function( propOverlay, hasServerValidationError ) {
        if( propOverlay.hasServerValidationError !== hasServerValidationError ) {
            propOverlay.hasServerValidationError = hasServerValidationError;
            exports.triggerDigestCycle();
        }
    };

    /**
     * Set property display name of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {String} propertyDisplayName - user displayable name of view model property.
     */
    exports.setPropertyDisplayName = function( propOverlay, propertyDisplayName ) {
        if( propOverlay.propertyDisplayName !== propertyDisplayName ) {
            propOverlay.propertyDisplayName = propertyDisplayName;
        }
    };

    /**
     * Set property label display of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {String} propertyLabelDisplay - String value of property label display.
     */
    exports.setPropertyLabelDisplay = function( propOverlay, propertyLabelDisplay ) {
        if( propOverlay.propertyLabelDisplay !== propertyLabelDisplay ) {
            propOverlay.propertyLabelDisplay = propertyLabelDisplay;
            exports.triggerDigestCycle();
        }
    };

    /**
     * Reset updates which converts back to original value.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     */
    exports.resetUpdates = function( propOverlay ) {
        var fireEvent = false;

        if( propOverlay.valueUpdated ) {
            propOverlay.valueUpdated = false;
            fireEvent = true;
        }

        if( propOverlay.displayValueUpdated ) {
            propOverlay.displayValueUpdated = false;
            fireEvent = true;
        }

        if( propOverlay.error ) {
            propOverlay.error = null;
            if( !fireEvent && propOverlay.propApi && propOverlay.propApi.notifyPropChange ) {
                propOverlay.propApi.notifyPropChange( PROP_ERROR );
            }
        }

        if( fireEvent ) {
            if( propOverlay.propApi && propOverlay.propApi.notifyPropChange ) {
                propOverlay.propApi.notifyPropChange( PROP_VALUE );
            }

            exports.resetValues( propOverlay );
        }

        exports.triggerDigestCycle();
    };

    /**
     * Reset db values and display values back to original value.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     */
    exports.resetValues = function( propOverlay ) {
        if( _.isArray( propOverlay.value ) ) {
            propOverlay.dbValue = propOverlay.value.slice(0);
        } else {
            propOverlay.dbValue = propOverlay.value;
        }

        var displayValuesFinal = ( propOverlay.prevDisplayValues === null ? [ '' ] : propOverlay.prevDisplayValues );
        propOverlay.displayValues = displayValuesFinal;
        propOverlay.uiValue = displayValuesFinal.join( ', ' );

        if( propOverlay.isArray ) {
            propOverlay.displayValsModel = [];
            for( var i = 0; i < propOverlay.displayValues.length; i++ ) {
                propOverlay.displayValsModel.push( {
                    displayValue: propOverlay.displayValues[ i ],
                    selected: false
                } );
            }
        }
    };

    /**
     * Set edit state of view model property. If the property is editable and editable in view model then the 'isEditable'
     * flag is set to true which shows the properties as editable.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} editable - set edit state of view model property.
     */
    exports.setEditState = function( propOverlay, editable ) {
        if( propOverlay.editableInViewModel !== editable ) {
            propOverlay.editableInViewModel = editable;
            propOverlay.error = null;
            propOverlay.isEditable = propOverlay.editable && propOverlay.editableInViewModel && propOverlay.isPropertyModifiable;
            exports.setEditLayoutSide( propOverlay );

            if( propOverlay.propApi.setLOVValueProvider ) {
                propOverlay.propApi.setLOVValueProvider();
            }

            if( propOverlay.propApi.setAutoAssignHandler ) {
                propOverlay.propApi.setAutoAssignHandler();
            }

            if( propOverlay.propApi.setObjectLinkPropertyHandler ) {
                propOverlay.propApi.setObjectLinkPropertyHandler();
            }

            if( propOverlay.propApi && propOverlay.propApi.notifyPropChange ) {
                propOverlay.propApi.notifyPropChange( PROP_EDITABLE );
            }

            exports.triggerDigestCycle();
        }
    };

    /**
     * Set 'editable' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} editable - set editable state of view model property.
     */
    exports.setEditable = function( propOverlay, editable ) {
        if( propOverlay.editable !== editable ) {
            propOverlay.editable = editable;
            exports.triggerDigestCycle();
        }
    };

    /**
     * Set 'isEditable' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} isEditable - TRUE if the user should have the ability to change the property's value. FALSE
     *           if the value is read-only.
     */
    exports.setIsEditable = function( propOverlay, isEditable ) {
        if( propOverlay.isEditable !== isEditable ) {
            propOverlay.isEditable = isEditable;
            exports.setEditLayoutSide( propOverlay );
            exports.triggerDigestCycle();
        }
    };

    /**
     * Set 'isPropertyModifiable' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} isPropertyModifiable - TRUE if the user should have the ability to change the property's value. FALSE
     *           if the value is read-only.
     */
    exports.setIsPropertyModifiable = function( propOverlay, isPropertyModifiable ) {
        if( propOverlay.isPropertyModifiable !== isPropertyModifiable ) {
            propOverlay.isPropertyModifiable = isPropertyModifiable;

            // set is editable flag whenever property modifiable state is changed
            propOverlay.isEditable = propOverlay.editable && propOverlay.editableInViewModel && propOverlay.isPropertyModifiable;
            exports.setEditLayoutSide( propOverlay );
            exports.triggerDigestCycle();
        }
    };

    /**
     * Set edit layout side state of view model property. For 'Boolean' and 'Object' based properties which doesn't
     * have LOV's this flag is set to true.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     */
    exports.setEditLayoutSide = function( propOverlay ) {
        if( propOverlay.type === 'BOOLEAN' || propOverlay.type === 'OBJECT' ) {
            if( propOverlay.isEditable && !propOverlay.hasLov ) {
                propOverlay.editLayoutSide = true;
            } else {
                propOverlay.editLayoutSide = false;
            }
        }
    };

    /**
     * Set 'hasLov' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} hasLov - TRUE if the property has a specific list of values associated with it.
     */
    exports.setHasLov = function( propOverlay, hasLov ) {
        if( propOverlay.hasLov !== hasLov ) {
            propOverlay.hasLov = hasLov;
            exports.setEditLayoutSide( propOverlay );
            exports.triggerDigestCycle();
        }
    };

    /**
     * Set 'renderingHint' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {String} renderingHint - Depending on the type, this string indicates some variation in how the
     *           property's value should be displayed (e.g. For 'BOOLEAN' type, valid values include 'radiobutton',
     *           'togglebutton', 'checkbox'. For 'STRING' type, valid values include 'label', 'textbox',
     *           'textfield', 'textarea', 'longtext').
     */
    exports.setRenderingHint = function( propOverlay, renderingHint ) {
        if( propOverlay.renderingHint !== renderingHint ) {
            propOverlay.renderingHint = renderingHint;
            exports.triggerDigestCycle();
        }
    };

    /**
     * Set 'overlayType' of view model property.
     * 'viewModelPropertyOverlay' - which defines that the overlay has real data(i.e IViewModelProperty).
     * 'widgetOverlay' - which defines that the overlay has widget data.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {String} overlayType - set overlay type of view model property.
     */
    exports.setOverlayType = function( propOverlay, overlayType ) {
        if( propOverlay.overlayType !== overlayType ) {
            propOverlay.overlayType = overlayType;
        }
    };

    /**
     * Set 'autofocus' state of view model property. Which defines whether the widget needs to be autofocused or NOT
     * bound to this property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} autofocus - set autofocus state of view model property.
     */
    exports.setAutoFocus = function( propOverlay, autofocus ) {
        if( propOverlay.autofocus !== autofocus ) {
            propOverlay.autofocus = autofocus;
        }
    };

    /**
     * Set 'dirty' state of view model property. Which defines whether the widget needs to be dirty or NOT.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} dirty - set dirty state of view model property.
     */
    exports.setDirty = function( propOverlay, dirty ) {
        if( propOverlay.dirty !== dirty ) {
            propOverlay.dirty = dirty;
        }
    };

    /**
     * Set array max row count of view model property. Number of visible rows for array widget.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Number} maxRowCount - set array max row count of view model property.
     */
    exports.setMaxRowCount = function( propOverlay, maxRowCount ) {
        if( maxRowCount !== -1 && maxRowCount !== 0 && propOverlay.maxRowCount !== maxRowCount ) {
            propOverlay.maxRowCount = maxRowCount;
        }
    };

    /**
     * Set minimum date of view model property. Only applicable for date widget.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Date} dateToSet - Date object that represents the earliest date/time this widget should allow.
     */
    exports.setMinimumDate = function( propOverlay, dateToSet ) {
        if( propOverlay && propOverlay.dateApi ) {
            propOverlay.dateApi.minDate = dateToSet;
        }
    };

    /**
     * Set maximum date of view model property. Only applicable for date widget.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Date} dateToSet - Date object that represents the latest date/time this widget should allow.
     */
    exports.setMaximumDate = function( propOverlay, dateToSet ) {
        if( propOverlay && propOverlay.dateApi ) {
            propOverlay.dateApi.maxDate = dateToSet;
        }
    };

    /**
     * Set date Enabled state of view model property. Which defines whether the date should be shown in date widget.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} enabled TRUE if date is enabled
     */
    exports.setDateEnabled = function( propOverlay, enabled ) {
        if( propOverlay && propOverlay.dateApi ) {
            propOverlay.dateApi.isDateEnabled = enabled;
        }
    };

    /**
     * Set time Enabled state of view model property. Which defines whether the time should be shown in date widget.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} enabled TRUE if time is enabled.
     */
    exports.setTimeEnabled = function( propOverlay, enabled ) {
        if( propOverlay && propOverlay.dateApi ) {
            propOverlay.dateApi.isTimeEnabled = enabled;
        }
    };

    /**
     * Set vertical state of view model property. Which defines whether the radio button should show vertical or not.
     * Only applicable for radio button widget.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {Boolean} vertical TRUE if radio button need to be shown vertically.
     */
    exports.setRadioButtonVertical = function( propOverlay, vertical ) {
        if( propOverlay && propOverlay.radioBtnApi ) {
            propOverlay.radioBtnApi.vertical = vertical;
            exports.triggerDigestCycle();
        }
    };

    /**
     * Set radio button's custom true label of view model property. Only applicable for radio button widget.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {String} customTrueLabel custom true label for radio button.
     */
    exports.setRadioButtonCustomTrueLabel = function( propOverlay, customTrueLabel ) {
        if( propOverlay && propOverlay.radioBtnApi ) {
            propOverlay.radioBtnApi.customTrueLabel = customTrueLabel;
            exports.triggerDigestCycle();
        }
    };

    /**
     * Set radio button's custom false label of view model property. Only applicable for radio button widget.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {String} customFalseLabel custom false label for radio button.
     */
    exports.setRadioButtonCustomFalseLabel = function( propOverlay, customFalseLabel ) {
        if( propOverlay && propOverlay.radioBtnApi ) {
            propOverlay.radioBtnApi.customFalseLabel = customFalseLabel;
            exports.triggerDigestCycle();
        }
    };

    /**
     * Has this property been modified in the view model
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @return {Boolean} TRUE if the property is modified in the view model.
     */
    exports.isModified = function( propOverlay ) {
        return propOverlay.valueUpdated || propOverlay.displayValueUpdated;
    };

    /**
     * Get the Display Value for Property. View uses Display Value for rendering if the property is not in edit state.
     * <br>
     * View uses Display Value for rendering if the property is not in edit state. If it is edit state, it has to use
     * the value.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @return {StringArray} Array of display values
     */
    exports.getDisplayValues = function( propOverlay ) {
        /**
         * Return new display values when view model property display values are updated.
         */
        if( propOverlay.displayValueUpdated ) {
            return propOverlay.newDisplayValues;
        }

        /**
         * Return the display value as per the real value when they are out of sync. If valueUpdated is true but
         * displayValueUpdated is false, then it means they are out of sync.
         */
        if( propOverlay.valueUpdated && propOverlay.newValue !== null && propOverlay.newValue !== undefined ) {
            var displayValues = [];

            if( propOverlay.isArray ) {
                if( propOverlay.type === 'DATEARRAY' ) {
                    for( var indx = 0; indx < propOverlay.newValue.length; indx++ ) {
                        displayValues.push( app.dateTimeSvc.formatSessionDateTime( propOverlay.newValue[ indx ] ) );
                    }
                } else if( propOverlay.type === 'OBJECTARRAY' ) {
                    for( var indx = 0; indx < propOverlay.newValue.length; indx++ ) {
                        displayValues.push( propOverlay.propApi.getDisplayName( propOverlay.newValue[ indx ] ) );
                    }
                } else {
                    /**
                     * For LOVs use property display values which are already set by LOV widget.
                     */
                    if( propOverlay.hasLov ) {
                        for( var indx = 0; indx < propOverlay.displayValues.length; indx++ ) {
                            displayValues.push( propOverlay.displayValues[ indx ].toString() );
                        }
                    } else {
                        for( var indx = 0; indx < propOverlay.newValue.length; indx++ ) {
                            displayValues.push( propOverlay.newValue[ indx ].toString() );
                        }
                    }
                }
            } else {
                if( propOverlay.type === 'DATE' ) {
                    displayValues.push( app.dateTimeSvc.formatSessionDateTime( propOverlay.newValue ) );
                } else if( propOverlay.type === 'OBJECT' ) {
                    displayValues.push( propOverlay.propApi.getDisplayName( propOverlay.newValue ) );
                } else {
                    /**
                     * For LOVs use property uiValue which is already set by LOV widget.
                     */
                    if( propOverlay.hasLov ) {
                        displayValues.push( propOverlay.uiValue.toString() );
                    } else {
                        displayValues.push( propOverlay.newValue.toString() );
                    }
                }
            }

            return displayValues;
        }

        return propOverlay.prevDisplayValues;
    };

    /**
     * Returns TRUE if the internal value of the property is a number.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @return {Boolean} TRUE if the dbValue of the property overlay is a number.
     */
    exports.isDbValueNumber = function( propOverlay ) {
        if( propOverlay.valueUpdated ) {
            return app._.isNumber( propOverlay.newValue );
        }

        return app._.isNumber( propOverlay.value );
    };

    /**
     * Returns TRUE if the internal value of the property is a boolean.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @return {Boolean} TRUE if the dbValue of the property overlay is a boolean.
     */
    exports.isDbValueBoolean = function( propOverlay ) {
        if( propOverlay.valueUpdated ) {
            return app._.isBoolean( propOverlay.newValue );
        }

        return app._.isBoolean( propOverlay.value );
    };

    /**
     * Returns TRUE if the overlayType is widgetOverlay.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @return {Boolean} TRUE if the overlay type is widgetOverlay.
     */
    exports.isOverlayTypeWidget = function( propOverlay ) {
        if( propOverlay.overlayType && propOverlay.overlayType === WIDGET ) {
            return true;
        }
        return false;
    };

    /**
     * Set 'initialize' state of view model property.
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     */
    exports.initialize = function( propOverlay ) {
        propOverlay.initialize = true;
    };

    /**
     * Updates property display values
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     * @param {StringArray} displayValues - display value of the property. Array of strings representing the
     *          current user displayable value(s) of the property.
     */
    exports.updateDisplayValues = function( propOverlay, displayValues ) {
        var displayValuesFinal = ( displayValues === null ? [ '' ] : displayValues );

        if( displayValuesFinal && displayValuesFinal.length === 0 ) {
            propOverlay.isNull = true;
        } else {
            propOverlay.isNull = false;
        }

        propOverlay.displayValues = displayValuesFinal;
        propOverlay.newDisplayValues = displayValuesFinal;
        propOverlay.uiValue = displayValuesFinal.join( ', ' );

        if( propOverlay.isArray ) {
            propOverlay.displayValsModel = [];
            for( var i = 0; i < propOverlay.displayValues.length; i++ ) {
                propOverlay.displayValsModel.push( {
                    displayValue: propOverlay.displayValues[ i ],
                    selected: false
                } );
            }
        }
    };

    /**
     * Updates view model property with updated values
     *
     * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
     */
    exports.updateViewModelProperty = function( propOverlay ) {
        var isValid = false;

        if( propOverlay.type === 'INTEGER' ) {
            if( isFinite( propOverlay.dbValue ) ) {
                if( propOverlay.dbValue !== null && propOverlay.dbValue !== "" ) {
                    propOverlay.dbValue = Number( propOverlay.dbValue );
                    if( propOverlay.dbValue >= _integerMinValue && propOverlay.dbValue <= _integerMaxValue ) {
                        isValid = true;
                    }
                } else {
                    isValid = true;
                }
            }
        } else if( propOverlay.type === 'DOUBLE' || propOverlay.type === 'DATE' ) {
            if( isFinite( propOverlay.dbValue ) ) {
                if( propOverlay.dbValue !== null && propOverlay.dbValue !== "" ) {
                    propOverlay.dbValue = Number( propOverlay.dbValue );
                }
                isValid = true;
            }
        } else {
            isValid = true;
        }

        if( isValid ) {
            if( propOverlay.type !== 'OBJECT' && propOverlay.type !== 'OBJECTARRAY') {
                exports.setValue( propOverlay, propOverlay.dbValue );

                if( propOverlay.propApi && propOverlay.propApi.fireValueChangeEvent ) {
                    propOverlay.propApi.fireValueChangeEvent();
                }
            } else {
                var uidsArray = propOverlay.dbValue;
                if( !propOverlay.isArray ) {
                    uidsArray = [];
                    if( propOverlay.dbValue !== null && propOverlay.dbValue !== undefined  ) {
                        uidsArray.push( propOverlay.dbValue );
                    } else {
                        uidsArray.push( '' );
                    }
                }

                requirejs( [ 'soa/dataManagementService' ], function( dmSvc ) {
                    dmSvc.loadObjects( uidsArray ).then( function( response ) {
                        exports.setValue( propOverlay, propOverlay.dbValue );

                        if( propOverlay.propApi && propOverlay.propApi.fireValueChangeEvent ) {
                            propOverlay.propApi.fireValueChangeEvent();
                        }
                    } );
                } );
            }
        } else {
            /**
             * Change isNull flag to false, if dbValue & uiValue exists and even though
             * its NOT valid.
             */
            if( propOverlay.isNull && propOverlay.dbValue && propOverlay.uiValue ) {
                propOverlay.isNull = false;
            }
        }
    };

    /**
     * Register this service with the AngularJS application.
     *
     * @return {Void}
     */
    app.factory( 'genericViewModelProperty', function() {
        return exports;
    } );

    return exports;
} );