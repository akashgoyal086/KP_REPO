//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 console
 */

/**
 * This service is for exposing the native js data provider behavior.
 * The module supports loading the module from GWT and getting the native JS code invoked.
 *
 * @module js/NgDataProvider.js
 */
define([ 'app', 'angular', 'jquery' ],
function (app, ngModule, $) {
    'use strict';
    var exports = {};

    /**
     * native JS data adapter.  This sits "between" the data provider and the consumer
     * of that data.  It acts as the api mediator to request more data.
     */
    var NativeDataAdapter = function () {
        var self = this;

        self.whatamI = "NativeDataAdapter"; // debug aid

        // members

        // sub structure/ references
        self.bindingCollection = {data: []}; // single data member as native array
        self.dataProvider = {moreRows: false};

        self.sortInfo = {}; // placeholder for future expansion
        self.filterInfo = {};  // placeholder for future expansion

        // operations
        self.reset = function () {
            console.log('Phase 0 - nativeDataAdapter reset');
        };

        self.dispose = function () {
            console.log('Phase 0 -  nativeDataAdapter dispose');
        };

        self.getFirstPage = function (promise) {
            console.log('Phase 0 -  nativeDataAdapter getFirstPage');
        };

        self.getNextPage = function (skipcount, promise) {
            console.log('Phase 0 - nativeDataAdapter getNextPage()');
            if (self.dataProvider && self.dataProvider.getNextPage ) {
                console.log('Phase 0 - nativeDataAdapter, invoke data source for next page');
                // TODO - may need to come back here to push data into the bind collection
                // or to update counts & state here????    nested promise?
                self.dataProvider.getNextPage(skipcount, promise);
            }else{
                console.log('Phase 0 - nativeDataAdapter, no data source, resolve with empty');
                self.moreRows = false;
                // TODO - how else to identify no more data?
                if (self.bindingCollection && self.bindingCollection.data) {
                    self.bindingCollection.data.length = 0; // clear
                }
                promise.resolve();
            }
        };


        self.getSortInfo = function () {
            return this.sortInfo;
        };

        self.getFilterInfo = function () {
            return this.filterInfo;
        };

    };

    app.factory('NativeDataAdapterService', function () {
        return new NativeDataAdapter();
    } );




    /**
     * native JS implementation of the data provider.
     * This is the paging based provider which can obtain more data from a service as requested.
     */
    var NativePagingDataProvider = function () {
        var self = this;

        self.whatamI = "NativePagingDataProvider"; // debug aid

        // members
        self.totalRowCount = 0;
        self.moreRows = true; // false;

        // sub structure/ references

        // operations
        self.dispose = function () {
            console.log('Phase 0 -  nativepagingdataProvider dispose');
        };

        self.getFirstPage = function (promise) {
            console.log('Phase 0 -  nativepagingdataProvider getFirstPage');
        };

        self.getNextPage = function (skipcount, promise) {
            console.log('Phase 0 - nativepagingdataProvider getNextPage()');
        };


    };

    app.factory('NativePagingDataProviderService', function () {
        return new NativePagingDataProvider();
    } );



    /**
     * native JS implementation of the data provider.
     * This is the fixed size provider which knows the full set of data, no paging needed/allowed.
     */
    var NativeFixedDataProvider = function () {
        var self = this;

        self.whatamI = "NativeFixedDataProvider"; // debug aid

        // members
        self.totalRowCount = 0;
        self.moreRows = false;
        self.m_data = [];

        // sub structure/ references


        // operations
        self.dispose = function () {
            console.log('Phase 0 -  nativeFixedDataProvider dispose');
        };

        // provide the native array of data contexts/entities to be added to the binding collection
        self.setObjects  = function (list) {
            self.m_data = list;
            self.totalRowCount = list.length;
        };

        self.getFirstPage = function (promise) {
            console.log('Phase 0 -  nativeFixedDataProvider getFirstPage');
            promise.resolve(self.m_data);
        };

        self.getNextPage = function (skipcount, promise) {
            console.log('Phase 0 - nativeFixedDataProvider getNextPage()');
            promise.resolve([]); // no more data
        };


    };

    app.factory('NativeFixedDataProviderService', function () {
        return new NativeFixedDataProvider();
    } );




    /**
     * external facing factory function
     */
    exports.getDataAdapter = function () {
        return new NativeDataAdapter();
    };

    /**
     * external facing factory function
     */
    exports.getNativePagingDataProvider = function () {
        return new NativePagingDataProvider();
    };

    /**
     * external facing factory function
     */
    exports.getFixedDataProvider = function () {
        return new NativeFixedDataProvider();
    };

    return exports;

} ); // End RequireJS Define