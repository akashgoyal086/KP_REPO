// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 window,
 localStorage,
 _app,
 angular,
 define
 */

/**
 * This service is used to announce various level logging events to the console.
 *
 * @module js/eventBus
 */
define( [ 'postal' ], function( postal ) {
    'use strict';

    var exports = postal;

    /** Build ID to ensure unique entry into the local storage */
    var _buildID = '{INSERT_HERE_BUILD_ID}';

    /** Browser ID Suffix for local storage data */
    var _browserID = '_B_GUID_:';

    /**
     * The id to include in the keys for all topics managed by this service.
     */
    var _localStorageId = _buildID;

    /**
     * @returns {String} Base URL for the current application's root 'document' without any protocol, machine, port or
     *          query attributes and (if otherwise valid) without a trailing '/'
     *
     * <pre>
     * (e.g. 'http://100.100.100.100:8888/awc/?locale=en_US#showGateway' would return 'awc' ).
     * (e.g. 'http://cii6s072:7001/madev1016/#showGateway' would return 'madev1016' ).
     * </pre>
     */
    var _getLocalStorageId = function() {
        if( _localStorageId !== _buildID ) {
            return _localStorageId;
        }

        if( !angular ) {
            // Support for non-Angular (NodeJS) run.
            _localStorageId = '';
        } else {
            // Regular expression used to match a web server's IP:PORT information
            var regex_endpoint = /^http[s]*\:\/\/[a-z0-9.]+[:]?[0-9]*\//gi;

            // Regular expression used to match a web page's optional HTML source information
            var regex_page_html = /^[a-z0-9]+.html/gi;

            // Get the current page's full URL string
            var s = angular.element( document )[0].location.href;

            // Find the web server 'endpoint' and remove it from the string
            var endpoint = s.match( regex_endpoint );

            s = s.substring( endpoint[0].length );

            // Find the web page's 'html file' (if any) and remove it from the string
            var page = s.match( regex_page_html );

            if( page && page.length > 0 ) {
                s = s.substring( page[0].length );
            }

            // Pull off any hash.
            var i = s.indexOf( '#' );

            if( i !== -1 ) {
                s = s.substring( 0, i );
            }

            // Pull off any query string.
            i = s.indexOf( '?' );

            if( i !== -1 ) {
                s = s.substring( 0, i );
            }

            // Rip off everything after the last slash.
            i = s.lastIndexOf( '/' );
            if( i !== -1 ) {
                s = s.substring( 0, i );
            }

            // Ensure a final slash if non-empty.
            _localStorageId = s.length > 0 ? s : '';
        }

        return _localStorageId;
    };

    /**
     * Subscribe to the given 'topic' on the 'soajs' event channel. When the event is published the given function will
     * be invoked and passed the 'eventData'.
     *
     * @param {String} topic - Topic to subscribe to. A '#' character is interpreted as a wildcard.
     *
     * @param {Function} callbackFn - Function to be invoked and passed 'eventData' when the event is published.
     */
    exports.subscribeSoa = function( topic, callbackFn ) {
        exports.subscribe( {
            channel: "soajs",
            topic: topic,
            callback: callbackFn
        } );
    };

    /**
     * Publish the given 'topic' on the 'soajs' event channel. Tthe given 'eventData' will be passed to each subscribers
     * callback function.
     *
     * @param {String} topic - Topic to publish.
     * @param {Object} eventData - Optional data to pass to the subscribed callback functions.
     */
    exports.publishSoa = function( topic, eventData ) {
        exports.publish( {
            channel: "soajs",
            topic: topic,
            data: eventData
        } );
    };

    /**
     * @param {String} topic - local storage topic (key)
     * @return {String} - unique local storage topic key
     */
    function getLSTopicKey( topic ) {
        return topic + ':' + _getLocalStorageId();
    }

    /**
     * @param {String} topic - local storage topic (key)
     * @param {Function} cb - event handler
     */
    exports.subscribeLocalStorage = function( topic, cb ) {
        window.addEventListener( 'storage',
            function( event ) {
                var ourEvent = _app.$.extend( {}, event ); // Avoid issues with strict, and writing to read only fields on the event
                if( _app._isIE ) {
                    if( ourEvent.newValue ) {
                        var start = ourEvent.newValue.indexOf( _browserID );
                        if( start > -1 ) {
                            var browserID = ourEvent.newValue.substr( start + _browserID.length,
                                ourEvent.newValue.length );
                            ourEvent.newValue = ourEvent.newValue.substr( 0, start );

                            if( browserID === _app.browserInstanceId ) {
                                return;
                            }

                            start = ourEvent.oldValue.indexOf( _browserID );
                            if( start > -1 ) {
                                ourEvent.oldValue = ourEvent.oldValue.substr( 0, start );
                            }
                        }
                    }
                }

                // Ideally we wouldn't have to check for value change but IE doesn't seem to be working correctly.
                if( ourEvent.key === getLSTopicKey( topic ) && ourEvent.newValue !== ourEvent.oldValue ) {
                    cb( ourEvent );
                }
            }, false );
    };

    /**
     * @param {String} topic - local storage topic (key)
     * @param {String} data - data to add to local storage
     */
    exports.publishLocalStorage = function( topic, data ) {
        if( _app._isIE ) {
            data += _browserID + _app.browserInstanceId;
        }

        // Ideally we wouldn't have to check for value change but IE doesn't seem to be working correctly.
        var topicKey = getLSTopicKey( topic );
        var exists = localStorage.hasOwnProperty( topicKey );
        if( exists && data === undefined ) {
            localStorage.removeItem( topicKey );
        } else if( !exists || localStorage[topicKey] !== data ) {
            localStorage.setItem( topicKey, data );
        }
    };

    /**
     * @param {String} topic - local storage topic (key)
     * @return {String} value of local storage (or NULL if the topic is not in the local storage).
     */
    exports.getLocalStorage = function( topic ) {
        var topicKey = getLSTopicKey( topic );
        if( localStorage.hasOwnProperty( topicKey ) ) {
            var item = localStorage[topicKey];
            if( _app._isIE ) {
                var start = item.indexOf( _browserID );
                if( start > -1 ) {
                    item = item.substr( 0, start );
                }
            }
            return item;
        }

        return null;
    };

    /**
     * @param {String} topic - local storage topic (key)
     * @param {Function} cb - event handler
     */
    exports.subscribeWS = function( topic, cb ) {
        exports.subscribeLocalStorage( topic, function( event ) {
            cb( JSON.parse( event.newValue ) );
        } );
    };

    /**
     * @param {String} topic - local storage topic (key)
     * @param {String} data - data to add to local storage
     */
    exports.publishWS = function( topic, data ) {
        // Clear the localStorage entry to ensure that it's communicated to the other clients
        localStorage.removeItem( topic );
        exports.publishLocalStorage( topic, JSON.stringify( data ) );
    };

    /**
     * Subscribe to the 'ctrl-mouse' click on the Siemens logo to kick off the cleanup of obsolete local storage
     * artifacts.
     */
    exports.subscribeSoa( "cdm.logDiagnostics", function( data, envelope ) {
        /** Regular expression used to cleanup older localStorage artifacts */
        var regex = /[a-z]+:(\d)+$/g;

        var keys = Object.keys( localStorage );

        for( var i = 0; i < keys.length; i++ ) {
            if( keys[i].match( regex ) ) {
                localStorage.removeItem( keys[i] );
            }
        }
    } );

    return exports;
} );
