// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 requirejs,
 define
 */
define(
    [ 'app', 'angular', 'js/NgProperty', 'js/genericViewModelProperty', 'soa/kernel/soaService', 'lodash',
        'soa/kernel/propertyPolicyService', 'js/appCtxService', 'js/eventBus', 'soa/preferenceService',
        'js/awDuiLocalizationService', 'js/NotyModule' ],
    function( app, ngModule, ngProperty, genericViewModelPropertyModule, soaSvc, _, propertyPolicyService,
        appCtxServiceModule, eventBus, preferenceService ) {

        'use strict';

        /**
         * Cached reference to the current $http service.
         */
        var _$http = null;

        /**
         * Cached reference to the angular q/promise service
         */
        var _$q = null;

        /*
         * Cached reference to the angular injector
         */
        var _$injector = null;

        /**
         * Cached reference to the appCtxService
         */
        var _appCtxService = null;

        /**
         * Cached reference to the list of appContexts
         */
        var _appContextList = [];

        /**
         * Cached reference to the aw DUI localization service
         */
        var _awDuiLocalizationService = null;

        /**
         * Cached reference to the panel noty service
         */
        var _panelNotyService = null;

        /**
         * Cached reference to the View Model Property Object service
         */
        var _vmPropSvc = null;

        /**
         * Cached reference to the Angular $parse service
         */
        var _$parse = null;

        var exports = {};

        /**
         * Listener for appCtx registration events
         */
        eventBus.subscribeSoa( "appCtx.register", function( context ) {

            if( context && _appContextList.length ) {
                exports.updateViewModel();
            }

        } );
        /**
         * Listener for panel onReveal state registration events
         */
        eventBus.subscribeSoa( "awPanel.reveal", function( context ) {
            if( context.scope ) {
                exports.executeCommand( 'reveal', context.scope );
            }

        } );

        /**
         * @param {String} displayName - Display name of the property.
         * @param {String} propertyType {'STRING','INTEGER', 'BOOLEAN', 'DATE', 'FLOAT', 'CHAR'}
         * @param {Boolean} isRequired - is the property required
         *
         * @return {ngProperty/genericViewModelProperty}
         */
        exports.createViewModelProperty = function( displayName, propertyType, passedIsRequired, passedIsEditable,
            passedDbValue, passedDisplValue, propLabelPosition ) {

            var propName = displayName;
            var type = propertyType;
            var hasLov = false;
            var isArray = false;
            var isAutoAssignable = false;
            var isEditable = true;
            var isEnabled = true;
            var isRequired = false;
            var isLocalizable = false;
            var isNull = false;
            var maxArraySize = -1;
            var maxLength = -1;
            var isRichText = false;
            var displayValues = [];
            var error = "";
            var renderingHint = "";
            var numberOfCharacters = -1;
            var numberOfLines = -1;

            var uw_dbValue = passedDbValue;

            if( !uw_dbValue && type === 'DATE' ) {
                var date = new Date();
                uw_dbValue = date.getTime();

            }

            if( passedIsRequired ) {
                isRequired = passedIsRequired === "true";
            }

            if( passedIsEditable ) {
                isEditable = passedIsEditable === "true";
                isEnabled = isEditable;
            }

            if( passedDisplValue ) {
                displayValues.push( passedDisplValue );
            }

            var viewProp = _vmPropSvc.createViewModelProperty( propName, displayName, type, uw_dbValue, displayValues );
            _vmPropSvc.setHasLov( viewProp, hasLov );
            _vmPropSvc.setIsArray( viewProp, isArray );
            _vmPropSvc.setIsAutoAssignable( viewProp, isAutoAssignable );
            _vmPropSvc.setIsEditable( viewProp, isEditable );
            _vmPropSvc.setIsRichText( viewProp, isRichText );
            _vmPropSvc.setIsEnabled( viewProp, isEnabled );
            _vmPropSvc.setIsLocalizable( viewProp, isLocalizable );
            _vmPropSvc.setIsNull( viewProp, isNull );
            _vmPropSvc.setIsRequired( viewProp, isRequired );
            _vmPropSvc.setLength( viewProp, maxLength );
            _vmPropSvc.setError( viewProp, error );
            _vmPropSvc.setRenderingHint( viewProp, renderingHint );
            _vmPropSvc.setNumberOfCharacters( viewProp, numberOfCharacters );
            _vmPropSvc.setNumberOfLines( viewProp, numberOfLines );
            _vmPropSvc.setArrayLength( viewProp, maxArraySize );

            if( type === 'DATE' ) {
                viewProp.dateApi = viewProp.dateApi || {};

                viewProp.dateApi.isDateEnabled = true;
                viewProp.dateApi.isTimeEnabled = false;
            }
            if( passedDbValue ) {
                viewProp.dbValues = passedDbValue;
            } else {
                viewProp.dbValues = [];
            }

            if( passedDisplValue ) {
                viewProp.uiValues = displayValues;
            } else {
                viewProp.uiValues = [];
            }

            viewProp.uiValue = viewProp.uiValues.join();

            viewProp.initialize = false;

            if( propLabelPosition && propLabelPosition === "PROPERTY_LABEL_AT_SIDE" ) {
                viewProp.editLayoutSide = true;
            }

            return viewProp;
        };

        /**
         * @param {String[]} preferenceName
         * @return {Promise}
         */
        function getPreferences( preferenceNames ) {
            if( preferenceNames && preferenceNames.length > 0 ) {
                return preferenceService.getMultiStringValues( preferenceNames );
            }
            return;
        }

        /**
         * populateViewModelProperties
         */
        exports.populateViewModelProperties = function( passedVm ) {

            var deferred = _$q.defer();

            var viewModelJson = passedVm;

            if( !viewModelJson ) {
                return;
            }
            _$http.get( viewModelJson ).then( function( jsonData ) {
                exports.data = {};
                exports.jsonDataOrig = _.clone( jsonData, true );

                processViewModel( jsonData );

                exports.actions = jsonData.data.actions;
                exports.functions = jsonData.data.functions;
                exports.messages = jsonData.data.messages;

                //preference
                var promise = getPreferences( jsonData.data.preferences );
                var i18nPromise = _awDuiLocalizationService.populateI18nMap( jsonData.data.i18n );

                _$q.all( [ exports, promise, i18nPromise ] ).then( function( values ) {
                    if( values[1] ) {
                        exports.data.preferences = values[1];
                    }
                    if( values[2] ) {
                        exports.data.i18n = values[2];
                    }

                    updateI18nTexts( exports.data );

                    deferred.resolve( exports.data );
                } );

            } );

            return deferred.promise;
        };

        /**
         * Update localization texts on the properties created based on data section
         *
         * @param {Object} input - Input object.
         */
        var updateI18nTexts = function( input ) {
            _.forEach( input, function( n, key ) {
                if( n ) {
                    if( _.isString( n ) ) {
                        if (_.startsWith( n, "{{i18n." )) {
                            var textPath = getStringBetweenDoubleMustaches( n );
                            var val = _.get( exports.data, textPath );
                            if( val ) {
                                input[key] = val;
                            } else {
                                input[key] = "";
                            }
                        }
                    } else {
                        updateI18nTexts( n );
                    }
                }
            } );
        };

        exports.updateViewModel = function( dataObject ) {

            var jsonData = _.clone( exports.jsonDataOrig, true );

            // Store the i18n strings
            var i18n = exports.data.i18n;

            for( var member in exports.data ) {
                delete exports.data[member];
            }

            // Restore the i18n strings so that they can be replaced on the view model
            if( i18n ) {
                exports.data.i18n = i18n;
            }

            processViewModel( jsonData );

            updateI18nTexts( exports.data );
        };

        var processViewModel = function( jsonData ) {
            initViewModel( jsonData.data.data );

            _.forEach( jsonData.data.data, function( n, key ) {
                if( n ) {
                    exports.data[key] = new exports.createViewModelProperty( n.propDisplayName, n.propType,
                        n.propIsRequired, n.propIsEditable, n.propDbValue, n.propDisplayValue, n.propLabelPosition );

                    //other properties
                    if( n.propType === 'BOOLEAN' && n.propertyRadioTrueText && n.propertyRadioFalseText ) {
                        exports.data[key].propertyRadioTrueText = n.propertyRadioTrueText;
                        exports.data[key].propertyRadioFalseText = n.propertyRadioFalseText;
                    } else if( n.propType === "STRING" ) {
                        if( n.isRichText ) {
                            exports.data[key].isRichText = n.isRichText;
                        }
                        if( n.maxLength ) {
                            exports.data[key].maxLength = n.maxLength;
                        }
                        if( n.numberOfLines ) {
                            exports.data[key].numberOfLines = n.numberOfLines;
                        }
                        if( n.hasLov ) {
                            exports.data[key].hasLov = n.hasLov;
                        }
                        exports.data[key].inputType = "text";
                    }
                }
            } );

        };

        var parentGet = function( input, path ) {
            var retVal = _.get( input, path );

            if( retVal !== undefined ) {
                return retVal;
            } else if( input.$parent ) {
                return parentGet( input.$parent, path );
            }
        };

        var loadDeps = function( depModule ) {
            var deferred = _$q.defer();

            if( depModule && depModule.length > 0 ) {
                requirejs( [ depModule ], function( depModule2 ) {
                    deferred.resolve( depModule2 );
                } );
            } else {
                deferred.resolve();
            }

            return deferred.promise;
        };

        var initViewModel = function( input ) {
            _.forEach( input, function( n, key ) {
                if( _.isString( n ) ) {
                    if( _.startsWith( n, "{{ctx." ) ) {
                        var newVal = _.trimLeft( n, "{{" );
                        newVal = _.trimRight( newVal, "}}" );

                        var val = _.get( _appCtxService, newVal );
                        if( val ) {
                            input[key] = val;
                        } else {
                            input[key] = "";
                        }
                        _appContextList.push( {
                            "name": key,
                            "value": newVal,
                            "input": input
                        } );
                    }
                } else {
                    initViewModel( n );
                }

            } );
        };

        var applyScope = function( input, $scope, deps ) {

            _.forEach( input, function( n, key ) {
                if( _.isString( n ) ) {
                    if( _.startsWith( n, "{{" ) ) {
                        var newVal = _.trimLeft( n, "{{" );
                        newVal = _.trimRight( newVal, "}}" );

                        if( _.startsWith( newVal, 'function:' ) ) {
                            var functionName = newVal.replace( "function:", '' );
                            var funcToCall = exports.functions[functionName];
                            var funcParams = funcToCall.parameters;
                            var i;
                            for( i = 0; i < funcParams.length; i++ ) {
                                var param = funcParams[i];
                                if( _.startsWith( param, "{{" ) ) {
                                    var newParam = _.trimLeft( param, "{{" );
                                    newParam = _.trimRight( newParam, "}}" );
                                    var realizedFuncParam = parentGet( $scope, newParam );
                                }
                            }

                            input[key] = deps[functionName]( realizedFuncParam );

                        } else {
                            var val = parentGet( $scope, newVal );
                            if( val !== undefined ) {
                                input[key] = val;
                            }
                        }
                    }
                } else {
                    applyScope( n, $scope, deps );
                }

            } );

        };

        /**
         * Execute command
         *
         * @param {String} commandString  The name of command action to be executed
         */
        exports.executeCommand = function( commandString, $scope ) {

            var action = exports.actions[commandString];
            if( !action ) {
                return;
            }
            var inputData = _.clone( action.inputData, true );
            var events = action.events;
            var actionMessages = action.actionMessages;
            var allMessages = _.clone( exports.messages, true );

            loadDeps( action.deps ).then(
                function( deps ) {
                    if( !inputData ) {
                        return;
                    }
                    applyScope( inputData, $scope, deps );

                    if( action.policy ) {
                        var actionPolicyId = propertyPolicyService.register( action.policy, action.operationName +
                            "_Policy" );
                    }

                    soaSvc.post( action.serviceName, action.operationName, inputData ).then(
                        function( response ) {

                            if( actionPolicyId ) {
                                propertyPolicyService.unregister( actionPolicyId );
                            }

                            //Process all the action output definition and stick them on the scopes data.
                            if( response && action.outputData ) {
                                _.forEach( action.outputData, function( n, key ) {
                                    if( n ) {
                                        parentGet( $scope, "data" )[key] = getOutput( response, n, deps );
                                    }
                                } );
                            }

                            if( response && events && events.success ) {
                                _.forEach( events.success, function( event, key ) {
                                    if( event ) {
                                        if( event.eventData ) {
                                            app.eventBus.publishSoa( event.name, event.eventData );
                                        } else {
                                            app.eventBus.publishSoa( event.name, {} );
                                        }
                                    }
                                } );
                            }

                            if( response && actionMessages && actionMessages.success ) {
                                _.forEach( actionMessages.success, function( successMessage ) {
                                    var evaluationEnv = {};
                                    evaluationEnv = exports.data;
                                    if( successMessage.condition &&
                                        evaluateCondition( successMessage.condition, evaluationEnv ) ) {
                                        reportNotyMessage( allMessages, successMessage.message, $scope );
                                    }
                                } );
                            }

                        },
                        function( err ) {
                            if( err && events && events.error ) {
                                _.forEach( events.error, function( event, key ) {
                                    if( event ) {
                                        if( event.eventData ) {
                                            app.eventBus.publishSoa( event.name, event.eventData );
                                        } else {
                                            app.eventBus.publishSoa( event.name, {} );
                                        }
                                    }
                                } );
                            } else if( err && actionMessages && actionMessages.failure ) {
                                if( err.cause && err.cause.partialErrors ) {
                                    _.forEach( err.cause.partialErrors, function( partErr, key ) {
                                        if( partErr.errorValues ) {
                                            _.forEach( partErr.errorValues, function( errVal ) {
                                                if( errVal.code ) {
                                                    _
                                                        .forEach( actionMessages.failure,
                                                            function( failureErr ) {
                                                                var evaluationEnv = {};
                                                                evaluationEnv.errorCode = errVal;
                                                                if( failureErr.condition &&
                                                                    evaluateCondition( failureErr.condition,
                                                                        evaluationEnv ) ) {
                                                                    reportNotyMessage( allMessages, failureErr.message,
                                                                        $scope );
                                                                }
                                                            } );
                                                }
                                            } );
                                        }
                                    } );
                                }
                            }
                        } );

                } );
        };

        /**
         * Report a message using 'NotyJS' API.
         *
         * @param {Object} messageList - Structure containing action messages.
         * @param {String} notyMessage - The action message.
         * @param {Object} parentScope - The scope of the parent
         */
        var reportNotyMessage = function( messageList, notyMessage, parentScope ) {
            var messageDefn = _.get( messageList, notyMessage );
            if( messageDefn && messageDefn.messageType ) {
                if( messageDefn.messageType === 'INFO' ) {
                    var localizedMessage = getLocalizedTextForInterpolationString( messageDefn.messageText );
                    localizedMessage = applyMessageParams( localizedMessage, messageDefn.messageTextParams, exports );
                    _panelNotyService.showInfo( localizedMessage );
                } else if( messageDefn.messageType === 'WARNING' ) {
                    var buttonsArr = [];
                    if( messageDefn.navigationOptions ) {
                        _.forEach( messageDefn.navigationOptions, function( navOption ) {
                            var button = {};

                            button.addClass = 'btn btn-notify';

                            button.text = getLocalizedTextForInterpolationString( navOption.text );
                            button.onClick = function( $noty ) {
                                $noty.close();
                                if( navOption.action ) {
                                    exports.executeCommand( navOption.action, parentScope );
                                }
                            };
                            buttonsArr.push( button );
                        } );
                    }
                    var localizedMessage = getLocalizedTextForInterpolationString( messageDefn.messageText );
                    localizedMessage = applyMessageParams( localizedMessage, messageDefn.messageTextParams, exports );
                    _panelNotyService.showWarning( localizedMessage, buttonsArr );
                }
            }
        };

        /**
         * Get localized text
         *
         * @param {String} interpolationString - The string to search.
         */
        var getLocalizedTextForInterpolationString = function( interpolationString ) {
            var textPath = getStringBetweenDoubleMustaches( interpolationString );
            return _.get( exports.data, textPath );
        };

        /**
         * Evaluate message with its parameters
         */
        var applyMessageParams = function( messageString, messagePramas, messageContext ) {
            var placeHolders = messageString.match( /{[0-9]*}/g );
            var resultString = messageString;
            if( placeHolders ) {
                for( var i in placeHolders ) {
                    var placeHolder = placeHolders[i];
                    var key = getStringBetweenDoubleMustaches( messagePramas[i] );
                    var replacementString = _.get( messageContext, key );
                    resultString = resultString.replace( placeHolder, replacementString );
                }
            }
            return resultString;
        };

        /**
         * @param expression expression {note: currently supporting ==,&&}
         * @param evaluationEnv
         * @return result
         */
        var evaluateCondition = function( expression, evaluationEnv ) {
            var operators = /==|&&/;
            var operands = expression.split( operators );
            var resultExpression = expression;
            for( var x in operands ) {
                var operand = operands[x];
                var value = _.get( evaluationEnv, operand.trim() );
                if( !value ) {
                    value = operand.trim();
                }
                resultExpression = resultExpression.replace( operand, value );
            }

            return _$parse( resultExpression )();
        };

        /**
         * @param {Object} response object
         * @param {Object[]} deps
         * @param {String} expression to parse e.g. "{{function:processTemplates}}"
         *            "{{templatesOutput[0].workflowTemplates}}"
         */
        var getOutput = function( response, inputExpression, deps ) {
            var expression = getStringBetweenDoubleMustaches( inputExpression );
            if( _.startsWith( expression, 'function:' ) ) {
                var functionName = expression.replace( 'function:', '' );
                //evaluate function
                return deps[functionName]( response );
            }
            return _.get( response, inputExpression );
        };

        /**
         * @param {String} expression
         * @return the string between mustaches
         */
        var getStringBetweenDoubleMustaches = function( expression ) {
            var insertionString = expression;
            if( _.isString( insertionString ) ) {
                if( _.startsWith( insertionString, "{{" ) ) {
                    insertionString = _.trimLeft( insertionString, "{{" );
                    insertionString = _.trimRight( insertionString, "}}" );
                }
                return insertionString;
            }
            return;
        };

        /**
         * Return ViewModelObject for the given path
         *
         * @param {String} path
         */
        exports.getViewModelObject = function( path ) {
            return _.get( exports.data, path );
        };

        /**
         * Register this service with the AngularJS application.
         */
        app.factory( 'panelViewModelService', [
            '$http',
            '$q',
            '$injector',
            'appCtxService',
            'awDuiLocalizationService',
            'notyService',
            'genericViewModelProperty',
            '$parse',
            function( $http, $q, $injector, appCtxService, awDuiLocalizationService, panelNotyService,
                genericViewModelProperty, $parse ) {
                _$http = $http;
                _$q = $q;
                _$injector = $injector;
                _appCtxService = appCtxService;
                _awDuiLocalizationService = awDuiLocalizationService;
                _panelNotyService = panelNotyService;
                _vmPropSvc = genericViewModelProperty;
                _$parse = $parse;
                return exports;
            } ] );

        return exports;
    } );