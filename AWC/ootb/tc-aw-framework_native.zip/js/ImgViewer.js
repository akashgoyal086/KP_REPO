//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

define( [], function() {
    'use strict';
    //==================================================
    // private variables
    //==================================================
    /** The view param */
    var vp = {
        scale: 1,
        x: 0,
        y: 0
    };
    /** The view param at the end of animation */
    var vpEnd = {
        scale: 1,
        x: 0,
        y: 0
    };
    /** The view param to fit the image */
    var vpFit = {
        scale: 1,
        x: 0,
        y: 0
    };

    /** The development environment, set to ture for debugging */
    var devEnv = false;
    /** The option to fix window, set to false to fix the viewport */
    var fixWindow = true;

    /** The maximum scale */
    var scaleMax = 4;
    /** The minimum scale */
    var scaleMin = 0.01;
    /** The pan is on */
    var panOn = false;
    /** The pinch zoom is on */
    var pinchOn = false;
    /** The pinch zoom factor */
    var pinchF = 1;
    /** The event x coord */
    var eventX = 0;
    /** The event y scale */
    var eventY = 0;
    /** The x coord of the mid point between two fingers */
    var midX = 0;
    /** The y coord of the mid point between two fingers */
    var midY = 0;
    /** The remaining steps for animation */
    var nStep = 1;
    /** The maximum steps for animation */
    var nMax = 10;

    /** The container for the canvas */
    var container = null;
    /** The image */
    var img = null;
    /** The message to be displayed */
    var msg = null;
    /** The canvas to draw the image */
    var canvas = null;
    /** The context to draw the image */
    var ctx = null;

    /** The canvas rectangle */
    var canvasRect = {
        left: 0,
        top: 0,
        width: 100,
        height: 100
    };
    /** The image rectangle */
    var imgRect = {
        left: 0,
        top: 0,
        width: 100,
        height: 100
    };

    /** The view param change callback */
    var viewParamChangeCallback = null;
    /** The mouse/touch/pointer change callback */
    var pointChangeCallback = null;
    /** The resize callback */
    var resizeCallback = null;
    /** The timer for double tap */
    var tapped = null;

    //==================================================
    // public functions
    //==================================================
    /**
     * Initialize this module
     *
     * @param {Element} viewerContainer - The viewer container
     */
    function init( viewerContainer ) {
        var doc = viewerContainer.ownerDocument;
        container = viewerContainer;

        if( !container.children["ImageViewerCanvas"] ) {
            canvas = doc.createElement( "canvas" );
            container.appendChild( canvas );
            ctx = canvas.getContext( "2d" );

            canvas.id = "ImageViewerCanvas";
            setCanvasRect();
            canvas.style["touch-action"] = "none";

            vp.scale = scaleMin;
            vp.x = canvas.width / 2;
            vp.y = canvas.height / 2;

            if( window.navigator.pointerEnabled ) {
                canvas.addEventListener( "pointerdown", pointerStart );
                canvas.addEventListener( "pointermove", pointerMove );
                canvas.addEventListener( "pointerup", pointerStop );
                canvas.addEventListener( "pointerout", pointerStop );
            } else {
                canvas.addEventListener( "mousedown", panStart );
                canvas.addEventListener( "mousemove", panMove );
                canvas.addEventListener( "mouseup", panStop );
                canvas.addEventListener( "mouseout", panStop );
                canvas.addEventListener( "click", clickOnCanvas );
            }

            canvas.addEventListener( "dblclick", panZoom );
            canvas.addEventListener( "mousewheel", wheelZoom );
            canvas.addEventListener( "DOMMouseScroll", wheelZoom );

            canvas.addEventListener( "touchstart", touchStart );
            canvas.addEventListener( "touchmove", touchMove );
            canvas.addEventListener( "touchend", touchEnd );
            canvas.addEventListener( "touchcancel", touchEnd );
        }

        // For debugging in the development environment, set devEnv to true and use Chrome browser only.
        // Developer may choose the option Fix Window or Fix Viewport, and see the parameters on screen.
        if( devEnv && navigator.userAgent.match( /chrome/i ) && !container.children["ImageViewerOption"] ) {
            var devOption = doc.createElement( "form" );
            var fixWindow = doc.createElement( "input" );
            fixWindow.type = "radio";
            fixWindow.name = "devOption";
            fixWindow.checked = "checked";

            /**
             */
            fixWindow.onclick = function() {
                setOption( true );
            };

            var fixViewport = doc.createElement( "input" );
            fixViewport.type = "radio";
            fixViewport.name = "devOption";

            /**
             */
            fixViewport.onclick = function() {
                setOption( false );
            };

            var fixWindowLable = doc.createElement( "lable" );
            fixWindowLable.innerHTML = "<small>Fix Window</small>";
            var fixViewportLable = doc.createElement( "lable" );
            fixViewportLable.innerHTML = "<small>Fix Viewport</small>";

            devOption.appendChild( fixWindow );
            devOption.appendChild( fixWindowLable );
            devOption.appendChild( fixViewport );
            devOption.appendChild( fixViewportLable );

            msg = doc.createElement( "div" );
            devOption.appendChild( msg );

            devOption.id = "ImageViewerOption";
            devOption.style.position = "absolute";
            devOption.style.left = canvasRect.left + 10 + "px";
            devOption.style.top = canvasRect.top + 10 + "px";
            container.appendChild( devOption );
        }
    }

    /**
     * Resize handler
     */
    function resize() {
        if( container && canvas && img ) {
            setVpFit();
            if( resizeCallback ) {
                resizeCallback();
            }
            fitViewParam( vp, vpEnd );
            animate();
        }
    }

    /**
     * Set the image
     *
     * @param {String} url - The image url
     */
    function setImage( url ) {
        img = new Image();
        img.src = url;
        img.onload = fit;
    }

    /**
     * Set the View Param
     *
     * @param {ViewParam} viewParam - The view param
     */
    function setViewParam( viewParam ) {
        copyViewParam( viewParam, vpEnd );
        animate();
    }

    //==================================================
    // private functions
    //==================================================
    /**
     * Set the Canvas Rectangle
     *
     */
    function setCanvasRect() {
        var docRect = container.ownerDocument.documentElement.getBoundingClientRect();
        var containerRect = container.getBoundingClientRect();

        canvasRect.width = containerRect.width;
        canvasRect.height = containerRect.height;
        canvasRect.left = containerRect.left - docRect.left;
        canvasRect.top = containerRect.top - docRect.top;

        canvas.width = canvasRect.width;
        canvas.height = canvasRect.height;
        canvas.style.left = "0px";
        canvas.style.top = "0px";
        canvas.style.position = "absolute";
    }

    /**
     * Draw the image on canvas
     *
     */
    function draw() {
        if( canvas && ctx ) {
            ctx.clearRect( 0, 0, canvas.width, canvas.height );
            var sx = 0;
            var sy = 0;
            var sw = img.naturalWidth;
            var sh = img.naturalHeight;
            var dx = vp.x;
            var dy = vp.y;
            var dw = img.naturalWidth * vp.scale;
            var dh = img.naturalHeight * vp.scale;

            if( !fixWindow ) {
                sx = -vp.x / vp.scale;
                sy = -vp.y / vp.scale;
                sw = canvas.width / vp.scale;
                sh = canvas.height / vp.scale;
                dx = 0;
                dy = 0;
                dw = canvas.width;
                dh = canvas.height;
            }

            ctx.drawImage( img, sx, sy, sw, sh, dx, dy, dw, dh );
            if( viewParamChangeCallback ) {
                viewParamChangeCallback( vp );
            }

            if( msg ) {
                msg.innerHTML = "<small>View Param = (" + vp.scale.toFixed( 3 ) + ", " + vp.x.toFixed( 3 ) + ", " +
                        vp.y.toFixed( 3 ) + ")<br/>" + "Window = (" + sx.toFixed( 3 ) + ", " + sy.toFixed( 3 ) + ", " +
                        sw.toFixed( 3 ) + ", " + sh.toFixed( 3 ) + ")<br/>" + "Viewport = (" + dx.toFixed( 3 ) + ", " +
                        dy.toFixed( 3 ) + ", " + dw.toFixed( 3 ) + ", " + dh.toFixed( 3 ) + ")</small>";
            }
        }
    }

    /**
     * Set the option
     *
     * @param {Boolean} option - True means fix window, false means fix viewport
     */
    function setOption( option ) {
        fixWindow = option;
        draw();
    }

    /**
     * Fit the image
     */
    function setVpFit() {
        setCanvasRect();
        imgRect.width = img.naturalWidth;
        imgRect.height = img.naturalHeight;

        vpFit.scale = Math.max( Math.min( canvasRect.width / imgRect.width, canvasRect.height / imgRect.height, 1 ),
                scaleMin );
        vpFit.x = canvasRect.width / 2 - vpFit.scale * imgRect.width / 2;
        vpFit.y = canvasRect.height / 2 - vpFit.scale * imgRect.height / 2;
    }

    /**
     */
    function fit() {
        setVpFit();
        copyViewParam( vpFit, vpEnd );
        animate();
    }

    /**
     * Transform the view param to vpEnd for animation
     *
     * @param {Number} s - the scale
     * @param {Number} xp - the x coordinate of the point P
     * @param {Number} yp - the y coordinate of the point P
     * @param {Number} xq - the x coordinate of the point Q
     * @param {Number} yq - the y coordinate of the point Q
     */
    function transformViewParam( s, xp, yp, xq, yq ) {
        xp = xp || canvasRect.width / 2;
        yp = yp || canvasRect.height / 2;
        xq = xq || canvasRect.width / 2;
        yq = yq || canvasRect.height / 2;

        vpEnd.scale = Math.min( Math.max( s, scaleMin ), scaleMax );
        vpEnd.x = xq - ( vpEnd.scale / vp.scale ) * ( xp - vp.x );
        vpEnd.y = yq - ( vpEnd.scale / vp.scale ) * ( yp - vp.y );
    }

    /**
     * Fit the view param
     *
     * @param {ViewParam} from - The source view param
     * @param {ViewParam} to - The destination view param
     * @return {Boolean} The view param is adjusted
     */
    function fitViewParam( from, to ) {
        if( from.scale < vpFit.scale ) {
            copyViewParam( vpFit, to );
            return true;
        }

        var sDiff = vpFit.scale - from.scale;
        to.x = Math.max( Math.min( vpFit.x, from.x ), vpFit.x + sDiff * imgRect.width );
        to.y = Math.max( Math.min( vpFit.y, from.y ), vpFit.y + sDiff * imgRect.height );
        to.scale = from.scale;
        return ( to.x !== from.x || to.y !== from.y );
    }

    /**
     * Copy the view param
     *
     * @param {ViewParam} from - The source view param
     * @param {ViewParam} to - The destination view param
     */
    function copyViewParam( from, to ) {
        to.scale = from.scale;
        to.x = from.x;
        to.y = from.y;
    }

    /**
     * Test if the two view params are the same
     *
     * @param {ViewParam} first - The first view param
     * @param {ViewParam} second - The second view param
     * @return {Boolean} True means the two view params are the same
     */
    function sameViewParam( first, second ) {
        return ( first.scale === second.scale && first.x === second.x && first.y === second.y );
    }

    /**
     * Clear the user selection
     */
    function clearUserSelection() {
        if( window.getSelection() ) {
            window.getSelection().removeAllRanges();
        }
    }

    /**
     * Do the zoom
     *
     * @param {Number} f - the zoom factor
     */
    function zoom( f ) {
        transformViewParam( f * vp.scale );
        fitViewParam( vpEnd, vpEnd );
        animate();
    }

    /**
     * Do the pan and zoom together
     *
     * @param {Object} e - the event
     */
    function panZoom( e ) {
        e = e || window.event;
        var x = e.offsetX || e.layerX;
        var y = e.offsetY || e.layerY;

        e.stopPropagation();
        e.preventDefault();
        clearUserSelection();

        if( sameViewParam( vp, vpFit ) ) {
            transformViewParam( 1, x, y, x, y );
            fitViewParam( vpEnd, vpEnd );
            animate();
        } else {
            fit();
        }
    }

    /**
     * Do the wheel zoom
     *
     * @param {Object} e - the event
     */
    function wheelZoom( e ) {
        e = e || window.event;
        var delta = ( e.wheelDelta ? e.wheelDelta / 120 : e.detail ? -e.detail / 3 : 0 );

        e.preventDefault();
        transformViewParam( Math.pow( 1.1, delta ) * vp.scale );
        fitViewParam( vpEnd, vp );
        draw();
    }

    /**
     * Animate for vp to vpEnd
     */
    function animate() {
        if( sameViewParam( vpEnd, vp ) ) {
            draw();
        } else {
            var dx = Math.abs( vpEnd.x - vp.x ) * 0.02;
            var dy = Math.abs( vpEnd.y - vp.y ) * 0.02;
            var ds = Math.abs( vpEnd.scale - vp.scale ) * 20;
            nStep = Math.floor( Math.min( nMax, Math.max( dx, dy, ds, 1 ) ) );
            animation();
        }
    }

    /**
     * Do one step of the animation
     */
    function animation() {
        if( nStep <= 1 ) {
            copyViewParam( vpEnd, vp );
            draw();
        } else {
            vp.scale += ( vpEnd.scale - vp.scale ) / nStep;
            vp.x += ( vpEnd.x - vp.x ) / nStep;
            vp.y += ( vpEnd.y - vp.y ) / nStep;
            nStep--;
            draw();
            if( window.requestAnimationFrame ) {
                window.requestAnimationFrame( animation );
            } else {
                window.setTimeout( animation, 16 );
            }
        }
    }

    /**
     * Pan start event handler
     *
     * @param {Object} e - the event
     */
    function panStart( e ) {
        e = e || window.event;
        panOn = true;
        eventX = e.offsetX || e.layerX;
        eventY = e.offsetY || e.layerY;
    }

    /**
     * Pan move event handler
     *
     * @param {Object} e - the event
     */
    function panMove( e ) {
        e = e || window.event;
        var x = e.offsetX || e.layerX;
        var y = e.offsetY || e.layerY;

        if( panOn ) {
            vp.x += x - eventX;
            vp.y += y - eventY;
            draw();
            eventX = x;
            eventY = y;
        } else {
            if( pointChangeCallback ) {
                pointChangeCallback( x, y, "mousemove" );
            }
        }
    }

    /**
     * Pan stop event handler
     */
    function panStop() {
        if( panOn && fitViewParam( vp, vpEnd ) ) {
            animate();
        }
        panOn = false;
    }

    /**
     * Click on canvas event handler
     *
     * @param {Object} e - the event
     */
    function clickOnCanvas( e ) {
        e = e || window.event;
        var x = e.offsetX || e.layerX;
        var y = e.offsetY || e.layerY;
        if( pointChangeCallback ) {
            pointChangeCallback( x, y, "click" );
        }
    }

    /**
     * Touch start event handler
     *
     * @param {Object} e - the event
     */
    function touchStart( e ) {
        e = e || window.event;
        e.preventDefault();

        if( e.touches.length === 1 ) {
            if( !tapped ) {
                tapped = window.setTimeout( function() {
                    tapped = null;
                }, 300 );
                panOn = true;
                pinchOn = false;
                eventX = e.touches[0].pageX - canvasRect.left;
                eventY = e.touches[0].pageY - canvasRect.top;
            } else {
                window.clearTimeout( tapped );
                tapped = null;
                panZoom( e );
            }
        } else if( e.touches.length === 2 ) {
            pinchOn = true;
            panOn = false;
            var x0 = e.touches[0].pageX - canvasRect.left;
            var y0 = e.touches[0].pageY - canvasRect.top;
            var x1 = e.touches[1].pageX - canvasRect.left;
            var y1 = e.touches[1].pageY - canvasRect.top;

            eventX = x0;
            eventY = y0;
            midX = ( x0 + x1 ) / 2;
            midY = ( y0 + y1 ) / 2;
            pinchF = vp.scale / Math.sqrt( ( x0 - x1 ) * ( x0 - x1 ) + ( y0 - y1 ) * ( y0 - y1 ) );
        }
    }

    /**
     * Touch move event handler
     *
     * @param {Object} e - the event
     */
    function touchMove( e ) {
        e = e || window.event;
        e.preventDefault();

        if( e.touches.length === 1 ) {
            var x = e.touches[0].pageX - canvasRect.left;
            var y = e.touches[0].pageY - canvasRect.top;

            if( panOn ) {
                vp.x += x - eventX;
                vp.y += y - eventY;
                draw();
            } else {
                panOn = true;
                pinchOn = false;
            }

            eventX = x;
            eventY = y;
        } else if( e.touches.length === 2 ) {
            var x0 = e.touches[0].pageX - canvasRect.left;
            var y0 = e.touches[0].pageY - canvasRect.top;
            var x1 = e.touches[1].pageX - canvasRect.left;
            var y1 = e.touches[1].pageY - canvasRect.top;
            var dist = Math.sqrt( ( x0 - x1 ) * ( x0 - x1 ) + ( y0 - y1 ) * ( y0 - y1 ) );

            if( pinchOn ) {
                transformViewParam( pinchF * dist, midX, midY, midX, midY );
                copyViewParam( vpEnd, vp );
                draw();
            } else {
                pinchOn = true;
                panOn = false;
                midX = ( x0 + x1 ) / 2;
                midY = ( y0 + y1 ) / 2;
                pinchF = vp.scale / dist;
            }

            eventX = x0;
            eventY = y0;
        }
    }

    /**
     * Touch end event handler
     *
     * @param {Object} e - the event
     */
    function touchEnd( e ) {
        e = e || window.event;
        e.preventDefault();

        if( panOn || pinchOn ) {
            if( fitViewParam( vp, vpEnd ) ) {
                animate();
            }

            if( panOn && pointChangeCallback ) {
                pointChangeCallback( eventX, eventY, "touchend" );
            }
        }

        panOn = false;
        pinchOn = false;
    }

    /**
     * Pointer start event handler
     *
     * @param {Object} e - the event
     */
    function pointerStart( e ) {
        e = e || window.event;
        if( e.pointerType !== "touch" ) {
            return panStart( e );
        }

        e.preventDefault();
        if( e.isPrimary ) {
            panOn = true;
            pinchOn = false;
            eventX = e.offsetX;
            eventY = e.offsetY;
        } else {
            pinchOn = true;
            panOn = false;
            var x0 = e.offsetX;
            var y0 = e.offsetY;
            var x1 = eventX;
            var y1 = eventY;

            midX = ( x0 + x1 ) / 2;
            midY = ( y0 + y1 ) / 2;
            pinchF = vp.scale / Math.sqrt( ( x0 - x1 ) * ( x0 - x1 ) + ( y0 - y1 ) * ( y0 - y1 ) );
        }
    }

    /**
     * Pointer move event handler
     *
     * @param {Object} e - the event
     */
    function pointerMove( e ) {
        e = e || window.event;
        if( e.pointerType !== "touch" ) {
            return panMove( e );
        }

        e.preventDefault();
        if( e.isPrimary ) {
            var x = e.offsetX;
            var y = e.offsetY;

            if( panOn ) {
                vp.x += x - eventX;
                vp.y += y - eventY;
                draw();
            }

            eventX = x;
            eventY = y;
        } else if( pinchOn ) {
            var x0 = e.offsetX;
            var y0 = e.offsetY;
            var x1 = eventX;
            var y1 = eventY;
            var dist = Math.sqrt( ( x0 - x1 ) * ( x0 - x1 ) + ( y0 - y1 ) * ( y0 - y1 ) );

            transformViewParam( pinchF * dist, midX, midY, midX, midY );
            copyViewParam( vpEnd, vp );
            draw();
        }
    }

    /**
     * Pointer end event handler
     *
     * @param {Object} e - the event
     */
    function pointerStop( e ) {
        e = e || window.event;
        e.preventDefault();

        if( panOn || pinchOn ) {
            var x = e.offsetX;
            var y = e.offsetY;
            var type = ( e.pointerType === "touch" ? "touchend" : "click" );

            if( fitViewParam( vp, vpEnd ) ) {
                animate();
            }

            if( panOn && pointChangeCallback ) {
                pointChangeCallback( x, y, type );
            }
        }

        panOn = false;
        pinchOn = false;
    }

    //==================================================
    // exported functions
    //==================================================
    var exports = {
        init: init,
        fit: fit,
        resize: resize,
        setImage: setImage,
        refresh: draw,
        /**
         */
        getContainer: function() {
            return container;
        },
        /**
         */
        getCanvas: function() {
            return canvas;
        },
        /**
         */
        getImage: function() {
            return img;
        },
        /**
         */
        getViewParam: function() {
            return vp;
        },
        /**
         */
        getFitViewParam: function() {
            return vpFit;
        },
        setViewParam: setViewParam,
        /**
         */
        setViewParamChangeCallback: function( callback ) {
            viewParamChangeCallback = callback;
        },
        /**
         */
        setPointChangeCallback: function( callback ) {
            pointChangeCallback = callback;
        },
        /**
         */
        setResizeCallback: function( callback ) {
            resizeCallback = callback;
        },
        /**
         */
        setDevEnv: function( b ) {
            devEnv = b;
        }
    };

    return exports;
} );
