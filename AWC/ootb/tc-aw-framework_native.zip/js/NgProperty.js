//@<COPYRIGHT>@
//==================================================
//Copyright 2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 document,
 awInclude,
 requirejs,
 CKEDITOR
 */

/**
 * @module js/NgProperty
 * the require define formatting is tied to the karma test script, don't change the format!
 */
define([ 'app', 'angular', 'jquery', 'js/iconService', 'js/dateTimeService', 'js/NgListService', 'js/NgI18n', 'js/localeService',
        'js/NgValidationService', 'js/NgPropertyDateTime', 'js/NgPropertyError', 'js/NgPropertyLov',
        'js/NgPropertyValidator','js/NgUtil', 'js/NgMaxRowService' ],
    function( app, ngModule, $,  iconService ) {
        'use strict';

        var exports = {};
        var _kcEnter = 13;

        /**
         * Defines the property controller
         *
         * @constructor awPropertyController
         *
         * @memberof NgControllers
         *
         * @param {Object} $scope - The 'scope' all controller level values are defined on.
         * @param {AngularService} $timeout -
         * @param {DOMElement} $element
         * @param {localeService} localeService -
         *
         * @return {Void}
         */
        app.controller( 'awPropertyController', [ '$scope', '$timeout', '$element', 'localeService',
            function( $scope, $timeout, $element, localeService ) {
                var self = this;

                /**
                 * @memberof NgControllers.awPropertyController
                 *
                 * @param {PropertyObject} prop - The {PropertyObject} to set as the basis for this NgProperty.
                 *
                 * @return {Void}
                 */
                self.setData = function( prop ) {
                    $scope.$evalAsync( function() {
                        /**
                         * Set the given data object as the primary property object.
                         */
                        $scope.prop = prop;

                        if( $scope.prop.type === "BOOLEAN" || $scope.prop.type === "BOOLEANARRAY" ) {
                            localeService.getTextPromise().then( function( localTextBundle ) {
                                $scope.prop.propertyRadioTrueText = localTextBundle.RADIO_TRUE;
                                $scope.prop.propertyRadioFalseText = localTextBundle.RADIO_FALSE;

                                /**
                                 * Handles setting of custom labels and vertical alignment attributes when directives
                                 * are used natively
                                 */
                                if( $scope.prop.radioBtnApi && $scope.prop.radioBtnApi.customTrueLabel ) {
                                    $scope.prop.propertyRadioTrueText = $scope.prop.radioBtnApi.customTrueLabel;
                                }

                                if( $scope.prop.radioBtnApi && $scope.prop.radioBtnApi.customFalseLabel ) {
                                    $scope.prop.propertyRadioFalseText = $scope.prop.radioBtnApi.customFalseLabel;
                                }

                                if( $scope.prop.radioBtnApi && $scope.prop.radioBtnApi.vertical ) {
                                    $scope.prop.vertical = $scope.prop.radioBtnApi.vertical;
                                }
                            } );
                        }

                        if( $scope.prop.type === "STRING" || $scope.prop.type === "STRINGARRAY" ) {
                            $scope.prop.inputType = "text";
                        }

                    } ); // evalAsync

                    // scope initialization time.  Fire the creation notification scope event.
                    $scope.$emit( "AWUnvWCreated", $element );
                }; // setData



                $scope.$on( '$destroy', function() {
                    /**
                     * *** Important Debug Output *** Please keep this block (even if it's commented out)
                     */
                    // if (app.isDebugEnabled) {
                    // if ($scope.prop) {
                    // console.log('awPropertyController: Destroy $scope=' + //
                    // $scope.$id + ' type=' + $scope.prop.type);
                    // } else {
                    // console.log('awPropertyController: Destroy $scope=' + //
                    // $scope.$id + ' type=' + 'no prop');
                    // }
                    // }
                    // Destroying all watch listeners
                    if( $scope.parseUrlListener ) {
                        $scope.parseUrlListener();
                    }
                    if( $scope.widgetInitializeListener ) {
                        $scope.widgetInitializeListener();
                    }
                    if( $scope.editStateListener ) {
                        $scope.editStateListener();
                    }

                    // Destroying all timeouts
                    if( $scope.nonEditArrayTimer ) {
                        $timeout.cancel( $scope.nonEditArrayTimer );
                    }
                    if( $scope.editArrayTimer ) {
                        $timeout.cancel( $scope.editArrayTimer );
                    }

                    if( $element.remove ) {
                        $element.remove();
                    }
                } ); // $destroy
            }
        ] ); // awPropertyController

        /**
         * Definition for the (aw-property-string) directive
         *
         * @member aw-property-string
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyString', function() {
            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwString.html'
            };
        } );

        /**
         * Definition for the (aw-property-numeric) directive
         *
         * @member aw-property-numeric
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyNumeric', function() {
            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwNumeric.html'
            };
        } );

        /**
         * Definition for the (aw-property-text-box-val) directive.
         *
         * @member aw-property-text-box-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyTextBoxVal', function() {
            function Controller( $scope ) {
                var uiProperty = $scope.prop;

                /**
                 * Bound via 'ng-change' on the 'input' element and called on value change.
                 *
                 * @memberof TextBoxValController
                 */
                $scope.changeFunction = function() {
                    if( !$scope.prop.isArray ) {
                        // this is needed for test harness
                        uiProperty.dbValues = [ uiProperty.dbValue ];
                        app.vmPropSvc.updateViewModelProperty( uiProperty );
                    }
                };

                /**
                 * Bound via 'ng-keydown' on the 'input' element and called on key down on 'input'
                 *
                 * @memberof TextBoxValController
                 */
                $scope.evalKey = function( $event ) {
                    if( $event.keyCode === _kcEnter ) {
                        if( uiProperty.isArray ) {
                            uiProperty.updateArray( $event );
                            $event.preventDefault();
                        }
                    }
                };

                /**
                 * Bound via 'ng-blur' on the 'input' element and called on called on input 'blur' (i.e. they leave the field)
                 *
                 * @memberof TextBoxValController
                 */
                $scope.blurTextBoxFunction = function( $event ) {
                    if( uiProperty.isArray ) {
                        uiProperty.updateArray( $event );
                    }
                };
            }

            Controller.$inject = [ '$scope' ];

            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                controller: Controller,
                templateUrl: app.getBaseUrlPath() + '/html/NgAwTextBoxVal.html'
            };
        } );

        /**
         * Definition for the (aw-property-text-area-val) directive.
         *
         * @member aw-property-text-area-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyTextAreaVal', function() {
            function Controller( $scope ) {
                var uiProperty = $scope.prop;

                /**
                 * Bound via 'ng-change' on the 'textarea' element and called on value change.
                 *
                 * @memberof TextAreaValController
                 */
                $scope.changeFunction = function() {
                    if( !$scope.prop.isArray ) {
                        // this is needed for test harness
                        uiProperty.dbValues = [ uiProperty.dbValue ];
                        app.vmPropSvc.updateViewModelProperty( uiProperty );
                    }
                };

                /**
                 * Bound via 'ng-keydown' on the 'textarea' element and called on key down on 'textarea'
                 *
                 * @memberof TextAreaValController
                 */
                $scope.evalKey = function( $event ) {
                    if( $event.keyCode === _kcEnter ) {
                        // For 'textarea' enter new line on 'ShiftKey + Enter' and 'AltKey + Enter'
                        if( !$event.shiftKey && !$event.altKey ) {
                            // Enter key should prevent default behavior and
                            // add value to the list if it is an array.
                            if( uiProperty.isArray ) {
                                uiProperty.updateArray( $event );
                            }
                            $event.preventDefault();
                        }

                        // To support new line character for 'AltKey + Enter'
                        if( $event.altKey ) {
                            $scope.prop.dbValue += '\n';
                        }
                    }
                };

                /**
                 * Bound via 'ng-blur' on the 'textarea' element and called on called on textarea 'blur' (i.e. they leave the field)
                 *
                 * @memberof TextAreaValController
                 */
                $scope.blurTextAreaFunction = function( $event ) {
                    if( uiProperty.isArray ) {
                        uiProperty.updateArray( $event );
                    }
                };
            }

            Controller.$inject = [ '$scope' ];

            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                controller: Controller,
                templateUrl: app.getBaseUrlPath() + '/html/NgAwTextAreaVal.html'
            };
        } );

        /**
         * Definition for the (aw-property-rich-text-area-val) directive.
         *
         * @member aw-property-rich-text-area-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyRichTextAreaVal', ['UtilsService', function( UtilsService ) {
            function Controller( $scope ) {
                $scope.changeFunction = function() {
                    if( !$scope.prop.isArray ) {
                        var uiProperty = $scope.prop;
                        // this is needed for test harness
                        uiProperty.dbValues = [ uiProperty.dbValue ];
                        app.vmPropSvc.updateViewModelProperty( uiProperty );
                    }
                };
            }

            Controller.$inject = [ '$scope' ];

            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                controller: Controller,
                link: function( scope, element, attrs ) {
                    requirejs( [ "ckeditor" ],
                        function( ckeditor ) {
                            var config, updateModel, setupEditor;
                            var editor = null;
                            var inTable = false;
                            var cellRendered = false;
                            var tableElem = $( element ).closest( '.dataGridCell' );
                            var formElem = $( element ).closest( '.aw-base-scrollPanel' );
                            if( formElem.length === 0 || tableElem.length === 1 ) {
                                inTable = true;
                            }
                            if( ( formElem.length === 1 && tableElem.length === 1 ) ) {
                                cellRendered = true;
                            }
                            // CKEditor configuration
                            if( inTable ) {
                                config = {
                                    toolbar: [ {
                                        name: 'clipboard',
                                        groups: [ 'undo' ],
                                        items: [ 'Undo', 'Redo' ]
                                    }, {
                                        name: 'basicstyles',
                                        groups: [ 'basicstyles', 'cleanup' ],
                                        items: [ 'Bold', 'Italic', 'Underline', 'Strike', 'Subscript',
                                            'Superscript', '-', 'RemoveFormat'
                                        ]
                                    }, {
                                        name: 'paragraph',
                                        groups: [ 'list', 'indent', 'blocks', 'align', 'bidi' ],
                                        items: [ 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent' ]
                                    }, '/', {
                                        name: 'styles',
                                        items: [ 'Styles', 'Format', 'Font', 'FontSize' ]
                                    }, {
                                        name: 'colors',
                                        items: [ 'TextColor', 'BGColor' ]
                                    } ],
                                    startupFocus: false
                                };
                            } else {
                                config = {
                                    toolbarGroups: [ {
                                        name: 'clipboard',
                                        groups: [ 'clipboard', 'undo' ]
                                    }, {
                                        name: 'editing',
                                        groups: [ 'find' ]
                                    }, '/', {
                                        name: 'basicstyles',
                                        groups: [ 'basicstyles', 'cleanup' ]
                                    }, '/', {
                                        name: 'paragraph',
                                        groups: [ 'list', 'indent' ]
                                    }, {
                                        name: 'colors'
                                    }, '/', {
                                        name: 'styles'
                                    } ],
                                    startupFocus: false
                                };
                            }

                            config.title = false;
                            config.pasteFromWordRemoveFontStyles = false;
                            CKEDITOR.disableAutoInline = true;
                            updateModel = function() {
                                $( $( element[ 0 ] ).find( '.aw-widgets-propertyRichTextEditValue' )[ 0 ] ).addClass(
                                    "changed" );
                                scope.prop.dbValue = editor.getData();
                                var uiProperty = scope.prop;

                                // this is needed for test harness
                                uiProperty.dbValues = [ uiProperty.dbValue ];

                                app.vmPropSvc.updateViewModelProperty( uiProperty );
                                return scope.prop.dbValue;
                            };

                            // Blur and Focus overrides necessary.
                            setupEditor = function() {
                                editor
                                    .on( 'instanceReady',
                                        function( e ) {
                                            $( $( element[ 0 ] ).find( '.aw-widgets-propertyRichTextEditValue' )[ 0 ] )
                                                .removeClass( "aw-jswidgets-popUpVisible" );
                                            $(
                                                    document
                                                    .getElementById( "cke_" +
                                                        $( $( element[ 0 ] ).find(
                                                            '.aw-widgets-propertyRichTextEditValue' )[ 0 ] )[ 0 ].id ) )
                                                .find( ".cke_toolbox" ).focus(
                                                    function( e2 ) {
                                                        if( !$(
                                                                $( element[ 0 ] ).find(
                                                                    '.aw-widgets-propertyRichTextEditValue' )[ 0 ] )
                                                            .hasClass( "aw-jswidgets-popUpVisible" ) ) {

                                                            $(
                                                                    $( element[ 0 ] ).find(
                                                                        '.aw-widgets-propertyRichTextEditValue' )[ 0 ] )
                                                                .addClass( "aw-jswidgets-popUpVisible" );
                                                        }
                                                    } ).blur(
                                                    function( e3 ) {

                                                        $(
                                                                $( element[ 0 ] ).find(
                                                                    '.aw-widgets-propertyRichTextEditValue' )[ 0 ] )
                                                            .removeClass( "aw-jswidgets-popUpVisible" );
                                                    } );
                                            editor.setData( scope.prop.dbValue );
                                            if( inTable ) {
                                                setCurserToEnd();
                                            }
                                            setRequiredText();
                                            editor.on( 'change', updateModel );
                                            scope.$on( '$destroy', function() {
                                                element.remove();
                                                element.empty();
                                                element = null;
                                            } );

                                            element.bind( '$destroy', function() {
                                                if( editor ) {
                                                    editor.destroy( true );
                                                }
                                            } );
                                        } );

                                editor.on( 'blur', function( e ) {
                                    if( scope.prop.error && scope.$parent.$$childTail.hideErrorFunction ) {
                                        scope.$parent.$$childTail.hideErrorFunction( e );
                                    }
                                    $( $( element[ 0 ] ).find( '.aw-widgets-propertyRichTextEditValue' )[ 0 ] )
                                        .toggleClass( "aw-jswidgets-popUpVisible" );
                                    setRequiredText();
                                    if( inTable ) {
                                        scope.$destroy();
                                    }
                                } );

                                $( $( element[ 0 ] ).find( '.aw-widgets-propertyRichTextEditValue' )[ 0 ] ).blur(
                                    function( e ) {
                                        if( !$( $( element[ 0 ] ).find( '.aw-widgets-propertyRichTextEditValue' )[ 0 ] )
                                            .hasClass( "aw-jswidgets-popUpVisible" ) ) {
                                            if( inTable ) {
                                                editor.destroy();
                                            }
                                        }
                                    } );

                                editor
                                    .on( 'focus',
                                        function( e ) {
                                            if( !editor && inTable ) {
                                                editor = CKEDITOR.inline( $( element[ 0 ] ).find(
                                                    '.aw-widgets-propertyRichTextEditValue' )[ 0 ], config );
                                                setupEditor();
                                            }
                                            $( $( element[ 0 ] ).find( '.aw-widgets-propertyRichTextEditValue' )[ 0 ] )
                                                .removeClass( "aw-jswidgets-popUpVisible" );

                                            $(
                                                    document
                                                    .getElementById( "cke_" +
                                                        $( $( element[ 0 ] ).find(
                                                            '.aw-widgets-propertyRichTextEditValue' )[ 0 ] )[ 0 ].id ) )
                                                .find( ".cke_toolbox" ).click(
                                                    function( e2 ) {
                                                        if( !$(
                                                                $( element[ 0 ] ).find(
                                                                    '.aw-widgets-propertyRichTextEditValue' )[ 0 ] )
                                                            .hasClass( "aw-jswidgets-popUpVisible" ) ) {

                                                            $(
                                                                    $( element[ 0 ] ).find(
                                                                        '.aw-widgets-propertyRichTextEditValue' )[ 0 ] )
                                                                .addClass( "aw-jswidgets-popUpVisible" );
                                                        }
                                                    } ).blur(
                                                    function( e3 ) {
                                                        $(
                                                                $( element[ 0 ] ).find(
                                                                    '.aw-widgets-propertyRichTextEditValue' )[ 0 ] )
                                                            .removeClass( "aw-jswidgets-popUpVisible" );
                                                    } );

                                            if( !inTable ) {
                                                setCurserToEnd();
                                            }

                                            removeRequiredText();

                                            if( scope.prop.error && scope.$parent.$$childTail.showErrorFunction ) {
                                                scope.$parent.$$childTail.showErrorFunction( e );
                                            }
                                        } );

                                setRequiredText();

                               /**
                                * CKEditor does not provide a 'scroll' event to listen to the scrolling movement.
                                * Hence,attaching the scroll listener to the CK Editor toolbox to listen to scroll movements
                                */
                                UtilsService.handleScroll( scope, element, 'CKEditorInline', function() {
                                    if( element ){
                                        element.find( '.aw-widgets-propertyRichTextEditValue' ).blur();
                                    }
                                });
                            };

                            function setRequiredText() {
                                if( scope.prop.isRequired && scope.prop.dbValue === '' &&
                                    element.find( ".aw-widgets-required" ).length === 0 ) {
                                    var requiredIndicator = "<span class='aw-widgets-required usingPlaceHolder'>" +
                                        scope.prop.propertyRequiredText + "</span>";
                                    $( $( element[ 0 ] ).find( '.aw-widgets-propertyRichTextEditValue' )[ 0 ] ).prepend(
                                        requiredIndicator );
                                }
                            }

                            function removeRequiredText() {
                                if( element.find( ".aw-widgets-required" ).length === 1 ) {
                                    element.find( ".aw-widgets-required" ).detach();
                                }
                            }

                            function setCurserToEnd() {
                                var range = editor.createRange();
                                range.moveToElementEditEnd( range.root );
                                editor.getSelection().selectRanges( [ range ] );
                            }

                            if( inTable ) {
                                if( cellRendered ) {
                                    editor = CKEDITOR.inline( $( element[ 0 ] ).find(
                                        '.aw-widgets-propertyRichTextEditValue' )[ 0 ], config );
                                    setupEditor();
                                }
                            } else {
                                editor = CKEDITOR.inline( $( element[ 0 ] )
                                    .find( '.aw-widgets-propertyRichTextEditValue' )[ 0 ], config );
                                setupEditor();
                            }

                        } );
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwRichTextAreaVal.html'
            };
        }]);

        /**
         * Definition for the <aw-property-object-val> directive
         *
         * @member aw-property-string-text-area
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyObjectVal', function() {
            function Controller( $scope ) {
                var uiProperty = $scope.prop;

                $scope.changeFunction = function( $event ) {
                    if( !uiProperty.isArray ) {
                        app.vmPropSvc.updateViewModelProperty( uiProperty );
                    } else {
                        uiProperty.updateArray( $event );
                    }
                    uiProperty.dirty = true;
                };

                $scope.addObject = function() {
                    if( uiProperty.propApi ) {
                        uiProperty.propApi.showAddObject( uiProperty.propertyName );
                    }
                };

                $scope.removeObject = function( $event ) {
                    $scope.prop.dbValue = '';
                    $scope.prop.uiValue = '';
                    $scope.changeFunction( $event );
                };
            }

            Controller.$inject = [ '$scope' ];

            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                controller: Controller,
                templateUrl: app.getBaseUrlPath() + '/html/NgAwObjectVal.html'
            };
        } );

        /**
         * Definition for the <aw-property-val> directive
         *
         * @member aw-property-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyVal', function() {
            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '=',
                    hint: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwPropertyVal.html',
                link: function( $scope, $element, attrs ) {
                    if( !$scope.prop ) {
                        // this shouldn't happen, but better to catch it here
                        console.log( "aw-property-val (link): " + //
                            "$scope.prop is undefined...Unable to bind to aw-property-val prop=" + attrs.prop + " scope=" +
                            $scope.$id );
                        return;
                    }

                    if( $scope.hint ) {
                        $scope.prop.hint = $scope.hint;
                    }

                    var jqParentElement = $( $element ).find( '.aw-widgets-propertyValContainer' );

                    // Watcher of editable state
                    $scope.editStateListener = $scope.$watch( 'prop.isEditable', function( newValue, oldValue ) {
                        if( jqParentElement && newValue !== oldValue && $scope.prop ) {
                            exports.includePropertyValue( newValue, jqParentElement, $element, $scope.prop );
                        }
                    } );

                    $scope.$on( '$destroy', function() {
                        if( $scope.editStateListener ) {
                            $scope.editStateListener();
                        }
                    } );

                    // non editable case
                    exports.includePropertyValue( $scope.prop.isEditable, jqParentElement, $element, $scope.prop );
                }
            };
        } );

        /**
         * Definition for the <aw-property-string-val> directive
         *
         * @member aw-property-string-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyStringVal', function() {
            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwStringVal.html'
            };
        } );

        /**
         * Definition for the (aw-property-numeric-val) directive.
         *
         * @member aw-property-numeric-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyNumericVal', function() {
            // use directive controller for prop update or pass in using &?
            function Controller( $scope ) {
                var uiProperty = $scope.prop;

                /**
                 * Bound via 'ng-change' on the 'input' element and called on value change
                 *
                 * @memberof NumericValController
                 */
                $scope.changeFunction = function() {
                    if( ngModule.isUndefined( uiProperty.dbValue ) ) {
                        uiProperty.dbValue = '';
                    }
                };

                /**
                 * Bound via 'ng-blur' on the 'input' element and called on input 'blur' (i.e. they leave the field)
                 *
                 * @memberof NumericValController
                 */
                $scope.blurNumericFunction = function( $event ) {
                    /**
                     * In most cases, updateViewModelProperty will overwrite this, but in a few cases, e.g., if there is
                     * a validation error, uiValue won't get updated, so manually do it here
                     * <P>
                     * Note: Setting 'dbValues' is needed for test harness
                     * <P>
                     * Note: We HAVE to check for 'null' since value can be '0' (which is otherwise 'false')
                     */
                    if( !uiProperty.isArray ) {
                        if( uiProperty.dbValue !== null ) {
                            uiProperty.uiValue = uiProperty.dbValue.toString();
                            uiProperty.dbValues = [ uiProperty.dbValue.toString() ];
                        } else {
                            uiProperty.uiValue = '';
                            uiProperty.dbValues = [];
                        }

                        app.vmPropSvc.updateViewModelProperty( uiProperty );
                    } else {
                        uiProperty.updateArray( $event );
                    }
                };

                /**
                 * Bound via 'ng-keydown' on the 'input' element and called on key down on 'input'
                 *
                 * @memberof NumericValController
                 */
                $scope.evalKey = function( $event ) {
                    if( $event.keyCode === _kcEnter ) {
                        if( uiProperty.isArray ) {
                            uiProperty.updateArray( $event );
                            $event.preventDefault();
                        }
                    }
                };
            }

            Controller.$inject = [ '$scope' ];

            return {
                restrict: 'E',
                controller: Controller,
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwNumericVal.html'
            };
        } );

        /**
         * Definition for the (aw-property-rendering-hint) directive.
         *
         * @member aw-property-rendering-hint
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyRenderingHint', function() {
            return {
                restrict: 'E',
                scope: {
                    // hint and prop are defined in the parent (i.e. controller's) scope
                    hint: '=',
                    prop: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwRenderingHint.html'
            };
        } );

        /**
         * Definition for the (aw-property-label) directive.
         *
         * @member aw-property-label
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyLabel', function() {
            return {
                restrict: 'E',
                templateUrl: app.getBaseUrlPath() + '/html/NgAwLabel.html'
            };
        } );

        /**
         * Definition for the (aw-property-boolean) directive.
         *
         * @member aw-property-boolean
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyBoolean', function() {
            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '=',
                    hint: '@'
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwBoolean.html'
            };
        } );

       /**
        * Definition for the (aw-property-image) directive.
        *
        * @member aw-property-image
        * @memberof
        *
        * @return {Void}
        */
        app.directive( 'awPropertyImage', function() {
            return {
               restrict: 'E',
               link: function( scope, element, attrs ) {
                   if( element ) {
                       element.append( iconService.getIcon( attrs.name ) );
                   }
               }
           };
        } );

        /**
         * Definition for the (aw-property-checkbox-val) directive.
         *
         * @member aw-property-checkbox-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyCheckboxVal', function() {
            // use directive controller for prop update or pass in using &?
            function Controller( $scope ) {
                var uiProperty = $scope.prop;

                /**
                 * Bound via 'ng-change' on the 'input' element and called on value change.
                 *
                 * @memberof CheckboxValController
                 */
                $scope.changeFunction = function() {
                    if( !uiProperty.isArray ) {
                        // this is needed for test harness
                        uiProperty.dbValues = [ Boolean( uiProperty.dbValue ) ];
                        app.vmPropSvc.updateViewModelProperty( uiProperty );
                    }
                };

                /**
                 * Returns 'TRUE' if isRequired flag is set to true.
                 *
                 * @memberof CheckboxValController
                 */
                $scope.showRequired = function() {
                    if( uiProperty.dbValue === null ) {
                        return $scope.prop.isRequired;
                    }

                    return false;
                };

                /**
                 * Bound via 'ng-keydown' on the 'input' element and called on key down on 'input'
                 *
                 * @memberof CheckboxValController
                 */
                $scope.evalKey = function( $event ) {
                    if( $event.keyCode === _kcEnter ) {
                        if( uiProperty.isArray ) {
                            uiProperty.updateArray( $event );
                            $event.preventDefault();
                        }
                    }
                };
            }

            Controller.$inject = [ '$scope' ];

            // add directive controller for prop update or pass in using &?
            return {
                restrict: 'E',
                controller: Controller,
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwCheckboxVal.html'
            };
        } );

        /**
         * Definition for the <aw-property-toggle-val> directive
         *
         * @member aw-property-toggle-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyToggleButtonVal', function() {
            function Controller( $scope ) {
                var uiProperty = $scope.prop;

                /**
                 * Bound via 'ng-change' on the 'input' element and called on value change.
                 *
                 * @memberof ToggleButtonValController
                 */
                $scope.changeFunction = function() {
                    if( !uiProperty.isArray ) {
                        // this is needed for test harness
                        uiProperty.dbValues = [ Boolean( uiProperty.dbValue ) ];
                        app.vmPropSvc.updateViewModelProperty( uiProperty );
                    }
                };

                /**
                 * Returns 'TRUE' if isRequired flag is set to true.
                 *
                 * @memberof ToggleButtonValController
                 */
                $scope.showRequired = function() {
                    if( uiProperty.dbValue === null ) {
                        return $scope.prop.isRequired;
                    }
                    return false;
                };

                /**
                 * Bound via 'ng-keydown' on the 'input' element and called on key down on 'input'
                 *
                 * @memberof ToggleButtonValController
                 */
                $scope.evalKey = function( $event ) {
                    if( $event.keyCode === _kcEnter ) {
                        if( uiProperty.isArray ) {
                            uiProperty.updateArray( $event );
                            $event.preventDefault();
                        }
                    }
                };
            }

            Controller.$inject = [ '$scope' ];

            return {
                restrict: 'E',
                controller: Controller,
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwToggleButtonVal.html'
            };
        } );

        /**
         * Definition for the (aw-property-radio-button-val) directive.
         *
         * @member aw-property-radio-button-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyRadioButtonVal', function() {
            // use directive controller for prop update or pass in using &?
            function Controller( $scope ) {
                var uiProperty = $scope.prop;

                /**
                 * Bound via 'ng-change' on the 'input' element and called on value change.
                 *
                 * @memberof RadioButtonValController
                 */
                $scope.changeFunction = function() {
                    if( !uiProperty.isArray ) {
                        // this is needed for test harness
                        uiProperty.dbValues = [ Boolean( uiProperty.dbValue ) ];
                        app.vmPropSvc.updateViewModelProperty( uiProperty );
                    }
                };

                /**
                 * Returns 'TRUE' if isRequired flag is set to true.
                 *
                 * @memberof RadioButtonValController
                 */
                $scope.showRequired = function() {
                    if( uiProperty.dbValue === null ) {
                        return $scope.prop.isRequired;
                    }
                    return false;
                };

                /**
                 * Bound via 'ng-keydown' on the 'input' element and called on key down on 'input'
                 *
                 * @memberof RadioButtonValController
                 */
                $scope.evalKey = function( $event ) {
                    if( $event.keyCode === _kcEnter ) {
                        if( uiProperty.isArray ) {
                            uiProperty.updateArray( $event );
                            $event.preventDefault();
                        }
                    }
                };
            }

            Controller.$inject = [ '$scope' ];

            // add directive controller for prop update or pass in using &?
            return {
                restrict: 'E',
                controller: Controller,
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '=',
                    vertical: '@',
                    customTrueLabel: '@',
                    customFalseLabel: '@'
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwRadioButtonVal.html'
            };
        } );

        /**
         * Definition for the (aw-property-non-edit-val) directive.
         *
         * @member aw-property-non-edit-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyNonEditVal', function() {
            function Controller( $scope ) {
                $scope.openObjectLinkPage = function() {
                    var uiProperty = $scope.prop;
                    var uid = '';

                    if( !uiProperty.isArray ) {
                        uid = uiProperty.dbValue;
                    } else {
                        uid = uiProperty.dbValue[ $scope.index ];
                    }

                    if( uiProperty.whatAmI === 'propDC' ) {
                        // this is temp code in phase 0 to get r-o object links working...
                        // proper solution coming in p1.
                        window.location = "#com.siemens.splm.clientfx.tcui.xrt.showObject;uid=" + uid;
                    } else if( uiProperty.propApi ) {
                        uiProperty.propApi.openObjectLinkPage( uiProperty.propertyName, uid );
                    }
                };
            }

            Controller.$inject = [ '$scope' ];

            // add directive controller for prop update or pass in using &?
            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '=',
                    index: '@'
                },
                link: function( $scope, $element, attrs ) {
                    $scope.$on( '$destroy', function() {
                        $element.remove();
                        $element.empty();
                    } );
                },
                controller: Controller,
                templateUrl: app.getBaseUrlPath() + '/html/NgAwNonEditVal.html'
            };
        } );

        /**
         * Definition for the (aw-property-non-edit-val) directive.
         *
         * @member aw-property-non-edit-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyTableNonEditVal', function() {
            // add directive controller for prop update or pass in using &?
            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                link: function( $scope, $element, attrs ) {
                    if( $scope.prop.isEditable && $scope.prop.type === "BOOLEAN" ) {
                        if( !$scope.prop.dbValue ) {
                            $scope.prop.uiValue = $scope.prop.propertyRadioFalseText;
                        } else {
                            $scope.prop.uiValue = $scope.prop.propertyRadioTrueText;
                        }
                    }
                    $scope.$on( '$destroy', function() {
                        $element.remove();
                        $element.empty();
                    } );
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwTableNonEditVal.html'
            };
        } );

        /**
         * Definition for the 'aw-parse-html' directive used to parse URL text and replace them with actual links
         *
         * @member aw-parse-html
         * @memberof NgAttributeDirectives
         *
         * @return {Void}
         */
        app.directive( 'awParseHtml', function() {
            /**
             * @private
             */
            var urlPattern = /(http|https):\/\/[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:\/\$~+#-]*[\w@?^=%&amp;\/~+#-])?|(http|https):\/\/([\w-]+)+([\w.,@?^=%&amp;:\/\$~+#-]*[\w@?^=%&amp;\/~+#-])?/gi;
            var newLinePattern = /\n/g;
            return {
                restrict: 'A',
                replace: true,
                scope: {
                    displayVal: '=',
                    isRichText: '=',
                    renderingHint: '='
                },
                link: function( $scope, $element, attrs ) {
                    $scope.parseUrlListener = $scope.$watch( 'displayVal', function( newValue ) {
                        if( newValue !== null && newValue !== undefined ) {
                            var parsedHtml = newValue;
                            if( !$scope.isRichText ||
                                ( $scope.isRichText && $scope.renderingHint ) ) {
                                // escape HTML string
                                parsedHtml = app.cdm.htmlEscapeAllowEntities( newValue );
                                // replaces url text to hyperlinks
                                parsedHtml = parsedHtml.replace( urlPattern, '<a href="$&">$&</a>' );
                                // replaces new lines to <br> tags
                                parsedHtml = parsedHtml.replace( newLinePattern, '<br/>' );
                            }

                            $element.html( parsedHtml );
                        }
                    } );

                    $scope.$on( '$destroy', function() {
                        if( $scope.parseUrlListener ) {
                            $scope.parseUrlListener();
                        }
                    } );
                }
            };
        } );

        /**
         * Definition for the 'aw-autofocus' directive used to autofocus an element
         *
         * @member aw-autofocus
         * @memberof NgAttributeDirectives
         *
         * @return {Void}
         */
        app.directive( 'awAutofocus', function() {
            function Controller( $scope, $element ) {
                if( $scope.autoFocus ) {
                    $( $element[ 0 ] ).focus();
                }
            }

            Controller.$inject = [ '$scope', '$element' ];

            return {
                restrict: "A",
                controller: Controller,
                scope: {
                    autoFocus: '='
                }
            };
        } );

        /**
         * Definition for the 'aw-widget-initialize' directive used to initialize widget
         *
         * @member aw-widget-initialize
         * @memberof NgAttributeDirectives
         *
         * @return {Void}
         */
        app.directive( 'awWidgetInitialize', function() {
            return {
                restrict: "A",
                require: '?ngModel',
                link: function( $scope, $element, attrs, ngModelCtrl ) {
                    if( !ngModelCtrl ) {
                        return;
                    }

                    $scope.widgetInitializeListener = $scope.$watch( function() {
                        return $scope.$parent.prop.initialize;
                    }, function( newValue ) {
                        if( newValue ) {
                            // when widget is initializing set pristine so that it clears out dirty flags
                            ngModelCtrl.$setPristine();
                            $scope.$parent.prop.initialize = false;
                        }
                    } );
                }
            };
        } );

        /**
         * Definition for the 'aw-property-native-table-val' directive used for basic read only display
         * could replace aw-property-non-edit-val
         *
         * @member aw-property-non-edit-val
         * @memberof NgElementDirectives
         */
        app.directive( 'awPropertyNativeTableVal', function() {
            function Controller( $scope ) {

                // walk up the scope hierarchy to find the grid from the cell
                var getGridOverlay = function() {
                    var parentScope = $scope.$parent;
                    while( parentScope ) {
                        if( parentScope.hasOwnProperty( 'gridOverlay' ) ) {
                            return parentScope.gridOverlay;
                        }
                        parentScope = parentScope.$parent;
                    }
                };

                // this gets called too much... TODO: find a better way. create a ref between the cell scope and
                // container scope (at link time) to avoid re-walking the tree or?
                $scope.isContainerEditable = function() {
                    var grid = getGridOverlay();
                    if( grid ) {
                        return grid.editable;
                    }
                };

                $scope.startEdit = function( ev ) {
                    // get the scope of the container to see if it supports edit
                    var gridOverlay = getGridOverlay();
                    if( gridOverlay && gridOverlay.editable ) {
                        // for some reason, when this event triggers the stopEdit, the parent cell can't be found...
                        // so, stopping propagation for now... means you can be in edit mode for multiple cells fttb
                        ev.stopPropagation();
                        if( $scope.prop && !$scope.prop.isEditing ) {
                            //var nonEditDiv = ev.currentTarget; //.parentElement;
                            // need to fully populate overlay here if we haven't already...

                            $scope.prop.isEditable = true; //tmp ngaw w-a... fix coming soon from Nihar/Mark
                            $scope.prop.isEnabled = true;
                            $scope.prop.isEditing = true;

                            // could change template and append on first activity...
                            //exports.insertNgProp(nonEditDiv, '<aw-property-val prop="prop"/>', $scope.prop);

                            $( 'body' ).on( 'click touchstart', $scope.stopEdit );
                        }
                    }
                };

                $scope.stopEdit = function( event ) {
                    var cell = $( event.target ).closest( '.aw-widgets-cellTop' );
                    if( cell.length === 0 || !cell.scope() || !cell.scope().prop.isEditing ) {
                        $scope.$evalAsync( function() {
                            $scope.prop.isEditing = false;
                        } );

                        $( 'body' ).off( 'click touchstart', $scope.stopEdit );
                    }
                };
            }
            Controller.$inject = [ '$scope' ];

            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwNativeTableVal.html',
                controller: Controller
            };
        } );

        /**
         * Definition for the (aw-property-native-table-prop-val) directive - will need to be unified with
         * aw-property-native-table-val.
         *
         * @member aw-property-non-edit-val
         * @memberof NgElementDirectives
         */
        app.directive( 'awPropertyNativeTablePropVal', function() {
            function Controller( $scope ) {

                // walk up the scope hierarchy to find the grid from the cell
                var getGridOverlay = function() {
                    var parentScope = $scope.$parent;
                    while( parentScope ) {
                        if( parentScope.hasOwnProperty( 'gridOverlay' ) ) {
                            return parentScope.gridOverlay;
                        }
                        parentScope = parentScope.$parent;
                    }
                };

                var isPopUpVisible = function( stopTarget ) {
                    var isVisible = false;
                    if( stopTarget !== null ) {
                        var arrLength = $( stopTarget ).find( ".aw-jswidgets-popUpVisible" ).length;

                        if( arrLength > 0 ) {
                            isVisible = true;
                        }
                    }
                    return isVisible;
                };
                ///// checks the property is textarea or not
                var checkRendering = function( scope ) {
                    if( ( scope.prop.renderingHint === "textarea" ) || ( scope.prop.maxLength >= 60 ) ) {
                        return true;
                    }
                    return false;
                };
                // this gets called too much... TODO: find a better way. create a ref between the cell scope and
                // container scope (at link time) to avoid re-walking the tree or?
                $scope.isContainerEditable = function() {
                    var grid = getGridOverlay();
                    if( grid ) {
                        return grid.editable;
                    }
                };

                var originalVal = null;
                var nonEditDiv = null;
                $scope.startEdit = function( ev ) {
                    // get the scope of the container to see if it supports edit
                    var gridOverlay = getGridOverlay();

                    if( gridOverlay && gridOverlay.editable && $scope.prop.isEditable ) {
                        // for some reason, when this event triggers the stopEdit, the parent cell can't be found...
                        // so, stopping propagation for now... means you can be in edit mode for multiple cells fttb
                        ev.stopPropagation();
                        if( $scope.prop && !$scope.prop.isEditing ) {

                            nonEditDiv = ev.currentTarget; //.parentElement;
                            // need to fully populate overlay here if we haven't already...
                            $scope.prop.isEnabled = true;
                            $scope.prop.isEditing = true;
                            $scope.prop.autofocus = true;
                            // need to check whether the property is text area or not so as to apply correct css to it
                            var isTextArea = checkRendering( $scope );
                            var parentRow = $( nonEditDiv ).parents( "div.ui-grid-row.ng-scope" );
                            if( isTextArea ) {
                                if(parentRow[ 0 ] &&  !parentRow[ 0 ].classList.contains( 'aw-jswidgets-tablePropertyEditTextAreaCell' ) ) {
                                    parentRow[ 0 ].classList.add( 'aw-jswidgets-tablePropertyEditTextAreaCell' );
                                    parentRow[ 0 ].classList.remove( 'aw-jswidgets-tablePropertyEditCell' );
                                } else {
                                    if( !parentRow.context.classList.contains( 'aw-jswidgets-tablePropertyEditTextAreaCell' ) ) {
                                        parentRow.context.classList.add( 'aw-jswidgets-tablePropertyEditTextAreaCell' );
                                        parentRow.context.classList.remove( 'aw-jswidgets-tablePropertyEditCell' );
                                    }
                                }

                            } else {
                                if( parentRow[ 0 ] && !parentRow[ 0 ].classList.contains( 'aw-jswidgets-tablePropertyEditTextAreaCell' ) ) {
                                    if( !parentRow[ 0 ].classList.contains( 'aw-jswidgets-tablePropertyEditCell' ) ) {
                                        parentRow[ 0 ].classList.add( 'aw-jswidgets-tablePropertyEditCell' );
                                    }
                                } else {
                                    if( !parentRow.context.classList.contains( 'aw-jswidgets-tablePropertyEditCell' ) ) {
                                        parentRow.context.classList.add( 'aw-jswidgets-tablePropertyEditCell' );
                                    }
                                }
                            }

                            originalVal = $scope.prop.uiValue;
                            ev.currentTarget.classList.add( 'ng-dirty' );
                            ev.currentTarget.classList.add( 'aw-jswidgets-editableProp' );
                            ev.currentTarget.classList.remove( 'aw-jswidgets-uicell' );
                            $( 'body' ).on( 'click', $scope.stopEdit );

                        }
                    }
                };

                $scope.stopEdit = function( event ) {
                    var gridOverlay = getGridOverlay();
                    var cell = $( event.target ).closest( '.aw-widgets-cellTop' );
                    var stopTarget = nonEditDiv;
                    var popUpVisible = isPopUpVisible( stopTarget );
                    var parentFinal = $( nonEditDiv ).parents( "div.ui-grid-viewport.ng-isolate-scope" );
                    var modifiedVal = $scope.prop.uiValue;
                    var changedVal = true;
                    if( modifiedVal === originalVal ) {
                        changedVal = false;
                    }
                    if( !popUpVisible ) {
                        nonEditDiv.classList.remove( 'changed' );
                        /////Removes the dirtyness of the property if the command is clicked directly without clicking outside the property widget.
                        if(gridOverlay && !gridOverlay.editable ) {
                            parentFinal[0].classList.remove( 'aw-jswidgets-tablePropertyContentChanged' );
                        }
                        else if( stopTarget.classList.contains( 'ng-dirty' ) && changedVal) {
                            nonEditDiv.classList.add( 'changed' );
                            if(parentFinal[ 0 ] && !parentFinal[ 0 ].classList.contains( 'aw-jswidgets-tablePropertyContentChanged' ) ) {
                                parentFinal[ 0 ].classList.add( 'aw-jswidgets-tablePropertyContentChanged' );
                            } else {
                                parentFinal.context.classList.add( 'aw-jswidgets-tablePropertyContentChanged' );
                            }

                        }
                        var parentRow = $( nonEditDiv ).parents( "div.ui-grid-row.ng-scope" );
                        if( parentRow[ 0 ] && parentRow[ 0 ].classList.contains( 'aw-jswidgets-tablePropertyEditTextAreaCell' ) ) {
                            parentRow[ 0 ].classList.remove( 'aw-jswidgets-tablePropertyEditTextAreaCell' );
                        } else {
                            parentRow.context.classList.remove( 'aw-jswidgets-tablePropertyEditTextAreaCell' );
                        }
                        if(parentRow[ 0 ] && parentRow[ 0 ].classList.contains( 'aw-jswidgets-tablePropertyEditCell' ) ) {
                            parentRow[ 0 ].classList.remove( 'aw-jswidgets-tablePropertyEditCell' );
                        } else {
                            parentRow.context.classList.remove( 'aw-jswidgets-tablePropertyEditCell' );
                        }

                        stopTarget.classList.remove( 'aw-jswidgets-uicell' );
                        stopTarget.classList.add( 'aw-jswidgets-uiNonEditCell' );


                    }
                    if( cell.length === 0 || !cell.scope() || !cell.scope().prop.isEditing ) {
                        $scope.$evalAsync( function() {
                            if( $scope.prop.dateApi !== null && popUpVisible ) {
                                $scope.prop.isEditing = true;
                                $scope.prop.isEnabled = true;
                                $scope.prop.autofocus = true;
                            } else {
                                $scope.prop.isEditing = false;
                                $scope.prop.isEnabled = true;
                                $scope.prop.autofocus = true;
                            }
                        } );

                        $( 'body' ).off( 'click', $scope.stopEdit );
                    }
                };
            }
            Controller.$inject = [ '$scope' ];

            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwNativeTableVal.html',
                controller: Controller
            };
        } );

        /**
         * Definition for the (aw-property-non-edit-array-val) directive.
         *
         * @member aw-property-non-edit-array-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyNonEditArrayVal', [
            '$timeout',
            'MaxRowService',
            function( $timeout, maxRowSvc ) {
            // add directive controller for prop update or pass in using &?
            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwNonEditArrayVal.html',
                link: function( $scope, $element, attrs ) {
                    $scope.nonEditArrayTimer = $timeout( function () {
                        var arrayHeight = maxRowSvc._calculateArrayHeight( $element, $scope.prop.maxRowCount );
                        if( arrayHeight ) {
                            $scope.arrayHeight = arrayHeight;
                        }
                    } );

                    $scope.$on( '$destroy', function() {
                        $element.remove();
                        $element.empty();
                    } );
                }
            };
        } ] );

        /**
         * Definition for the (aw-property-array-edit-val) directive.
         *
         * @member aw-property-array-edit-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyArrayEditVal', function() {
            // add directive controller for prop update or pass in using &?
            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                templateUrl: app.getBaseUrlPath() + '/html/NgAwArrayEditVal.html',
                link: function( $scope, $element, attrs ) {
                    if( !$scope.prop ) {
                        // this shouldn't happen, but better to catch it here
                        console.log( "aw-property-array-edit-val (link): " + //
                            "$scope.prop is undefined...Unable to bind to aw-property-array-edit-val prop=" + attrs.prop + " scope=" +
                            $scope.$id );
                        return;
                    }

                    var jqParentElement = $( $element ).find( '.aw-jswidgets-arrayEditWidgetContainer' );
                    exports.includeArrayPropertyValue( jqParentElement, $element, $scope.prop );

                    $scope.$on( '$destroy', function() {
                        $element.remove();
                        $element.empty();
                    } );
                }
            };
        } );

        /**
         * Definition for the <aw-property-array-val> directive
         *
         * @member aw-property-array-val
         * @memberof NgElementDirectives
         *
         * @return {Void}
         */
        app.directive( 'awPropertyArrayVal', [
            '$timeout',
            'MaxRowService',
            function( $timeout, maxRowSvc ) {
            return {
                restrict: 'E',
                scope: {
                    // 'prop' is defined in the parent (i.e. controller's) scope
                    prop: '='
                },
                controller: 'awPropertyArrayValController',
                templateUrl: app.getBaseUrlPath() + '/html/NgAwArrayVal.html',
                link: function( $scope, $element, attrs ) {
                    $scope.editArrayTimer = $timeout( function () {
                        var arrayHeight = maxRowSvc._calculateArrayHeight( $element, $scope.prop.maxRowCount );
                        if( arrayHeight ) {
                            $scope.arrayHeight = arrayHeight;
                        }
                    } );

                    $scope.$on( '$destroy', function() {
                        $element.remove();
                        $element.empty();
                    } );
                }
            };
        } ] );

        /**
         * Controller for {@link NgElementDirectives.aw-property-array-val} directive.
         *
         * @constructor awPropertyArrayValController
         * @memberof NgControllers
         *
         * @param $scope
         * @param $element
         * @param localeService
         */
        app.controller( 'awPropertyArrayValController', [
            '$scope',
            '$element',
            'localeService',
            function( $scope, $element, localeService ) {
                /**
                 * Create a duplicate prop object from the paramater provided
                 *
                 * @memberof NgControllers.awPropertyArrayValController
                 *
                 * @param {NativeGenericViewModelProperty} Property overlay object
                 * @return {Object} Duplicate prop instance
                 */
                $scope.duplicateProp = function( prop ) {
                    var dummyProp = {};
                    for( var key in prop ) {
                        dummyProp[ key ] = prop[ key ];
                    }

                    dummyProp.overlayType = 'dummyArrayProp';

                    return dummyProp;
                };

                /**
                 * Clear edit widget after adding the value to the array.
                 *
                 * @memberof NgControllers.awPropertyArrayValController
                 *
                 * @param {String} type - Data type
                 * @param {String} hint - rendering hint
                 * @return {Void}
                 */
                $scope.clearWidget = function( type, hint ) {
                    switch( type ) {
                        case "STRINGARRAY":
                        case "INTEGERARRAY":
                        case "DOUBLEARRAY":
                        case "OBJECTARRAY":
                            $scope.dummyProp.dbValue = null;
                            $scope.dummyProp.uiValue = null;
                            break;
                        case "DATEARRAY":
                            $scope.dummyProp.dbValue = null;
                            $scope.dummyProp.uiValue = null;
                            $scope.dummyProp.dateApi.dateValue = null;
                            $scope.dummyProp.dateApi.timeValue = null;
                            break;
                        case "BOOLEANARRAY":
                            switch( hint ) {
                                case "radiobutton":
                                    $scope.dummyProp.dbValue = null;
                                    $scope.dummyProp.uiValue = null;
                                    break;
                                default:
                                    break;
                            }
                            break;
                        default:
                            break;
                    }
                };

                var uiProperty = $scope.prop;
                $scope.dummyProp = $scope.duplicateProp( uiProperty );
                uiProperty.editArrayInlineMode = false;
                uiProperty.dirty = false;

                $scope.clearWidget( uiProperty.type, uiProperty.renderingHint );

                /**
                 * Check to see if the dbValue is a valid value to add it to array.
                 *
                 * @memberof NgControllers.awPropertyArrayValController
                 *
                 * @param {NativeGenericViewModelProperty} propOverlay - NativeGenericViewModelProperty object that will be updated.
                 * @return {Boolean} True if db value is valid
                 */
                $scope.isValidArrayValue = function( propOverlay ) {
                    var isValid = false;

                    if( propOverlay && propOverlay.dbValue !== "" &&
                        propOverlay.dbValue !== null && propOverlay.dbValue !== undefined ) {
                        if( propOverlay.type === 'INTEGERARRAY' || propOverlay.type === 'DOUBLEARRAY' ||
                              propOverlay.type === 'DATEARRAY' ) {
                            if( isFinite( propOverlay.dbValue ) ) {
                                propOverlay.dbValue = Number( propOverlay.dbValue );
                                isValid = true;
                            }
                        } else if( propOverlay.type === 'BOOLEANARRAY' ) {
                            isValid = app._.isBoolean( propOverlay.dbValue );
                        } else {
                            isValid = true;
                        }
                    }

                    return isValid;
                };

                /**
                 * Adds value to array widget, clears the edit widget after adding and marks the widget as dirty.
                 *
                 * @memberof NgControllers.awPropertyArrayValController
                 *
                 * @param {DOMEvent} $event - Event object
                 * @return {Void}
                 */
                $scope.dummyProp.updateArray = function( $event ) {
                    // propagate error from dummy prop to uiProperty
                    uiProperty.error = $scope.dummyProp.error;
                    if( $scope.isValidArrayValue( $scope.dummyProp ) && !uiProperty.error ) {
                        uiProperty.dbValue.push( $scope.dummyProp.dbValue );

                        // For LOVs update display values with LOV entry's uiValue
                        if( uiProperty.hasLov ) {
                            uiProperty.uiValue = $scope.dummyProp.uiValue;
                            uiProperty.displayValues.push( uiProperty.uiValue );

                            if( uiProperty.isArray ) {
                                uiProperty.displayValsModel = uiProperty.displayValsModel || [];
                                uiProperty.displayValsModel.push( {
                                    displayValue: uiProperty.uiValue,
                                    selected: false
                                } );
                            }
                        }

                        app.vmPropSvc.updateViewModelProperty( uiProperty );

                        $scope.clearWidget( uiProperty.type, uiProperty.renderingHint );
                        uiProperty.dirty = true;
                    }
                };

                /**
                 * Selection of the array list is handled. First click on the cell selects the list item and
                 * next click on the cell will embed edit widget into the cell so that user should be able
                 * to replace the value.
                 *
                 * @memberof NgControllers.awPropertyArrayValController
                 *
                 * @param {DOMEvent} $event - Event object
                 * @param {Number} $index - selected index of the list.
                 * @return {Void}
                 */
                $scope.selectAndEdit = function( $event, $index ) {
                    var jqParentElement = $event.currentTarget;
                    if( !uiProperty.editArrayInlineMode ) {
                        if( uiProperty.displayValsModel[ $index ].selected ) {
                            uiProperty.autofocus = true;

                            uiProperty.currArrayDbValue = uiProperty.dbValue.slice( 0 );
                            uiProperty.dbValue = uiProperty.currArrayDbValue[ $index ];
                            uiProperty.uiValue = uiProperty.displayValues[ $index ];
                            uiProperty.$index = $index;

                            exports.includeArrayPropertyValue( jqParentElement, jqParentElement, uiProperty );

                            uiProperty.editArrayInlineMode = true;
                        } else {
                            for( var i = 0; i < uiProperty.displayValsModel.length; i++ ) {
                                if( i === $index ) {
                                    uiProperty.displayValsModel[ i ].selected = true;
                                    $scope.lastSelected = uiProperty.displayValsModel[ $index ];
                                } else {
                                    uiProperty.displayValsModel[ i ].selected = false;
                                }
                            }
                        }
                    }
                    $event.stopPropagation();
                };


                /**
                 * Replaces value of array cell item and inserts non-edit widget with updated value.
                 *
                 * @memberof NgControllers.awPropertyArrayValController
                 *
                 * @param {DOMEvent} $event - Event object
                 * @param {Boolean} skipUpdate - TRUE if there is no change in value then
                 *        don't call 'updateViewModelProperty'.
                 * @return {Void}
                 */
                $scope.prop.updateArray = function( $event, skipUpdate ) {
                    if( $scope.isValidArrayValue( uiProperty ) &&
                        (!uiProperty.error || uiProperty.hasServerValidationError) ) {
                        if( uiProperty.currArrayDbValue ) {
                            uiProperty.currArrayDbValue.splice( uiProperty.$index, 1, uiProperty.dbValue );
                        }

                        uiProperty.dirty = true;
                        uiProperty.dbValue = uiProperty.currArrayDbValue.slice( 0 );

                        // For LOVs update display values with LOV entry's uiValue
                        if( uiProperty.hasLov ) {
                            uiProperty.displayValues.splice( uiProperty.$index, 1, uiProperty.uiValue );

                            if( uiProperty.isArray ) {
                                uiProperty.displayValsModel = uiProperty.displayValsModel || [];
                                uiProperty.displayValsModel.splice( uiProperty.$index, 1, {
                                    displayValue: uiProperty.uiValue,
                                    selected: false
                                } );
                            }
                        }

                        if( !skipUpdate ) {
                            app.vmPropSvc.updateViewModelProperty( uiProperty );
                        }
                    } else {
                        if( uiProperty.dbValue === "" || uiProperty.dbValue === null
                            || uiProperty.dbValue === undefined ) {
                            /**
                             * Empty values are not allowed while replacing existing value in array. Revert it to
                             * previous value if empty value is entered by user.
                             */
                            uiProperty.dbValue = uiProperty.currArrayDbValue.slice( 0 );
                        }
                    }
                    uiProperty.editArrayInlineMode = false;
                    $scope.insertNonEdit( $event );
                };

                /**
                 * Inserts non-edit widget with updated value and destroys any previous scopes.
                 *
                 * @memberof NgControllers.awPropertyArrayValController
                 *
                 * @param {DOMEvent} $event - Event object
                 * @return {Void}
                 */
                $scope.insertNonEdit = function( $event ) {
                    if( $event ) {
                        uiProperty.autofocus = false;
                        var inputElement = $event;

                        if( $event.currentTarget ) {
                            inputElement = $event.currentTarget;
                        }

                        var jqParentElement = $( inputElement ).closest( '.aw-state-selected .aw-jswidgets-arrayValue' );
                        var previousScopeElement = $( jqParentElement ).find( '.aw-jswidgets-property' );
                        // destroying scope of previous element
                        if( previousScopeElement ) {
                            var contrScope = previousScopeElement.scope();
                            if( contrScope ) {
                                contrScope.$destroy();
                                previousScopeElement.remove();
                            }
                        }

                        exports.insertNgProp( jqParentElement, '<div ng-click="selectAndEdit($event, $index)">{{displayNode.displayValue}}</div>', uiProperty );
                    }
                };

                /**
                 * Used to move UP value in the array cell list based on the index.
                 *
                 * @memberof NgControllers.awPropertyArrayValController
                 *
                 * @param {Number} $index - index of the cell list item which needs to be moved.
                 * @return {Void}
                 */
                $scope.moveUp = function( $index ) {
                    if( $index > 0 ) {
                        var currDbVal = uiProperty.dbValue[ $index ];
                        var currDisplayVal = uiProperty.displayValues[ $index ];
                        var currDisplayValModel = uiProperty.displayValsModel[ $index ];

                        uiProperty.dbValue.splice( $index, 1 );
                        uiProperty.dbValue.splice( $index - 1, 0, currDbVal );

                        uiProperty.displayValues.splice( $index, 1 );
                        uiProperty.displayValues.splice( $index - 1, 0, currDisplayVal );

                        uiProperty.displayValsModel.splice( $index, 1 );
                        uiProperty.displayValsModel.splice( $index - 1, 0, currDisplayValModel );

                        uiProperty.dirty = true;
                        app.vmPropSvc.updateViewModelProperty( uiProperty );
                    }
                };

                /**
                 * Used to move DOWN value in the array cell list based on the index.
                 *
                 * @memberof NgControllers.awPropertyArrayValController
                 *
                 * @param {Number} $index - index of the cell list item which needs to be moved.
                 * @return {Void}
                 */
                $scope.moveDown = function( $index ) {
                    if( $index <= uiProperty.displayValsModel.length - 1 ) {
                        var currDbVal = uiProperty.dbValue[ $index ];
                        var currDisplayVal = uiProperty.displayValues[ $index ];
                        var currDisplayValModel = uiProperty.displayValsModel[ $index ];

                        uiProperty.dbValue.splice( $index, 1 );
                        uiProperty.dbValue.splice( $index + 1, 0, currDbVal );

                        uiProperty.displayValues.splice( $index, 1 );
                        uiProperty.displayValues.splice( $index + 1, 0, currDisplayVal );

                        uiProperty.displayValsModel.splice( $index, 1 );
                        uiProperty.displayValsModel.splice( $index + 1, 0, currDisplayValModel );

                        uiProperty.dirty = true;
                        app.vmPropSvc.updateViewModelProperty( uiProperty );
                    }
                };

                /**
                 * Removes the item from array cell list.
                 *
                 * @memberof NgControllers.awPropertyArrayValController
                 *
                 * @param {Number} $index - index of the cell list item which needs to be moved.
                 * @return {Void}
                 */
                $scope.remove = function( $index ) {
                    uiProperty.dbValue.splice( $index, 1 );

                    if( uiProperty.hasLov ) {
                        uiProperty.displayValues.splice( $index, 1);

                        if( uiProperty.isArray ) {
                            uiProperty.displayValsModel = uiProperty.displayValsModel || [];
                            uiProperty.displayValsModel.splice( $index, 1);
                        }
                    }

                    uiProperty.dirty = true;
                    app.vmPropSvc.updateViewModelProperty( uiProperty );
                };
            }
        ] );

        /**
         * Initialize ('bootstrap') the angular system and create an angular controller on a new 'child' of the given
         * 'parent' element.
         *
         * @param {Element} parentElement - The DOM element the controller and 'inner' HTML content will be added to.
         *            <P>
         *            Note: All existing 'child' elements of this 'parent' will be removed.
         *
         * @param {String} innerHtml - String that defines the exact HTML content that will be added to the 'parent'
         *            element.
         *
         * @param {Object} cellData - Arbitrary object to be set as the primary 'scope' of the new angular controller.
         *            <P>
         *            Note: This object will have the 'rootScopeElement' property set on this object with the new
         *            AngularJS Element created to hold the compiled given 'innerHtml' and attached as a child to the
         *            given 'parentElement'.
         *
         * @return {Void}
         */
        exports.insertNgPropVal = function( parentElement, innerHtml, cellData ) {
            /**
             * Create an 'outer' <DIV> (to hold the given 'inner' HTML) and create the angular controller on it.
             * <P>
             * Remove any existing 'children' of the given 'parent'
             * <P>
             * Add this new element as a 'child' of the given 'parent'
             */
            var ctrlElement = ngModule
                .element( '<div class="aw-jswidgets-propertyVal" ng-controller="awPropertyController"/>' );

            ctrlElement.html( innerHtml );

            $( parentElement ).empty();
            $( parentElement ).append( ctrlElement );

            var ctrlFn = awInclude( parentElement, ctrlElement );

            if( ctrlFn ) {
                ctrlFn.setData( cellData );
            }
        };

        /**
         * Initialize ('bootstrap') the angular system and create an angular controller on a new 'child' of the given
         * 'parent' element.
         *
         * @param {Element} parentElement - The DOM element the controller and 'inner' HTML content will be added to.
         *            <P>
         *            Note: All existing 'child' elements of this 'parent' will be removed.
         *
         * @param {String} innerHtml - String that defines the exact HTML content that will be added to the 'parent'
         *            element.
         *
         * @param {Object} cellData - Arbitrary object to be set as the primary 'scope' of the new angular controller.
         *            <P>
         *            Note: This object will have the 'rootScopeElement' property set on this object with the new
         *            AngularJS Element created to hold the compiled given 'innerHtml' and attached as a child to the
         *            given 'parentElement'.
         *
         * @return {Void}
         */
        exports.insertNgProp = function( parentElement, innerHtml, cellData ) {
            /**
             * Create an 'outer' <DIV> (to hold the given 'inner' HTML) and create the angular controller on it.
             * <P>
             * Remove any existing 'children' of the given 'parent'
             * <P>
             * Add this new element as a 'child' of the given 'parent'
             */
            var ctrlElement = ngModule.element( '<div class="aw-jswidgets-property" />' );

            ctrlElement.html( innerHtml );

            $( parentElement ).empty();
            $( parentElement ).append( ctrlElement );

            awInclude( parentElement, ctrlElement );

            // /**
            // * Note: We do not want to set data on this 'child' element since we want that data to be inherited from its
            // * parent. The following line is kept for reference since the 'parent' insert code looks so similar this
            // * might be mistaken as a bug.
            // */
            // if (ctrlFn) {
            //    ctrlFn.setData(cellData);
            // }
        };

        /**
         * Update error property of the related controller.
         *
         * @param {DOMElement} parentElement - The element above the element the controller was created on.
         *
         * @param {NativeGenericViewModelProperty} uiProperty - UI Property Overlay object that will be updated in the context of
         *            the scope,
         *
         * @param {Object} error - boolean flag to isRequired.
         *
         * @return {Void}
         */
        exports.setError = function( parentElement, uiProperty, error ) {

            var ctrlElement = null;
            var ngScope = null;

            if( parentElement ) {
                ctrlElement = ngModule.element( parentElement.querySelector( '.aw-jswidgets-propertyVal' ) );
            }
            if( ctrlElement !== null ) {
                ngScope = ngModule.element( ctrlElement ).scope();
            }
            if( ngScope !== null && ngScope !== undefined ) {
                ngScope.$evalAsync( function() {
                    var errors = ngModule.element( parentElement ).find( 'aw-property-error' );
                    if( error !== "" && errors.length > 0 ) {
                        var alreadySet = false;
                        errors.each( function() {
                            if( ngModule.element( this ).scope().errorApi.errorMsg === error ) {
                                alreadySet = true;
                            }
                        } );
                        if( !alreadySet ) {
                            ngModule.element( errors ).scope().errorApi.errorMsg = error;
                        }
                    } else if( ngModule.element( errors ).scope() ) {
                        ngModule.element( errors ).scope().errorApi.errorMsg = error;
                    }
                } );
            }
        };

        /**
         * Retrieves directive template based on the type and hint provided.
         *
         * @param {String} prop - property overlay
         * @param {String} hint - property rendering hint
         *
         * @return {String} Returns directive template
         */
        exports.getTemplateBasedOnType = function( prop, hint  ) {
            var innerHtml = '';
            switch( prop.type ) {
                case "STRING":
                    if( hint === "password" ) {
                        prop.inputType = hint;
                    }
                    innerHtml = '<aw-property-string-val prop="prop"/>';
                    break;

                case "STRINGARRAY":
                    innerHtml = '<aw-property-string-val prop="prop"/>';
                    break;

                case "OBJECT":
                case "OBJECTARRAY":
                    innerHtml = '<aw-property-object-val prop="prop"/>';
                    break;

                case "DATE":
                case "DATEARRAY":
                    innerHtml = '<aw-property-date-time-val prop="prop"/>';
                    break;

                case "INTEGER":
                case "DOUBLE":
                case "INTEGERARRAY":
                case "DOUBLEARRAY":
                    innerHtml = '<aw-property-numeric-val prop="prop"/>';
                    break;

                case "BOOLEAN":
                case "BOOLEANARRAY":
                    switch( hint ) {
                        case "radiobutton":
                            innerHtml = '<aw-property-radio-button-val prop="prop"/>';
                            break;

                        case "togglebutton":
                            innerHtml = '<aw-property-toggle-button-val prop="prop"/>';
                            break;

                        default:
                            innerHtml = '<aw-property-checkbox-val prop="prop"/>';
                            break;
                    }
                    break;

                default:
                    innerHtml = '<aw-property-non-edit-val prop="prop"/>';
                    break;
            }

            return innerHtml;
        };

        /**
         * Set initialize property of the related controller.
         *
         * @param {Boolean} isEditable - boolean flag to isEditable.
         *
         * @param {Element} jqParentElement - The element above the element the controller was created on.
         *
         * @param {Element} element - The element above the element the controller was created on.
         *
         * @param {Object } cellData - ...
         *
         * @return {Void}
         */
        exports.includePropertyValue = function( isEditable, jqParentElement, element, cellData ) {
            var previousScopeElement = '';
            var innerHtml = '<aw-property-non-edit-val prop="prop"/>';
            var propertyContainer = $( element ).closest( '.aw-widgets-propertyContainer' );

            if( cellData.isArray ) {
                innerHtml = '<aw-property-non-edit-array-val prop="prop"/>';
            }

            // non editable case
            if( !isEditable || cellData.renderingHint === "label" ) {
                innerHtml = '<aw-property-non-edit-val prop="prop"/>';

                if( cellData.isArray ) {
                    innerHtml = '<aw-property-non-edit-array-val prop="prop"/>';
                }

                previousScopeElement = $( element ).find( '.aw-jswidgets-property' );
                if( cellData.propertyLabelDisplay === "PROPERTY_LABEL_AT_TOP" ) {
                    if( !propertyContainer.hasClass( 'aw-layout-flexColumn' ) ) {
                        propertyContainer.addClass( 'aw-layout-flexColumn' );
                    }
                    if( propertyContainer.hasClass( ' aw-layout-flexRow' ) ) {
                        propertyContainer.removeClass( 'aw-layout-flexRow' );
                    }
                } else {
                    if( propertyContainer.hasClass( 'aw-layout-flexColumn' ) ) {
                        propertyContainer.removeClass( 'aw-layout-flexColumn' );
                    }
                    if( !propertyContainer.hasClass( 'aw-layout-flexRow' ) ) {
                        propertyContainer.addClass( 'aw-layout-flexRow' );
                    }
                }
            } else {
                // edit case
                if( cellData.editLayoutSide ) {
                    //override for cases where edit property is horizontal
                    if( propertyContainer.hasClass( 'aw-layout-flexColumn' ) ) {
                        propertyContainer.removeClass( 'aw-layout-flexColumn' );
                    }
                    if( !propertyContainer.hasClass( 'aw-layout-flexRow' ) ) {
                        propertyContainer.addClass( 'aw-layout-flexRow' );
                    }
                } else {
                    if( !propertyContainer.hasClass( 'aw-layout-flexColumn' ) ) {
                        propertyContainer.addClass( 'aw-layout-flexColumn' );
                    }
                    if( propertyContainer.hasClass( 'aw-layout-flexRow' ) ) {
                        propertyContainer.removeClass( 'aw-layout-flexRow' );
                    }
                }

                previousScopeElement = $( element ).find( '.aw-widgets-propertyNonEditValue' );

                var renderingHint = null;
                if( cellData.renderingHint ) {
                    renderingHint = cellData.renderingHint;
                } else if( cellData.hint ) {
                    renderingHint = cellData.hint;
                }

                if( cellData.isArray ) {
                    innerHtml = '<aw-property-array-val prop="prop"/>';
                } else {
                    innerHtml = exports.getTemplateBasedOnType( cellData, renderingHint );
                }
            }
            // destroying scope of previous element
            if( previousScopeElement ) {
                var contrScope = previousScopeElement.scope();
                if( contrScope ) {
                    contrScope.$destroy();
                    previousScopeElement.remove();
                }
            }
            exports.insertNgProp( jqParentElement, innerHtml, cellData );
        };

         /**
         * Set initialize property of the related controller.
         *
         * @param {Element} jqParentElement - The element above the element the controller was created on.
         *
         * @param {Element} element - The element above the element the controller was created on.
         *
         * @param {Object } cellData - ...
         *
         * @return {Void}
         */
        exports.includeArrayPropertyValue = function( jqParentElement, element, cellData ) {
            var previousScopeElement = '';
            var renderingHint = null;

            if( cellData.renderingHint ) {
                renderingHint = cellData.renderingHint;
            } else if( cellData.hint ) {
                renderingHint = cellData.hint;
            }

            previousScopeElement = $( element ).find( '.aw-jswidgets-property' );
            var innerHtml = exports.getTemplateBasedOnType( cellData, renderingHint );

            // destroying scope of previous element
            if( previousScopeElement ) {
                var contrScope = previousScopeElement.scope();
                if( contrScope ) {
                    contrScope.$destroy();
                    previousScopeElement.remove();
                }
            }
            exports.insertNgProp( jqParentElement, innerHtml, cellData );
        };

        /**
         * @param {Element} parentElement - The DOM element to retrieve scope.
         *
         * @return TRUE if the 'first child' of the given 'parent' element has currently
         */
        exports.hasScope = function( parentElement ) {
            if( parentElement && parentElement.firstChild ) {
                var contrScope = ngModule.element( parentElement.firstChild ).scope();
                if( contrScope && !contrScope.$$destroyed ) {
                    return true;
                }
            }

            return false;
        };

        /**
         * Called when the hosting GWT PropertyWidget is 'unLoaded'. This method will call $destroy on the AngularJS
         * 'scope' associated with the property container's ng-controller.
         * <P>
         * Note: *** No further use of this controller is allowed (or wise) ***
         *
         * @param {Element} parentElement - The DOM element to retrieve scope.
         *
         * @return {Void}
         */
        exports.destroyPropertyScope = function( parentElement ) {
            if( parentElement && parentElement.firstChild ) {
                var contrScope = ngModule.element( parentElement.firstChild ).scope();
                if( contrScope ) {
                    contrScope.$destroy();
                }
            }
        };

        // data context getter functions...
        var getIsRichText = function() {
            return this.nativeProp.propertyDescriptor.constantsMap[ 'Fnd0RichText' ];
        };

        var getType = function() {
            var type;
            switch( this.nativeProp.propertyDescriptor.propertyType ) {
                case 2:
                    type = 'OBJECT';
                    break;
                default:
                    type = 'STRING';
            }
            return type;
        };

        var getUiValue = function() {
            if( this.nativeProp.uiValues ) {
                return this.nativeProp.uiValues.join( ', ' );
            }
        };

        var getDbValue = function() {
            if( this.nativeProp.dbValues ) {
                return this.nativeProp.dbValues.join( ', ' );
            }
        };

        var getIsNull = function() {
            return this.nativeProp.uiValues ? false : true;
        };

        //  TODO - remove for later Phase 1 UIGrid migration testing
        var longString = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris volutpat nec dolor id" +
            " ornare. Donec venenatis arcu lacus, quis tincidunt mauris dignissim sit amet. Mauris tempus luctus " +
            "congue. Quisque velit lacus, faucibus eget lacus et, pellentesque rhoncus turpis. Donec condimentum " +
            "dignissim fringilla. Nulla at pretium ipsum. Etiam nisl arcu, mattis non condimentum ac, finibus id " +
            "urna. Mauris ac lectus porta metus placerat posuere. Donec vehicula eget purus eget commodo. Ut " +
            "suscipit ex eget libero hendrerit efficitur. Nam elementum rhoncus sollicitudin. Phasellus fermentum " +
            "neque nisl, a interdum quam dictum a.";

        /**
        * Constructor for a JS data context Object.
        * We create an entityDC and attach it the parent. The eDC then contains all of the propDCs which are
        * used to hold the Teamcenter prop, propDesc, and view state for
        * HtmlPanel/AngularJS data binding used by Universal Widgets.
        *
        * The propDC is the 3.1 replacement for the UICellValueOverlayJS.
        *
        * @constructor createDCJS

        * <P>
        *
        * @param {Object} parentVM - parent view-model - represents the object
        * @param {String} uid - unique id
        * @param {Object} mo - model object data
        *
        * @return {Void}
        */
        exports.createDCJS = function( parentVM, uid, mo ) {
            parentVM.entityDC = {
                "uid": uid,
                "isSelected": false,
                "propDCs": {}
            };

            if( mo && mo.props ) {
                for( var name in mo.props ) {
                    var prop = mo.props[ name ];

                    var propDC = {
                        "name": name,
                        "autofocus": "",
                        "editLayoutSide": "",
                        "error": "",
                        "isEditing": false,
                        "renderingHint": "",
                        "lovApi": {},
                        "propApi": {},
                        "nativeProp": prop,
                        "staticType": prop.propertyDescriptor.propertyType,
                        "whatAmI": "propDC"
                    };

                    // move these prop defs to a prototype?
                    Object.defineProperty( propDC, 'type', {
                        get: getType
                    } );

                    Object.defineProperty( propDC, 'isRichText', {
                        get: getIsRichText
                    } );

                    // temp - put lorem ipsum long text in description Phase 1 UIGrid migration testing
                    // if( name === "object_desc" ) {
                        // Object.defineProperty( propDC, 'uiValue', {
                            // get: function() {
                                // return longString;
                            // }
                        // } );
                    // } else {
                        // Object.defineProperty( propDC, 'uiValue', {
                            // get: getUiValue
                        // } );
                    // }
                    Object.defineProperty( propDC, 'uiValue', {
                        get: getUiValue
                    } );

                    Object.defineProperty( propDC, 'isNull', {
                        get: getIsNull
                    } );

                    Object.defineProperty( propDC, 'dbValue', {
                        get: getDbValue
                    } );

                    parentVM.entityDC.propDCs[ name ] = propDC;
                }
            }
        };

        return exports;
        // End RequireJS Define
    } );
