//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 awInclude,
 define,
 requirejs,
 window
 */

/**
 * @module js/NgHtmlPanel
 */
define( [ 'app', 'angular', 'jquery', 'js/logService', 'js/NgProperty' ], function( app, ngModule, $, logSvc,
    propertyModule ) {
    'use strict';

    /**
     * Defines the htmlPanel controller.
     *
     * @constructor awHtmlPanelController
     * @memberof NgControllers
     *
     * @param {Object} $scope - The 'scope' all controller level values are defined on.
     * @param {Element} $element - DOM element the controller is attached to.
     *
     * @return {Void}
     */
    app.controller( 'awHtmlPanelController', [ '$scope', '$element', function( $scope, $element ) {
        // Define the panel controller
        var self = this;

        $scope.validURL = {};
        $scope.modifiable = true;
        $scope.newValue = {};

        /**
         * @memberof NgControllers.awHtmlPanelController
         *
         * @param {Object} dataObject - Object containing the currently selected {ModelObject} and session
         *            {ModelObject}.
         *
         * @return {Void}
         */
        self.setData = function( dataObject ) {
            $scope.$evalAsync( function() {
                $scope.selected = dataObject.selected;
                $scope.session = dataObject.session;
            } );
        };

        /**
         * *** Important Debug Output *** Please keep this block (even if it's commented out)
         *
         * @return {Void}
         */
        $scope.$on( '$destroy', function() {
            $scope.validURL = null;
            $scope.newValue = null;
            $scope.selected = null;
            $scope.session = null;
            $scope.$$watchers = null;

            $element.remove();

            if( app.isDebugEnabled ) {
                logSvc.info( 'awHtmlPanelController: Destroy $scope=' + $scope.$id );
            }

        } );
    } ] );

    /**
     * Defines the controller for <aw-property> directives in an HtmlPanel.
     *
     * @constructor awHtmlPanelPropertyController
     *
     * @memberof NgControllers
     *
     * @param {Object} $scope - The 'scope' all controller level values are defined on.
     * @param {Object} $attrs - Object containing the attributes of the DOM element this controller is being attached
     *            to.
     * @param {Element} $element - DOM Element of this controller is being attached to.
     * @param {dateTimeService} dateTimeSvc -
     * @param {localeService} localeSvc
     *
     * @return {Void}
     */
    app.controller( 'awHtmlPanelPropertyController', [
        '$scope',
        '$attrs',
        '$element',
        'dateTimeService',
        'localeService',
        function( $scope, $attrs, $element, dateTimeSvc, localeSvc ) {

            // /**
            //  * *** Important Debug Output *** Please keep this block (even if it's commented out)
            //  */
            // if (app.isDebugEnabled) {
            //     if ($scope.prop) {
            //         logSvc.info('awHtmlPanelPropertyController: Create $scope=' + //
            //             $scope.$id + ' type=' + $scope.prop.type + ' name=' + $scope.prop.name);
            //     } else {
            //         logSvc.info('awHtmlPanelPropertyController: Create $scope=' + //
            //             $scope.$id + ' type=' + 'no prop');
            //     }
            // }

            if( !$scope.prop ) {
                // this shouldn't happen, but better to catch it here
                console
                    .log( "awHtmlPanelPropertyController: " + //
                    "$scope.prop is undefined...Unable to bind to aw-property prop=" + $attrs.prop + " scope=" +
                        $scope.$id );
                return;
            }

            /**
             * Setup localized 'dateValue' & 'timeValue' text based on the current 'dbValue' Date Object.
             */
            if( $scope.prop.type === "DATE" && $scope.prop.dateApi ) {
                $scope.prop.dateApi.dateValue = dateTimeSvc.formatDate( $scope.prop.dbValue );
                $scope.prop.dateApi.timeValue = dateTimeSvc.formatTime( $scope.prop.dbValue );
            }

            if( $scope.prop.type === "BOOLEAN" || $scope.prop.type === "BOOLEANARRAY" ) {
                localeSvc.getTextPromise().then( function( localTextBundle ) {
                    $scope.prop.propertyRadioTrueText = localTextBundle.RADIO_TRUE;
                    $scope.prop.propertyRadioFalseText = localTextBundle.RADIO_FALSE;

                    /**
                     * Handles setting of custom labels and vertical alignment attributes when directives are used
                     * natively
                     */
                    if( $scope.prop.radioBtnApi && $scope.prop.radioBtnApi.customTrueLabel ) {
                        $scope.prop.propertyRadioTrueText = $scope.prop.radioBtnApi.customTrueLabel;
                    }

                    if( $scope.prop.radioBtnApi && $scope.prop.radioBtnApi.customFalseLabel ) {
                        $scope.prop.propertyRadioFalseText = $scope.prop.radioBtnApi.customFalseLabel;
                    }

                    if( $scope.prop.radioBtnApi && $scope.prop.radioBtnApi.vertical ) {
                        $scope.prop.vertical = $scope.prop.radioBtnApi.vertical;
                    }
                } );
            }

            if( $scope.prop.type === "STRING" || $scope.prop.type === "STRINGARRAY" ) {
                $scope.prop.inputType = "text";
            }

            /**
             * Called by various templates to delegate an ng-change directive.
             *
             * @memberof NgControllers.awHtmlPanelPropertyController
             *
             * @return {Void}
             */
            $scope.changeFunction = function() {
                var uiProperty = $scope.prop;
                var type = uiProperty.type;

                if( type === "DATE" || type === "DATEARRAY" ) {
                    uiProperty.dbValue = new Date( uiProperty.dateApi.dateValue );
                    uiProperty.dateApi.dateObject = new Date( uiProperty.dateApi.dateValue );
                }

                app.vmPropSvc.updateViewModelProperty( uiProperty );
            };

            /**
             * @memberof NgControllers.awHtmlPanelPropertyController
             *
             * @param {Number} index -
             *
             * @return {Void}
             */
            $scope.onClick = function( index ) {
                $scope.newValue = $scope.prop.displayValues[index];
            };

            /**
             * @memberof NgControllers.awHtmlPanelPropertyController
             *
             * @param {Number} index -
             *
             * @return {Void}
             */
            $scope.onRemove = function( index ) {
                $scope.prop.displayValues.splice( index, 1 );
                $scope.prop.dbValue.splice( index, 1 );
                $scope.changeFunction();
            };

            $scope.mySorted = $scope.$on( 'my-sorted', function( ev, val ) {
                $scope.prop.displayValues.splice( val.to, 0, $scope.prop.displayValues.splice( val.from, 1 )[0] );
                $scope.prop.dbValue.splice( val.to, 0, $scope.prop.dbValue.splice( val.from, 1 )[0] );
                $scope.changeFunction();
            } );

            /**
             * @memberof NgControllers.awHtmlPanelPropertyController
             *
             * @return {Void}
             */
            $scope.addValue = function() {
                $scope.prop.displayValues.push( $scope.prop.newValue );
                if( $scope.prop.type === "DATEARRAY" ) {
                    $scope.prop.dbValue.push( new Date( $scope.prop.newValue ) );
                } else {
                    $scope.prop.dbValue.push( $scope.prop.newValue );
                }

                $scope.prop.newValue = "";

                $scope.changeFunction();
            };

            $scope.$on( '$destroy', function() {

                // /**
                //  * *** Important Debug Output *** Please keep this block (even if it's commented out)
                //  */
                // if (app.isDebugEnabled) {
                //     if ($scope.prop) {
                //         logSvc.info('awHtmlPanelPropertyController: Destroy $scope=' + //
                //             $scope.$id + ' type=' + $scope.prop.type + ' name=' + $scope.prop.name);
                //     } else {
                //         logSvc.info('awHtmlPanelPropertyController: Destroy $scope=' + //
                //             $scope.$id + ' type=' + 'no prop');
                //     }
                // }

                // Destroying all watch listeners
                if( $scope.mySorted ) {
                    $scope.mySorted();
                }

                $element.remove();
            } );
        } ] );

    /**
     * Definition for the (aw-property) directive.
     *
     * @member aw-property
     * @memberof NgElementDirectives
     *
     * @return {Void}
     */
    app.directive( 'awProperty', function() {
        return {
            restrict: 'E',
            scope: {
                prop: '=',
                hint: '@'
            },
            controller: 'awHtmlPanelPropertyController',
            templateUrl: app.getBaseUrlPath() + '/html/NgAwProperty.html'
        };
    } );

    /**
     * Definition for the (aw-sortable) directive
     *
     * @member aw-sortable
     * @memberof NgAttributeDirectives
     *
     * @return {Void}
     */
    app.directive( 'awSortable', function() {
        return {
            restrict: 'A',
            link: function( scope, $element, attrs ) {
                $element.sortable( {
                    revert: true,
                    handle: 'button',
                    cancel: ''
                } );
                $element.disableSelection();
                $element.on( "sortdeactivate", function( event, ui ) {
                    var from = ngModule.element( ui.item ).scope().$index;
                    var to = $element.children().index( ui.item );
                    if( to >= 0 ) {
                        scope.$apply( function() {
                            if( from >= 0 ) {
                                scope.$emit( 'my-sorted', {
                                    from: from,
                                    to: to
                                } );
                            }
                        } );
                    }
                } );
            }
        };
    } );

    /**
     * Defines the directive used to include an iframe within the HTML and use binding to build the URL to be used as
     * its source.
     *
     * @member aw-frame
     * @memberof NgElementDirectives
     *
     * @param {AngularService} $sce -
     *
     * @return {Void}
     */
    app.directive( 'awFrame', [ '$sce', function( $sce ) {
        return {
            restrict: 'E',
            scope: {
                // 'url' is defined as an attribute on this directive's html tag
                url: '@'
            },
            templateUrl: app.getBaseUrlPath() + '/html/NgAwFrame.html',
            link: function( scope, $element, attrs ) {
                scope.validURL = $sce.trustAsResourceUrl( scope.url );
            }
        };
    } ] );

    var exports = {};

    /**
     * Initialize ('bootstrap') the angular system and create an angular controller on a new 'child' of the given
     * 'parent' element.
     *
     * @param {Element} parentElement - The DOM element the controller and 'inner' HTML content will be added to.
     *            <P>
     *            Note: All existing 'child' elements of this 'parent' will be removed.
     *
     * @param {String} innerHtml - String that defines the exact HTML content that will be added to the 'parent'
     *            element.
     *
     * @param {String} depModule - Relative path to a JavaScrict module resource to be loaded before the contents of the
     *            'innerHtml' have been added to the 'parent' element. If this module exports any object (e.g. with API
     *            or data), that object will be added as the 'depModule' property to the '$scope' object. This object is
     *            passed to the 'setData' method on the new 'awHtmlPanelController'. This controller is added as a
     *            'child' element to the 'parent'.
     *
     * @param {Object} jsObject - Arbitrary object to be set as the primary 'scope' (i.e. 'context') of the new
     *            AngularJS controller.
     *
     * @return {Void}
     */
    exports.insertPanel = function( parentElement, innerHtml, depModule, jsObject ) {
        /**
         * Create an 'outer' <DIV> (to hold the given 'inner' HTML) and create the angular controller on it.
         * <P>
         * Remove any existing 'children' of the given 'parent'
         * <P>
         * Add this new element as a 'child' of the given 'parent'
         */
        var ctrlElement = ngModule
            .element( '<div class="aw-jswidgets-htmlPanel" ng-controller="awHtmlPanelController"/>' );

        ctrlElement.html( innerHtml );

        $( parentElement ).empty();
        $( parentElement ).append( ctrlElement );

        /**
         * Check if we are being asked to load a dependent module before we actually include the HTML into the DOM using
         * AngularJS' compile feature.<BR>
         * If so: Load the module and then 'include' the contents.<BR>
         * If not: Immediately 'include' the contents.
         */
        if( depModule && depModule.length > 0 ) {
            requirejs( [ depModule ], function( depModule2 ) {
                var contrFn = awInclude( parentElement, ctrlElement );

                if( contrFn ) {
                    /**
                     * Check if the dependent module exported something.<BR>
                     * If so: Pass that along as a 'decoration' to the given (or locally new) $scope object.
                     */
                    if( depModule2 ) {
                        var jsObjectFinal = jsObject;
                        if( !jsObjectFinal ) {
                            jsObjectFinal = {};
                        }

                        jsObjectFinal.depModule = depModule2;
                    }

                    contrFn.setData( jsObject );
                }
            } );
        } else {
            var contrFn = awInclude( parentElement, ctrlElement );

            if( contrFn ) {
                contrFn.setData( jsObject );
            }
        }
    };

    /**
     * Update the 'scope' object of the related controller.
     *
     * @param {Element} parentElement - The element above the element the controller was created on.
     *
     * @param {UIPropertyOverlayJS} uiProperty - UI Property Overlay object that will be updated in the context of the
     *            scope,
     *
     * @param {Boolean} isEditable - TRUE if the property is currently read-write. FALSE if it is read-only.
     *
     * @param {Boolean} isEnabled - TRUE if the property is currently enabled. FALSE is disabled.
     *
     * @param {Boolean} isRequired - TRUE if the property is required
     *
     * @param {String} error - Message string for any current error associated with this property.
     *
     * @param {Object} dbValue - Value of the property used internally for storage in the database.
     *
     * @param {StringArray} displayValues - String(s) defining the new display values for the given uiProperty.
     *
     * @return {Void}
     */
    exports.updateViewProperty = function( parentElement, uiProperty, isEditable, isEnabled, isRequired, error,
        dbValue, displayValues ) {
        var ctrlElement = ngModule.element( parentElement.querySelector( '.aw-jswidgets-htmlPanel' ) );

        if( ctrlElement ) {
            var ngScope = ngModule.element( ctrlElement ).scope();
            if( ngScope ) {
                ngScope.$evalAsync( function() {
                    uiProperty.isEditable = isEditable;
                    uiProperty.isEnabled = isEnabled;
                    uiProperty.isRequired = isRequired;
                    uiProperty.error = error;

                    uiProperty.displayValues = displayValues;

                    if( !uiProperty.isNull ) {
                        if( displayValues.length === 0 ) {
                            uiProperty.isNull = true;
                        }
                    } else {
                        if( dbValue ) {
                            uiProperty.isNull = false;
                        }
                    }

                    if( uiProperty.isArray ) {
                        uiProperty.dbValues = dbValue;
                        uiProperty.displayValsModel = [];

                        for( var i = 0; i < displayValues.length; i++ ) {
                            uiProperty.displayValsModel.push( {
                                displayValue: displayValues[ i ],
                                selected: false
                            } );
                        }
                    } else {
                        uiProperty.uiValue = displayValues.join( ', ' );
                        uiProperty.dbValue = dbValue;
                    }

                    /**
                     * Check if we are turning edit 'off' AND there is currently an error on this property.<BR>
                     * If so: Clear the error message now.
                     */
                    if( !isEditable && uiProperty.error ) {
                        uiProperty.error = null;
                    }
                } );
            }
        } else {
            logSvc.error( "Unable to relocate angular controller on 'parent' element" );
        }
    };

    /**
     * Called when the hosting GWT XRTHtmlPanelView is 'hidden'. This method will call $destroy on the AngularJS 'scope'
     * associated with the ng-controller.
     * <P>
     * Note: *** No further use of this controller is allowed (or wise) ***
     *
     * @param {Element} parentElement - The element above the element the controller was created on.
     */
    exports.unLoadHtmlPanel = function( parentElement ) {
        var ctrlElement = ngModule.element( parentElement.querySelector( '.aw-jswidgets-htmlPanel' ) );

        if( ctrlElement ) {
            var ngScope = ngModule.element( ctrlElement ).scope();

            if( ngScope ) {
                ngScope.$destroy();
            }
        }
    };

    /**
     * Update editLayoutSide property of the related controller.
     *
     * @param {Element} parentElement - The element above the element the controller was created on.
     *
     * @param {UIPropertyOverlayJS} uiProperty - UI Property Overlay object that will be updated in the context of
     *            the scope,
     *
     * @param {boolean} editLayoutSide -Boolean value of property editLayoutSide.
     *
     * @return {Void}
     */
    exports.setEditLayoutSide = function( parentElement, uiProperty, editLayoutSide ) {
        var ctrlElement = ngModule.element( parentElement.querySelector( '.aw-jswidgets-htmlPanel' ) );

        if( ctrlElement !== null ) {
            var ngScope = ngModule.element( ctrlElement ).scope();

            if( ngScope !== null && ngScope !== undefined ) {
                ngScope.$evalAsync( function() {
                    uiProperty.editLayoutSide = editLayoutSide;
                } );
            }

        } else {
            console.log( "Unable to relocate angular controller on 'parent' element" );
        }
    };

    exports.propertyModule = propertyModule;

    return exports;

    // End RequireJS Define
} );
