// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 document,
 requirejs,
 window
 */

var agentStr = navigator.userAgent;
console.debug( agentStr );
var oldIE = false;
if( agentStr.search( /Trident/ ) > -1 ) {
    oldIE = agentStr.search( /MSIE (2|3|4|5|6|7|8|9|10)./ ) > -1 && agentStr.search( /Trident\/[1-6]\./ ) > -1;
} else {
    oldIE = agentStr.search( /MSIE (2|3|4|5|6|7|8|9|10)./ ) > -1;
}
var oldChrome = agentStr.search( /Chrome\/([1-9]|1[0-9]|2[0-8])\./ ) > -1;
var oldFirefox = agentStr.search( /Firefox\/([1-9]|1[0-9]|2[0-7])\./ ) > -1;
if( oldIE || oldChrome || oldFirefox ) {
    console.error( 'Unsupported browser. Please upgrade.' );
    window.location.replace( 'unsupported.html' );
}

/**
 * Global cached reference to the NG App (as supplied by RequireJS module loading).
 *
 * @private
 */
var _app;

/**
 * Base URL directory path.
 *
 * @private
 */
var baseUrlPath = 'assets';

/**
 *
 * @module js/bootstrap
 */
requirejs.config( {
    baseUrl: baseUrlPath,
    waitSeconds: 0,
    paths: {
        'angular': 'lib/angularjs-1.3.15/angularjs.min',
        'angulartemplatecache': 'js/angulartemplatecache',
        'app': 'js/app',
        'assert': 'js/adapters/angularjs/assert',
        'chalk': 'js/adapters/angularjs/chalk',
        'ckeditor': 'lib/ckeditor/ckeditor',
        'fmsService': 'js/adapters/angularjs/fmsService',
        'gwt': '../thinclient/thinclient.nocache',
        'fs': 'js/adapters/angularjs/fs',
        'hammer': 'lib/hammer-2.0.4/hammer.min',
        'highcharts': 'lib/highcharts/highcharts-4.2.3.min',
        'hostInterop': 'lib/host_integration/hostInterop',
        'hostInfServiceConstants': 'lib/host_integration/IInfrastructureServiceConstants',
        'httpWrapper': 'js/adapters/angularjs/httpWrapper',
        'jquery': 'lib/jquery-2.1.4/jquery.min',
        'jquerymobile': 'lib/jquerymobile/jquery.mobile.custom.min',
        'jquerymousewheel': 'lib/MetroUILib/javascript/jquery.mousewheel.min',
        'jqueryui': 'lib/jqueryui-1.11.4/jqueryui.min',
        'jquerytouch': 'lib/jqueryui-touch-punch-0.2.3/jquery.ui.touch-punch.min',
        'lodash': 'lib/lodash-3.9.3/lodash.min',
        'noty': 'lib/noty/jquery.noty',
        'noty.customized': 'lib/noty/js/jquery.noty.customized',
        'postal': 'lib/postal-1.0.6/postal.min',
        'q': 'js/adapters/angularjs/q',
        'soa': 'js/soa',
        'soaSchema': 'js/soa/kernel/schema',
        'ui.grid': 'lib/uigrid/ui-grid.min',
        'diagramfoundation': 'lib/diagramfoundation'
    },
    shim: {
        'bootstrap': {
            deps: [ 'jquery', 'ui.grid' ]
        },
        'highcharts': {
            deps: [ 'jquery' ],
            exports: 'Highcharts'
        },
        'hostInterop': {
            exports: 'globalhostedInfo'
        },
        'noty': {
            deps: [ 'jquery' ]
        },
        'ui.grid': {
            deps: [ 'angular' ]
        },
        'noty.customized': {
            deps: [ 'noty' ]
        },
        'angular': {
            deps: [ 'jquery' ],
            exports: 'angular'
        },
        'jquerytouch': {
            deps: [ 'jqueryui' ]
        }
    }
} );

/**
 * Load the main application JS file and 'bootstrap' the AngularJS system on this page's document.
 */
requirejs( [ 'app', 'angular', 'jquery', 'lodash', 'soa/kernel/clientMetaModel', 'soa/kernel/clientDataModel',
    'soa/kernel/propertyPolicyService', 'js/dateTimeService', 'js/localeService', 'js/logService', 'js/iconService',
    'js/genericViewModelProperty', 'js/pasteService' ], function( app, ngModule, $, _ ) {
    'use strict';

    /**
     * Set the global '_app' variable to the 'app' module we just loaded.
     */
    _app = app;

    _app.setBaseUrlPath( baseUrlPath );
    /**
     * Allow access to 'JQuery' via '_app.$'.
     * <P>
     * Call the 'noConflict' method to avoid having the JQuery API we just loaded to not conflict with any other JQuery
     * loaded (or will be loaded) by any other client. This method has the effect of making the '$' global variable
     * 'undefined' if no other JQuery is loaded. The AW Client must only access JQuery via the global '_app' object.
     * <P>
     * Note: There are multiple 3rd party JS files that require the '$' to remain global, sp until those are addressed
     * we cannot use 'noConflict'.
     */
    _app.$ = $;
    // _app.$.noConflict();

    /**
     * Allow access to 'LodashJS' via '_app._'.
     * <P>
     * Call the 'noConflict' method to avoid having the LodashJS API we just loaded to not conflict with any other
     * LodashJS loaded (or will be loaded) by any other client. This method has the effect of making the '_' global
     * variable 'undefined' if no other LodashJS is loaded. The AW Client must only access LodashJS via the global
     * '_app' object.
     */
    _app._ = _;
    _app._.noConflict();

    _app.ngModule = ngModule;

    _app.ngModule.bootstrap( document, [ 'AwRootAppModule' ] );

    /**
     * TRUE if extra-deep debug listings should be see.
     * <P>
     * *** Please keep this block (even if it's commented out)
     */
    _app.isDebugEnabled = false;

    /**
     * Note: We need to 'get' the injected 'soa_kernel_clientDataModel' service (et al.) so that it can get all the
     * services it needs injected correctly.
     */
    var injector = _app.ngModule.element( document ).injector();

    _app.iconSvc = injector.get( 'iconService' );
    _app.cmm = injector.get( 'soa_kernel_clientMetaModel' );
    _app.cdm = injector.get( 'soa_kernel_clientDataModel' );
    _app.propPolicySvc = injector.get( 'soa_kernel_propertyPolicyService' );
    _app.vmPropSvc = injector.get( 'genericViewModelProperty' );
    _app.dateTimeSvc = injector.get( 'dateTimeService' );
    _app.localeSvc = injector.get( 'localeService' );
    _app.logSvc = injector.get( 'logService' );
    _app.pasteSvc = injector.get( 'pasteService' );

    /**
     * Global space map used to associate a given module name (actually a relative path to the module resource file) to
     * an AngularJS 'promise' used to manage asynchronous access to an instance of the module's object.
     *
     * @private
     */
    _app.mapModule2Defer = {};

    /**
     * Look for the 'locale' in the URL and if found extract the value from it.
     */
    var localeNdx = document.URL.search( '[?#]locale=' );

    if( localeNdx !== -1 ) {
        var query_string = {};
        var query = window.location.search.substring( 1 );
        var vars = query.split( "&" );
        for( var i = 0; i < vars.length; i++ ) {
            var pair = vars[i].split( "=" );
            // If first entry with this name
            if( typeof query_string[pair[0]] === "undefined" ) {
                query_string[pair[0]] = pair[1];
                // If second entry with this name
            } else if( typeof query_string[pair[0]] === "string" ) {
                var arr = [ query_string[pair[0]], pair[1] ];
                query_string[pair[0]] = arr;
                // If third or later entry with this name
            } else {
                query_string[pair[0]].push( pair[1] );
            }
        }

        if( query_string.locale ) {
            _app.localeInfo.locale = query_string.locale;
        }
    }

    /**
     * Check if we should simply assume the browser's current locale setting.
     */
    if( !_app.localeInfo.locale ) {
        _app.localeInfo.locale = window.navigator.userLanguage || window.navigator.language;
    }

    if( _app.isDebugEnabled ) {
        requirejs( [ 'js/debugHelper' ], function() {
            //
        } );
    }

    /**
     * Look for the 'hosting' flag in the URL. <BR>
     * If found: Requre the hostSupportService be loaded as well.
     */
    _app.hostSupportService = null;

    var hostNdx = document.URL.search( '[?#]ah=true' );

    if( hostNdx !== -1 ) {
        requirejs( [ 'soa/kernel/hostSupportService' ], function( hostSupportService ) {
            /**
             * Cache a reference to this module as a property in the global '_app' object.
             */
            _app.hostSupportService = hostSupportService;

            /**
             * Disable support for PointerEvents since HammerJS does not work correctly with a browser that is being
             * wrapped by a host (that does not pass along these type events).
             * <P>
             * Note: This code must be run BEFORE HammerJS is loaded since the event support flag is checked and set
             * during its loading phase (via a self executing function).
             * <P>
             * To maintain compatibility in a hosted RAC (et al.) using IE10+ we have to drop support for 'pointer'
             * event. This will cause only mouse events to be passed to the Hammer APIs. The SWT Browser cannot pass
             * pointer event along to the browser, only mouse events.
             * <P>
             * D-14536 - Hosting: Selection of AW items in RAC host is broken.
             */
            if( window.PointerEvent ) {
                delete window.PointerEvent;
            }
            if( window.webkitPointerEvent ) {
                delete window.webkitPointerEvent;
            }
            if( window.mozPointerEvent ) {
                delete window.mozPointerEvent;
            }
            if( window.MSPointerEvent ) {
                delete window.MSPointerEvent;
            }
            if( window.msPointerEvent ) {
                delete window.msPointerEvent;
            }
            if( window.oPointerEvent ) {
                delete window.oPointerEvent;
            }
        } );
    }

    /** is browser IE? */
    if( typeof navigator !== 'undefined' && navigator && navigator.userAgent ) {
        _app._isIE = navigator.userAgent.search( /(trident|edge)/i ) > -1;
    }

    _app.browserInstanceId = _.now().toString();

    /**
     * Add meta element for GWT locale specification. This must be after this script (bootstrap.js) but before the GWT
     * scripts are processed. Therefore, we're using the 'title' element for placement.
     */
    var meta = document.createElement( 'meta' );
    meta.name = 'gwt:property';
    meta.content = 'locale=' + _app.localeInfo.locale.replace( /-/g, '_' );
    $( 'title' ).before( meta );

    /**
     * Load GWT generated JS code now (and add more CSS links once it is loaded)
     */
    requirejs( [ 'gwt' ], function() {
        var injector = _app.ngModule.element( document ).injector();

        /**
         * Need to make sure these CSS files are included AFTER GWT is loaded (via require from 'app') so that their
         * contents will override some values loaded by GWT's (e.g. clean.css).
         */
        var link = document.createElement( 'link' );
        link.type = 'text/css';
        link.rel = 'stylesheet';
        link.href = _app.getBaseUrlPath() + '/main.css';
        $( 'head' ).append( link );
    } );
} );

/**
 * @param {Object} moduleName - A String with the name of the module the caller is interested in.
 *            <P>
 *            Note: The 'name' is actually a relative path to the module resource file.
 *
 * @return An AngularJS 'promise' to be used by the caller to gain access to the module's resources once they are
 *         loaded.
 */
function getModuleLoadPromise( moduleName ) {
    'use strict';

    /**
     * Check if we have NOT seen a request to load this module before.
     */
    var defer = _app.mapModule2Defer[moduleName];

    if( !defer ) {
        var injector = _app.ngModule.element( document ).injector();

        injector.invoke( [ '$q', function( $q ) {
            defer = $q.defer();

            requirejs( [ moduleName ], function() {
                if( arguments.length === 0 ) {
                    defer.resolve();
                } else if( arguments.length === 1 ) {
                    defer.resolve( arguments[0] );
                } else if( arguments.length > 1 ) {
                    var results = [];
                    for( var ndx = 0; ndx < arguments.length; ndx++ ) {
                        results.push( arguments[ndx] );
                    }
                    defer.resolve( results );
                }
            } );
        } ] );
    }

    return defer.promise;
}

/**
 * This function simulates the 'ng-include' directive and allows DOM elements created outside the AngularJS system to be
 * 'compiled' and hooked up into that system.
 *
 * @param {Element} parentElement - The DOM element above the 'ctrlElement' where the parent scope can be gotten from.
 *
 * @param {Element} ctrlElement - The DOM element containing the HTML tags defining a 'controller' to be 'compiled' into
 *            the AngularJS system.
 *
 * @return {Controller} Reference to the new AngularJS controller function that was created/compiled and set onto the
 *         given 'ctrlElement'.
 */
function awInclude( parentElement, ctrlElement ) {
    'use strict';

    try {
        var docNgElement = _app.ngModule.element( document.body );
        var parentNgElement = _app.ngModule.element( parentElement );
        var contrNgElement = _app.ngModule.element( ctrlElement );

        var parentScope = parentNgElement.scope();

        /**
         * Check if the parent scope does not exists OR it is the 'root' scope.<BR>
         * If so: Create a new child scope based on the document's scope.
         * <P>
         * Note: This can occur when the parentElement is part of a DOM tree that is not yet attached into the document
         * (i.e. it is still being built). Currently, when this happens there seems to a node with the class
         * 'locationPanel' at the top of the fragment. A new child scope of the document scope will be added to this
         * 'locationPanel' and used as the parent scope for the ctrlElement.
         * <P>
         * Note: We do not want to use the 'root' scope for inserting new elements into since it hass been shown to not
         * be the one the API is eventually added to (it will be a child of it anyway).
         */
        if( !parentScope || parentScope.$id === 1 ) {
            var docScope = docNgElement.scope();

            parentScope = docScope.$new();

            _app.$( '.locationPanel' ).data( '$scope', parentScope );
        }

        var ctrlScope = parentScope.$new();

        _app.$( ctrlElement ).data( '$scope', ctrlScope );

        var docInjector = docNgElement.injector();

        var compileFn = docInjector.get( '$compile' );

        if( compileFn ) {
            var compiledFn = compileFn( contrNgElement );

            ctrlScope = contrNgElement.scope();

            if( ctrlScope && compiledFn ) {
                compiledFn( ctrlScope );

                return contrNgElement.controller();
            }
        }

    } catch( e ) {
        _app.logSvc.error( e );
    }

    return null;
}