//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 awInclude
 */

/**
 * @module js/NgPropertyLovCb
 */
define(
    [ 'app', 'angular', 'jquery' ],
    function( app, ngModule, $ ) {
        "use strict";

        /**
         * @constructor CBLOVDataService
         *
         * @param {AngularService} $q -
         */
        var CBLOVDataService = function( $q ) {
            var self = this;

            /**
             * returns a promise to fetch initial lov vals
             * <P>
             * Note: The current implementation is a little different from other tc lov implementations.
             * <P>
             * filterStr isn't currently used here, it is always null. Typical tc impl would call for "initial" vals
             * everytime the filterStr changes - sometimes on every keystroke. In this impl, we only call initial once,
             * call next for subsequent vals, and do the filtering client side in ng. this will perform better in most
             * cases, but would be slow when filtering for a val towards the end of a long list
             * <P>
             * since this impl is focused on checkbox lovEntries and not intended for huge lists, this is fine and even
             * preferable, but if in future we want to use this logic more broadly, it will need some tweaking...
             * (really the getNext api should take a filter and have an allowance for a slightly smarter client, but
             * that's a separate discussion...)
             *
             * @memberof module:js/NgPropertyLovCb~CBLOVDataService
             *
             * @param cba
             * @param filterStr
             *
             * @returns {Promise}
             */
            self.promiseInitialValues = function( cba, filterStr ) {
                var deferred = $q.defer();

                // make server call via lov data provider interface
                cba.options.gwtGetInitialValues( filterStr, deferred );
                return deferred.promise;
            };

            /**
             * Returns a promise to fetch next lov vals
             *
             * @memberof module:js/NgPropertyLovCb~CBLOVDataService
             *
             * @param {Object} cba -
             *
             * @returns {Promise}
             */
            self.promiseNextValues = function( cba ) {
                var deferred = $q.defer();

                // make server call via lov data provider interface
                cba.options.gwtGetNextValues( deferred );
                return deferred.promise;
            };
        };

        /**
         * Register an instance of {@linkcode module:js/NgPropertyLovCb~CBLOVDataService|CBLOVDataService} with the
         * application module's service factory.
         *
         * @member CBLOVDataService
         * @memberof NgServices
         *
         * @param $q
         *
         * @returns {CBLOVDataService}
         */
        app.factory( 'CBLOVDataService', [ '$q', function( $q ) {
            return new CBLOVDataService( $q );
        } ] );

        /**
         * Directive to drive loading more values on scroll.
         *
         * @member aw-when-scrolled-cb
         * @memberof NgAttributeDirectives
         *
         * @returns {Object}
         */
        app.directive( 'awWhenScrolledCb', function() {
            return {
                restrict: "A",
                link: function( scope, $element, attrs ) {
                    var raw = $element[0];
                    $element.bind( 'scroll', function() {
                        if( raw.scrollTop + raw.offsetHeight >= raw.scrollHeight ) {
                            scope.$evalAsync( attrs.awWhenScrolledCb );
                        }
                    } );
                }
            };
        } );

        /**
         * controller for lovEntries
         *
         * @constructor awCheckboxLovController
         * @memberof NgControllers
         *
         * @param $scope
         * @param $q
         * @param CBLOVDataSvc
         *
         * @returns {Object}
         */
        app
            .controller(
                'awCheckboxLovController',
                [
                    '$scope',
                    '$q',
                    'CBLOVDataService', //
                    function( $scope, $q, CBLOVDataSvc ) {
                        // lov data will be held here
                        $scope.lovEntries = [];
                        $scope.expanded = false;
                        $scope.moreValuesExist = true;
                        $scope.lovInitialized = false;
                        $scope.prevFilteredCount = 0;
                        $scope.queueIdle = true;
                        $scope.dropPosition = "below";

                        /**
                         * Function to expand/collapse lov dropdown
                         *
                         * @memberof NgControllers.awCheckboxLovController
                         *
                         * @returns {Void}
                         */
                        $scope.toggleDropdown = function() {
                            // toggle expansion state
                            $scope.expanded = !$scope.expanded;

                            // is there room below? if not, set style to place cbaDrop above
                            var cbaParent = $scope.myCba.$parent.children()[0];
                            var spaceBelow = cbaParent.offsetParent.offsetHeight -
                                cbaParent.getBoundingClientRect().bottom;
                            $scope.dropPosition = ( spaceBelow < 150 ) ? "above" : "below";

                            // if first click, also fetch initial vals
                            if( $scope.moreValuesExist && !$scope.lovInitialized ) {
                                $scope.requestInitialLovEntries();
                            }

                            // if expanded, listen for click outside of control
                            if( $scope.expanded ) {
                                $( 'body' ).on( "click", $scope.collapseOnBlur );
                            } else {
                                $( 'body' ).off( "click", $scope.collapseOnBlur );
                            }
                        };

                        /**
                         * If click is outside of control, collapse
                         * <P>
                         * Note: ng-blur would be preferable, but it doesn't seem to work when ng isn't aware of the
                         * rest of the application
                         *
                         * @memberof NgControllers.awCheckboxLovController
                         *
                         * @param e
                         *
                         * @returns {Void}
                         */
                        $scope.collapseOnBlur = function( e ) {
                            var choiceElem = $scope.myCba.$parent.find( ".aw-jswidgets-cbaChoice" )[0];
                            var dropElem = $scope.myCba.$parent.find( ".aw-jswidgets-cbaDrop" )[0];
                            if( e.target === choiceElem ||
                                $( e.target ).parents( '.aw-jswidgets-cbaChoice' )[0] === choiceElem ) {
                                return;
                            }
                            if( ( e.target === dropElem || $( e.target ).parents( '.aw-jswidgets-cbaDrop' )[0] !== dropElem ) &&
                                $scope.expanded ) {
                                $scope.cbaCollapse();
                            }
                        };

                        /**
                         * Collapse the drop-down
                         *
                         * @memberof NgControllers.awCheckboxLovController
                         *
                         * @returns {Void}
                         */
                        $scope.cbaCollapse = function() {
                            $scope.expanded = false;
                            $scope.$apply();
                            $( 'body' ).off( 'click', $scope.collapseOnBlur );
                        };

                        /**
                         * @memberof NgControllers.awCheckboxLovController
                         *
                         * @return {String} Class name for showing or hiding the loading animation based on lov state
                         */
                        $scope.loadingClass = function() {
                            var loadingClass = "";
                            if( $scope.queueIdle ) {
                                loadingClass = "hidden";
                            }

                            if( $scope.filtered && $scope.filtered.length < 10 ) {
                                // if after filtering, we have less than 10 results, check for more
                                $scope.requestNextLovEntries();
                            }

                            return loadingClass;
                        };

                        /**
                         * @memberof NgControllers.awCheckboxLovController
                         *
                         * @return {String} Class name for filter field based on number of vals (show filter when we
                         *         have > 20 vals)
                         */
                        $scope.filterClass = function() {
                            var filterClass = "hidden";
                            if( $scope.lovEntries.length > 20 ) {
                                filterClass = "";
                            }
                            return filterClass;
                        };

                        /**
                         * Function to update the button text with selected values
                         *
                         * @memberof NgControllers.awCheckboxLovController
                         *
                         * @return {String} A comma separated string containing the 'aggregate' of all currently
                         *         selected items.
                         */
                        $scope.getDisplayVal = function() {
                            var displayValStr = "";
                            ngModule.forEach( $scope.lovEntries.concat( $scope.selectedPHolders ), function( lov ) {
                                if( lov.sel ) {
                                    displayValStr += displayValStr === "" ? "" : ", ";
                                    displayValStr += lov.propDisplayValue;
                                }
                            } );
                            return displayValStr;
                        };

                        /**
                         * Function to get the js object for the selected vals
                         *
                         * @memberof NgControllers.awCheckboxLovController
                         *
                         * @return {LOV[]} An array containing the LOV object of all currently selected items.
                         */
                        $scope.getSelVals = function() {
                            var jsonVals = [];

                            ngModule.forEach( $scope.lovEntries.concat( $scope.selectedPHolders ), function( lov ) {
                                if( lov.sel ) {
                                    jsonVals.push( lov );
                                }
                            } );
                            return jsonVals;
                        };

                        /**
                         * Get the initial vals
                         *
                         * @memberof NgControllers.awCheckboxLovController
                         *
                         * @returns {Void}
                         */
                        $scope.requestInitialLovEntries = function() {
                            var filterStr = $scope.search ? $scope.search.propDisplayValue : "";
                            $scope.queueIdle = false;
                            $scope.lovInitialized = true;
                            CBLOVDataSvc.promiseInitialValues( $scope.myCba, filterStr ).then(
                                $scope.processLovEntries, $scope.processError );
                        };

                        /**
                         * Get the next set of vals
                         *
                         * @memberof NgControllers.awCheckboxLovController
                         *
                         * @returns {Void}
                         */
                        $scope.requestNextLovEntries = function() {
                            // this can get called from multiple places.... which would be fine except that the fx
                            // implmentation
                            // will return duplicate values on sequential requests... therefore, throttle the requests
                            // here...
                            if( $scope.lovInitialized && $scope.moreValuesExist && $scope.queueIdle ) {
                                $scope.queueIdle = false;
                                CBLOVDataSvc.promiseNextValues( $scope.myCba ).then( $scope.processLovEntries,
                                    $scope.processError );
                            }
                        };

                        /**
                         * Take the updated place-holder object and apply it to the lov.
                         * <P>
                         * Make this available on the parent scope.
                         *
                         * @memberof NgControllers.awCheckboxLovController
                         *
                         * @returns {Void}
                         */
                        $scope.$parent.reinitLOV = function() {
                            for( var inx = 0; inx < $scope.lovEntries.length; inx++ ) {
                                // unselect all values
                                $scope.lovEntries[inx].sel = false;
                                for( var jnx = 0; jnx < $scope.selectedPHolders.length; jnx++ ) {
                                    if( $scope.selectedPHolders[jnx].propInternalValue === $scope.lovEntries[inx].propInternalValue ) {
                                        // if it's in the place-holder, remove it and mark as selected
                                        $scope.selectedPHolders.splice( jnx, 1 );
                                        $scope.lovEntries[inx].sel = true;
                                        break;
                                    }
                                }
                            }
                            $scope.$evalAsync();
                        };

                        /**
                         * @memberof NgControllers.awCheckboxLovController
                         *
                         * @param {ObjectArray} lovEntries - Array of LOV Entry objects returned from the SOA service.
                         *
                         * @returns {Void}
                         */
                        $scope.processLovEntries = function( lovEntries ) {
                            $scope.queueIdle = true;
                            if( lovEntries.length === 0 ) {
                                // we have all the vals now...
                                $scope.moreValuesExist = false;
                            }
                            ngModule
                                .forEach(
                                    lovEntries,
                                    function( lovEntry ) {
                                        // if the new lovEntry is in place-holder array, remove it
                                        if( lovEntry.sel ) {
                                            for( var inx = 0; inx < $scope.selectedPHolders.length; inx++ ) {
                                                if( $scope.selectedPHolders[inx].propInternalValue === lovEntry.propInternalValue ) {
                                                    $scope.selectedPHolders.splice( inx, 1 );
                                                    break;
                                                }
                                            }
                                        }
                                        // append new value to model
                                        $scope.lovEntries.push( lovEntry );
                                    } );

                            // if after filtering, we have less than 10 results or no new vals, check for more
                            var newFilteredCount = $scope.filtered.length;
                            if( newFilteredCount === $scope.prevFilteredCount ) {
                                $scope.requestNextLovEntries();
                            } else {
                                $scope.prevFilteredCount = newFilteredCount;
                            }
                        };

                        /**
                         * Call this if there is an error calling our service
                         *
                         * @memberof NgControllers.awCheckboxLovController
                         */
                        $scope.processError = function( reason ) {
                            // placeholder function. do nothing; error should already be handled.
                        };

                        /**
                         * Update the array vals in the gwt cdm
                         *
                         * @memberof NgControllers.awCheckboxLovController
                         */
                        $scope.updateArray = function() {
                            $scope.myCba.options.gwtUpdateArrayVals( $scope.getSelVals() );
                        };

                        /**
                         * *** Important Debug Output *** Please keep this block (even if it's commented out)
                         */
                        if( app.isDebugEnabled ) {
                            $scope.$on( '$destroy', function() {
                                console.log( 'awCheckboxLovController: Destroy $scope=' + $scope.$id );
                            } );
                        }
                    } ] );

        /**
         * List populated by ng-repeat from controller's lov data and progressively loaded via the data services.
         *
         * @member aw-checkbox-lov
         * @memberof NgElementDirectives
         *
         * @returns {Void}
         */
        app.directive( "awCheckboxLov", function() {
            return {
                restrict: "E",
                templateUrl: app.getBaseUrlPath() + '/html/NgAwCheckboxLov.html',
                controller: 'awCheckboxLovController'
            };
        } );

        var exports = {};

        exports.NgCheckboxLov = function() {
            // Nothing to do
        };

        exports.NgCheckboxLov.prototype = {

            // initialize NgCheckboxLov
            constructor: exports.NgCheckboxLov,

            // create the container for the interactive control and set a display value on it
            // this is the gwt entry point used to create the control
            createCB: function( insertHere, displayVals, internalVals, options ) {
                // add reinitVals to the api object - called by gwt when returning to edit mode
                options.reinitVals = function( currentVals, currentDisplayVals ) {
                    // replace place-holder object with current values
                    this.scope.selectedPHolders = [];
                    for( var inx = 0; inx < currentVals.length; inx++ ) {
                        this.scope.selectedPHolders.push( JSON.parse( '{ "propInternalValue": "' + currentVals[inx] +
                            '", "propDisplayValue": "' + currentDisplayVals[inx] + '", "sel": true }' ) );
                    }
                    if( typeof this.scope.reinitLOV !== 'undefined' ) {
                        this.scope.reinitLOV();
                    }
                };

                this.$parent = $( '<aw-checkbox-lov/>' );
                $( insertHere ).append( this.$parent );
                awInclude( insertHere, this.$parent );

                var ngScope = ngModule.element( this.$parent ).scope();
                if( ngScope ) {
                    // attatch this control reference to ng's scope
                    ngScope.myCba = this;

                    // attach the scope (parent) to gwt's option object
                    options.scope = ngScope;

                    this.options = options;

                    // generate place-holder array for selected values not yet loaded
                    ngScope.selectedPHolders = [];

                    for( var inx = 0; inx < displayVals.length; inx++ ) {
                        ngScope.selectedPHolders.push( JSON.parse( '{ "propInternalValue": "' + internalVals[inx] +
                            '", "propDisplayValue": "' + displayVals[inx] + '", "sel": true }' ) );
                    }
                }
            }
        };

        return exports;
    } );
