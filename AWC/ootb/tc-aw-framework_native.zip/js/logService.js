// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 console,
 define,
 window
 */

/**
 * This service is used to announce various level logging events to the console.
 * <p>
 * This builds on the GWT logging controls via the URL parameters. See
 * http://www.gwtproject.org/doc/latest/DevGuideLogging.html for more information.
 * <p>
 * Expected patterns:<br>
 * (1) http://localhost:3000?logLevel=FINER<br>
 * (2) http://localhost:3000?logLevel=FINER&locale=fr<br>
 * (3) http://localhost:3000/?logLevel=FINER#com.siemens.splm.clientfx.tcui.xrt.showObject;uid=gkYNKH6Fqd%2524DyB
 *
 * @module js/logService
 */
define( [ 'app', 'lodash' ], function( app, _ ) {
    'use strict';

    var exports = {};

    /** Log correlation ID. */
    var _logCorrelationID = '';

    /** Logger output level. */
    var level = 4; // Default value of DEBUG/FINE

    /** is browser IE? */
    var _isIE = false;
    if( typeof navigator !== 'undefined' && navigator && navigator.userAgent ){
        _isIE = navigator.userAgent.search( /(trident|edge)/i ) > -1;
    }

    if( typeof window !== 'undefined' && window && window.location ) {
        /**
         * Query the 'logLevel' parameter from the URL (if it's there).
         */
        var urlParam = window.location.search.substr( 1 ).split( '&' );
        for( var i = 0; i < urlParam.length; ++i ) {
            var p = urlParam[i].split( '=', 2 );
            if( p.length === 1 ) {
                urlParam[p[0]] = "";
            } else {
                urlParam[p[0]] = decodeURIComponent( p[1].replace( /\+/g, " " ) );
            }
        }

        if( urlParam.logLevel ) {
            switch( urlParam.logLevel ) {
            case 'OFF':
                level = 0;
                break;
            case 'SEVERE': // Not supported by GWT
            case 'ERROR':
                level = 1;
                break;
            case 'WARN': // Not supported by GWT
            case 'WARNING':
                level = 2;
                break;
            case 'INFO': // Not supported by GWT
            case 'CONFIG':
                level = 3;
                break;
            case 'DEBUG': // Not supported by GWT
            case 'FINE':
                level = 4;
                break;
            case 'TRACE': // Not supported by GWT
            case 'FINER':
            case 'FINEST':
                level = 5;
                break;
            case 'ALL':
                level = 6;
                break;
            default:
                // do nothing
            }
        }
    } else {
        /**
         * Support Node.js usage of this service. window isn't defined & it's missing console.debug & console.warn.
         */
        if( !console.error ) {
            console.error = console.log;
        }
        if( !console.warn ) {
            console.warn = console.log;
        }
        if( !console.info ) {
            console.info = console.log;
        }
        if( !console.debug ) {
            console.debug = console.log;
        }
        if( !console.trace ) {
            console.trace = console.log;
        }
    }

    /**
     * @return {String} log correlation ID
     */
    exports.getCorrelationID = function() {
        return _logCorrelationID;
    };

    /**
     * @return {String} log correlation ID
     */
    function getCorrelationIDPrefix() {
        return _logCorrelationID ? _logCorrelationID + '\n' : '';
    }

    /**
     * @param {String} logCorrelationID log correlation ID
     */
    exports.setCorrelationID = function( logCorrelationID ) {
        if( logCorrelationID ) {
            _logCorrelationID = logCorrelationID;
        }
    };

    /**
     * @param {String} prefix log correlation ID prefix
     * @param {String} logCorrelationID log correlation ID
     */
    exports.updateCorrelationID = function( prefix, logCorrelationID ) {
        if( ( !_logCorrelationID || logCorrelationID ) && prefix ) {
            exports.setCorrelationID( prefix + ':' + logCorrelationID + ':' + _.now() );
        }
    };

    /**
     * Checks whether this Logger is enabled for the ERROR Level.
     *
     * @returns {boolean} true if error output is enabled.
     */
    exports.isErrorEnabled = function() {
        return level >= 1;
    };

    /**
     * Checks whether this Logger is enabled for the WARN Level.
     *
     * @returns {boolean} true if warning output is enabled.
     */
    exports.isWarnEnabled = function() {
        return level >= 2;
    };

    /**
     * Checks whether this Logger is enabled for the INFO Level.
     *
     * @returns {boolean} true if info output is enabled.
     */
    exports.isInfoEnabled = function() {
        return level >= 3;
    };

    /**
     * Checks whether this Logger is enabled for the DEBUG Level.
     *
     * @returns {boolean} true if debug output is enabled.
     */
    exports.isDebugEnabled = function() {
        return level >= 4;
    };

    /**
     * Checks whether this Logger is enabled for the TRACE Level.
     *
     * @returns {boolean} true if trace output is enabled.
     */
    exports.isTraceEnabled = function() {
        return level >= 5;
    };

    /**
     * Handle argument processing to support IE short coming.
     *
     * @return {Array} arguments to console function
     */
    function handleArg() {
        var args = [ getCorrelationIDPrefix() ];
        for( var ii = 0; ii < arguments.length; ii++ ) {
            if( _isIE && _.isPlainObject( arguments[ii] ) ) {
                // IE doesn't handle this scenario well
                args.push( JSON.stringify( arguments[ii], null, 2 ) );
            } else {
                args.push( arguments[ii] );
            }
        }
        return args;
    }

    /**
     * Similar to info() but also includes a stack trace from where the method was called.
     */
    exports.error = function() {
        if( exports.isErrorEnabled() ) {
            console.error.apply( console, handleArg.apply( this, arguments ) );
        }
    };

    /**
     * This method is like info() but also displays a yellow warning icon along with the logged message.
     */
    exports.warn = function() {
        if( exports.isWarnEnabled() ) {
            console.warn.apply( console, handleArg.apply( this, arguments ) );
        }
    };

    /**
     * This method is identical to debug().
     */
    exports.info = exports.success = function() {
        if( exports.isInfoEnabled() ) {
            console.info.apply( console, handleArg.apply( this, arguments ) );
        }
    };

    /**
     * Displays a message in the console. You pass one or more objects to this method, each of which are evaluated and
     * concatenated into a space-delimited string. The first parameter you pass may contain format specifiers, a string
     * token composed of the percent sign (%) followed by a letter that indicates the formatting to be applied.
     */
    exports.debug = function() {
        if( exports.isDebugEnabled() ) {
            console.debug.apply( console, handleArg.apply( this, arguments ) );
        }
    };

    /**
     * Prints a stack trace from the point where the method was called, including links to the specific lines in the
     * JavaScript source.
     */
    exports.trace = function() {
        if( exports.isTraceEnabled() ) {
            console.debug.apply( console, handleArg.apply( this, arguments ) );
        }
    };

    /**
     * Register this service with the AngularJS application.
     *
     * @returns {Object} Reference to this module's API.
     */
    app.factory( 'logService', function() {
        return exports;
    } );

    return exports;
} );
