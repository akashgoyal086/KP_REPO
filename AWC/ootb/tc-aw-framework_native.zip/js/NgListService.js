//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 window
 */

/**
 * Note: We include 'jqueryui' as a parameter to be sure it finished loading before we get here.
 *
 * @module js/NgListService
 */
define( [ 'app', 'jquery', 'jqueryui', 'js/NgUtil' ], function( app, $, jqueryui ) {
    'use strict';

    /**
     * Define local variables for commonly used key-codes.
     */
    var _kcTab = 9;
    var _kcEnter = 13;
    var _kcEscape = 27;
    var _kcUpArrow = 38;
    var _kcDnArrow = 40;

    /**
     * @constructor ListService
     *
     * @param {AngularService} $timeout -
     */
    var ListService = function( $timeout, UtilsService ) {
        var self = this;

        /**
         * @memberof module:js/NgListService~ListService
         * @private
         *
         * @param {Object} scope - The 'scope' all controller level values are defined on.
         * @param {Element} $element - DOM element the controller is attached to.
         *
         * @return {Void}
         */
        self._adjustPositionForValues = function( scope, $element ) {
            // Setup the click handler
            $( 'body' ).off( 'click touchstart' ).on( 'click touchstart', scope, self.exitFieldHandler );
            scope.$evalAsync( function() {
                // now that we have the list of items determine if we should be above or below the choice
                var $choiceElem = $element.find( '.aw-jswidgets-choice' );
                var dropElem = $element.find( '.aw-jswidgets-drop' )[ 0 ];
                var choiceElem = $choiceElem[ 0 ];
                var choiceRect = choiceElem.getBoundingClientRect();
                var spaceBelow = window.innerHeight - choiceRect.bottom;
                var dropRect = dropElem.getBoundingClientRect();

                scope.dropPosition = ( spaceBelow < dropRect.height ) ? 'above' : 'below';

                // Get the border width from the CSS

                if( scope.dropPosition === 'above' ) {
                    var choiceBorderWidthTop = parseFloat( $choiceElem.css( 'borderTopWidth' ) );

                    scope.dropDownVerticalAdj = -Math.abs( dropRect.bottom - dropRect.top ) + choiceBorderWidthTop +
                        "px";
                } else {
                    var choiceBorderWidthBottom = parseFloat( $choiceElem.css( 'borderBottomWidth' ) );

                    scope.dropDownVerticalAdj = scope.choiceElemHeight - choiceBorderWidthBottom + "px";
                }

                scope.listener = null; // clear the watch
            } );
        };

        /**
         * This gets called when we exit the control by clicking outside.
         * <P>
         * Note: More ideally, it would be invoked on blur, but blur events are not well-supported across browsers. In
         * the case of Input blur, we want to ignore clicks inside the drop, so we need to know the target that caused
         * the blur. In chrome, it's 'relatedTarget', in IE you have to use 'document.activeElement', in FF you have
         * 'explicitOriginalTarget', etc. Instead, this is using a document click listener.
         *
         * @param {Object} scope - The 'scope' all controller level values are defined on.
         * @param {DOMEvent} event
         *
         * @memberof module:js/NgListService~ListService
         * @private
         *
         * @return {Void}
         */
        self._exitField = function( scope, event ) {
            var targetScope = $( event.target ).scope();
            var choiceScope = $( event.target ).parents( '.aw-jswidgets-choice' ).scope();
            var dropScope = $( event.target ).parents( '.aw-jswidgets-drop' ).scope();
            var targetScopeId = -1;
            var choiceScopeId = -1;
            var dropScopeId = -1;

            if( targetScope ) {
                targetScopeId = targetScope.$id;
            }

            if( choiceScope ) {
                choiceScopeId = choiceScope.$id;
            }

            if( dropScope ) {
                dropScopeId = dropScope.$id;
            }

            // Some platforms, such as iPAD Safari, send erroneous field exit events, check to make sure this isn't one
            if( targetScopeId === scope.$id || choiceScopeId === scope.$id || dropScopeId === scope.$id ) {
                return;
            }

            if( scope.expanded ) {
                self.collapseList( scope );
                scope.handleFieldExit();
            }
        };

        /**
         * Exit field handler which gets triggered when user clicks outside of the LOV
         *
         * @memberof module:js/NgListService~ListService
         *
         * @param {DOMEvent} event -
         *
         * @return {Void}
         */
        self.exitFieldHandler = function( event ) {
            self._exitField( event.data, event );
        };

        /**
         * Collapse the drop-down
         *
         * @memberof module:js/NgListService~ListService
         *
         * @param {Object} scope - The object holding all the state within the 'scope' of the widget needing the list.
         *
         * @return {Void}
         */
        self.collapseList = function( scope ) {
            scope.listFilterText = '';

            $( 'body' ).off( 'click touchstart', self.exitFieldHandler );

            scope.$evalAsync( function() {
                scope.expanded = false;
            } );
        };

        /**
         * Show the popup list of lovEntries.
         *
         * @param {Object} scope - The object holding all the state within the 'scope' of the widget needing the list.
         * @param {JqliteElement} $element -
         *
         * @return {Void}
         */
        self.expandList = function( scope, $element ) {
            if( !scope.expanded ) {
                var choiceElem = $element.find( '.aw-jswidgets-choice' )[ 0 ];
                var dropElem = $element.find( '.aw-jswidgets-drop' )[ 0 ];

                if( !choiceElem ) {
                    console.log( 'ListService.expandList: Unable to find choice input field element' );
                    return;
                }

                if( !dropElem ) {
                    console.log( 'ListService.expandList: Unable to find dropdown list container element' );
                    return;
                }

                scope.dropPosition = 'below';

                /**
                 * Position the dropdown list element
                 */
                var choiceElemDimensions = choiceElem.getBoundingClientRect();

                scope.lovDDLeft = choiceElemDimensions.left;
                scope.lovDDTop = window.pageYOffset + choiceElemDimensions.top;
                scope.lovDDWidth = choiceElemDimensions.width;
                scope.choiceElemHeight = choiceElemDimensions.bottom - choiceElemDimensions.top;

                /**
                 * Listen for changes so we can hide the drop on scroll, etc.
                 *
                 * @return {Void}
                 */
                scope.listener = scope.$watch( function() {
                    return $element.find( '.aw-widgets-cellListWidget' )[ 0 ].clientHeight;
                }, function( newValue, oldValue ) {
                    if( newValue !== oldValue && newValue > 0 ) {
                        self._adjustPositionForValues( scope, $element );
                    }
                } );

                UtilsService.handleScroll( scope, $element, 'listService', function() {
                    scope.$scrollPanel.off( 'scroll.listService' );
                    scope.$scrollPanel = null;
                    self.collapseList( scope );
                } );

                scope.expanded = true;
            }
        };

        /**
         * Evaluate a key press in the input
         *
         * @memberof module:js/NgListService~ListService
         *
         * @param {Object} scope -
         * @param {Object} event -
         */
        self.evalKey = function( scope, event, $element ) {
            // find the index in the lovEntries array of the value of current attention
            var getAttnIndex = function() {
                if( scope.lovEntries.length && scope.expanded ) {
                    var index = scope.lovEntries.map( function( lovEntry ) {
                        return lovEntry.attn;
                    } ).indexOf( true );
                    return index;
                }
            };

            var code = event.keyCode;

            if( code === _kcTab || code === _kcEnter || code === _kcEscape || code === _kcUpArrow ||
                code === _kcDnArrow ) {
                var attnIndex = getAttnIndex();
                var selectIndex = -1;
                if( code === _kcTab || code === _kcEnter ) {
                    scope.handleFieldExit( event, attnIndex );
                } else if( code === _kcUpArrow || code === _kcDnArrow ) {
                    // arrow keys
                    if( !scope.expanded ) {
                        scope.toggleDropdown();
                    }
                    // if attn isn't yet set, set it to the first val
                    if( attnIndex < 0 ) {
                        scope.lovEntries[ 0 ].attn = true;
                        selectIndex = 0;
                    } else {
                        if( code === _kcDnArrow ) {
                            // down arrow: move the attention down
                            if( scope.lovEntries.length > attnIndex + 1 ) {
                                scope.lovEntries[ attnIndex ].attn = false;
                                scope.lovEntries[ attnIndex + 1 ].attn = true;
                                selectIndex = attnIndex + 1;
                            }
                        } else {
                            // up arrow
                            if( attnIndex > 0 ) {
                                scope.lovEntries[ attnIndex ].attn = false;
                                scope.lovEntries[ attnIndex - 1 ].attn = true;
                                selectIndex = attnIndex - 1;
                            }
                        }
                    }
                    // scroll as-needed
                    self.scrollAttention( scope, $element );

                    if( scope.handleFieldSelect ) {
                        scope.handleFieldSelect( selectIndex );
                    }

                } else if( code === _kcEscape ) {
                    self.collapseList( scope );

                    scope.handleFieldEscape();
                }
            }
        };

        /**
         * Scroll to the list item of attention.
         *
         * @memberof module:js/NgListService~ListService
         *
         * @param {Object} scope -
         * @param {DOMElement} $element -
         *
         * @return {Void}
         */
        self.scrollAttention = function( scope, $element ) {
            var dropElem = $element.find( '.aw-jswidgets-drop' );
            if( !dropElem ) {
                console.log( 'ListService.scrollAttention: Unable to find dropdown list container element' );
                return;
            }

            $timeout( function() {
                var $chosenElem = dropElem.find( 'div.aw-jswidgets-nestingListItemDisplay.aw-state-attention' );

                if( $chosenElem && $chosenElem.length ) {
                    // Calculate where to scroll to show the selected item in the LOV drop down
                    var calcTop = dropElem.scrollTop() + $chosenElem.position().top - ( dropElem.height() / 2 );
                    dropElem.animate( {
                        scrollTop: calcTop
                    }, 'fast' );
                }
            } );
        };
    };

    /**
     * Definition for the ListService service used by (aw-property-lov-val) and (aw-property-time-val).
     *
     * @member ListService
     * @memberof NgServices
     *
     * @param {AngularService} $timeout -
     * @param {UtilsService} UtilsService -
     *
     * @return {Void}
     */
    app.factory( 'ListService', [ '$timeout', 'UtilsService', function( $timeout, UtilsService ) {
        return new ListService( $timeout, UtilsService );
    } ] );

    // End RequireJS Define
} );
