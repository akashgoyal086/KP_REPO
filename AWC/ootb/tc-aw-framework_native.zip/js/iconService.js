// @<COPYRIGHT>@
// ==================================================
// Copyright 2016.
// Siemens Product Lifecycle Management Software Inc.
// All Rights Reserved.
// ==================================================
// @<COPYRIGHT>@

/*global
 define
 window
 */

/**
 * @module js/iconService
 */
define( [ 'app', 'lodash' ], function( app, _ ) {
    'use strict';

    var exports = {};

    /**
     * @private
     */
    var _cache = {
        /**
         * Map of all actual (non-Type) SVG file names to the raw SVG definition strings.
         */
        img: {},

        /**
         * Set of '<svg>' and '<img>' HTML tags set with the "aw-base-icon" CSS class once an icon is used.
         */
        use: {},

        /**
         * Map of icon 'alias' names (w/'type' or another prefix) to the actual SVG file name to use.
         */
        map: {}
    };

    //Do not remove the below line. The SVG type icons are combined and inserted as part of the 'gulp war' task.
    /* INSERT_SVG_HERE */

    /**
     * @param {String} key - key field within use object
     * @return {String|null} string from use object per key field
     */
    function _getFromUseCache( key ) {
        var result = _cache.use[key];
        if( result ) {
            return result;
        }
    }

    /**
     * @param {String} key - key field within use object
     * @return {String|null} string from use object per key field
     */
    function _addToUseCache( key ) {
        /**
         * Note: We need to insure a space behind the class define to fix the parse issue of FireFox and IE.
         */
        var iconTag = _cache.img[key].replace( '<svg ', '<svg class="aw-base-icon" ' );

        _cache.use[key] = iconTag;

        return iconTag;
    }

    /**
     * Check if the given iconName is an alias name for the actual icon filename.
     *
     * @param {String} iconName - The name of the icon to any final iconName for.
     *
     * @return {String} Final icon file name.
     */
    function _resolveKeyFromAlias( iconName ) {
        var key = _cache.map[iconName];

        if( !key ) {
            key = iconName;
        }

        return key;
    }

    /**
     * Returns the <SVG> tag for the given icon name (or NULL if the icon file was not deployed).
     *
     * @param {String} name - The name of the icon to return.
     * @return {String} The <SVG> tag for the given icon name (or NULL if the icon file was not deployed).
     */
    function _getIcon( name ) {
        /**
         * Check if this is an alias name for the actual icon name.
         */
        var key = _resolveKeyFromAlias( name );

        /**
         * Check if we have already prepared a tag for this icon to use.
         */
        var ret = _getFromUseCache( key );

        if( ret ) {
            return ret;
        }

        /**
         * Check if this icon is even defined in the image map.
         */
        if( _.isString( _cache.img[key] ) ) {
            return _addToUseCache( key );
        }

        return null;
    }

    /**
     * @param {String} typeName type name
     * @return {String|null} type file name
     */
    function _getTypeFileNameFromCache( typeName ) {
        var key = _resolveKeyFromAlias( 'type' + typeName );

        if( _.indexOf( _cache.typeFiles, key, true ) > -1 ) {
            return key + '.svg';
        }

        // If alias doesn't indicate the number try adding it.
        key += '48';
        if( _.indexOf( _cache.typeFiles, key, true ) > -1 ) {
            return key + '.svg';
        }

        return null;
    }

    /**
     * @param {Object} modelType Teamcenter model type
     * @return {String} type icon file name
     */
    exports.getTypeIconFileName = function( modelType ) {
        for( var ii = 0; ii < modelType.typeHierarchyArray.length; ii++ ) {
            var typeName = modelType.typeHierarchyArray[ii];
            var typeFileName = _getTypeFileNameFromCache( typeName );
            if( typeFileName ) {
                return typeFileName;
            }
        }
        return _getTypeFileNameFromCache( 'MissingImage' );
    };

    /**
     * Returns the <IMG> tag for the given type name (or NULL if the type icon file was not deployed).
     *
     * @param {String} typeName - The 'type' name (w/o the 'type' prefix) to get an icon for.
     * @return {String} The <IMG> tag for the given type name (or NULL if the type icon file was not deployed).
     */
    exports.getTypeIcon = function( typeName ) {
        /**
         * Check if we have already prepared a tag for this icon to use.
         */
        var ret = _getFromUseCache( typeName );
        if( ret ) {
            return ret;
        }

        var iconFileName = null;

        var modelType = app.cmm.getType( typeName );
        if( modelType && modelType.constantsMap.IconFileName ) {
            // If we already have the meta model cached, use the constant for the type icon filename.
            iconFileName = modelType.constantsMap.IconFileName;
        } else {
            /**
             * Check if this is an alias name for the actual icon name.
             */
            iconFileName = _getTypeFileNameFromCache( typeName );
            if( !iconFileName ) {
                return null;
            }
        }

        /**
         * Build final tag and put into the 'use' cache to save some work in the future.
         */
        var iconTag = '<img class="aw-base-icon" src="' + app.getBaseUrlPath() + '/image/' + iconFileName +
            '" draggable="false" ondragstart="return false;" />';
        _cache.use[typeName] = iconTag;
        return iconTag;
    };

    /**
     * Returns the url to the type icon for the given type name (or NULL if the icon file was not deployed).
     *
     * @param {String} typeName - The 'type' name (w/o the 'type' prefix) to get an icon for.
     * @return {String} The <IMG> tag for the given type name (or NULL if the type icon file was not deployed).
     */
    exports.getTypeIconURL = function( typeName ) {
        /**
         * Check if this is an alias name for the actual icon name.
         */
        var iconFileName = _getTypeFileNameFromCache( typeName );
        if( !iconFileName ) {
            return null;
        }

        /**
         * Create the path to the icon
         */
        var url = app.getBaseUrlPath() + '/image/' + iconFileName;
        return url;
    };

    /**
     * Gets the SVG string for the given tile name. If the tile has not been registered in a module.json this returns
     * null.
     *
     * @param {String} name - the type name to get an icon for.
     * @return {String} SVG string for tile
     */
    exports.getTileIcon = function( name ) {
        return _getIcon( 'home' + name );
    };

    /**
     * Gets the SVG string for the given tile name. If the tile has not been registered in a module.json this returns
     * null.
     *
     * @param {String} name - the icon name to get an icon for.
     * @return {String} SVG string for tile
     */
    exports.getMiscIcon = function( name ) {
        return _getIcon( 'misc' + name );
    };

    /**
     * Gets the SVG string for the given tile name. If the tile has not been registered in a module.json this returns
     * null.
     *
     * @param {String} name - the icon name to get an icon for.
     * @return {String} SVG string for tile
     */
    exports.getCmdIcon = function( name ) {
        return _getIcon( 'cmd' + name );
    };

    /**
     * Gets the SVG string for the given name.
     *
     * @param {String} iconName - the icon name to get an icon for.
     * @return {String} SVG string for the icon
     */
    exports.getIcon = function( iconName ) {
        /**
         * Check if this is an alias name for the actual icon name.
         */
        var key = _resolveKeyFromAlias( iconName );

        return _cache.img[key];
    };

    /**
     * Register this service with the AngularJS application.
     *
     * @returns {Object} Reference to this module's API.
     */
    app.factory( 'iconService', function() {
        return exports;
    } );

    return exports;
} );