//@<COPYRIGHT>@
//==================================================
//Copyright 2015.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define
 */

/**
 * @module js/NotyModule
 */
define( [ 'app',
    'jquery',
    'noty.customized' , 'js/iconService'], function( app, $, notyCust, iconService ) {
    'use strict';

    /**
     * Include the CSS for 'noty' module.
     */
    var link = document.createElement( "link" );

    //read the svg content for pin/unpin icons from the icon service
    $.notyRenderer.setSvg(iconService.getTileIcon("UnpinButton"), iconService.getTileIcon("PinButton"));

    link.type = "text/css";
    link.rel = "stylesheet";
    link.href =  app.getBaseUrlPath() + "/lib/noty/css/noty.css";

    document.getElementsByTagName( "head" )[ 0 ].appendChild( link );

    /**
     * Register this service with the AngularJS application.
     */
    app.factory( 'notyRenderer', function() {
        return $.notyRenderer;
    } );

    app.factory( 'notyService', function() {
        return {
            /**
             * Report an 'informational' type pop up message using 'NotyJS' API.
             *
             * @param {String} message - Message to display.
             */
            showInfo: function( message ) {
                var notyMessage = {
                    layout: 'bottom',
                    theme: 'lightTheme',
                    type: 'information',
                    text: message,
                    dismissQueue: true,
                    maxVisible: 3,
                    closeWith: [ 'stayOnClick' ],
                    animation: {
                        open: {
                            height: 'toggle'
                        },
                        close: {
                            height: 'toggle'
                        },
                        easing: 'swing',
                        speed: 500
                    },
                    timeout: 6000
                };

                $.notyRenderer.init( notyMessage );
            },
            /**
             * Report an 'alert' type pop up message using 'NotyJS' API.
             *
             * @param {String} message - Message to display.
             */
            showAlert: function( message ) {
                var notyMessage = {
                    layout: 'bottom',
                    theme: 'lightTheme',
                    type: 'alert',
                    text: message,
                    dismissQueue: true,
                    maxVisible: 3,
                    closeWith: [ 'stayOnClick' ],
                    animation: {
                        open: {
                            height: 'toggle'
                        },
                        close: {
                            height: 'toggle'
                        },
                        easing: 'swing',
                        speed: 500
                    },
                    timeout: 6000
                };

                $.notyRenderer.init( notyMessage );
            },
            /**
             * Report an 'warning' type pop up message using 'NotyJS' API.
             *
             * @param {String} message - Message to display.
             * @param {Object} buttonsArr - Array of buttons as user options
             */
            showWarning: function( message, buttonsArr ) {
                var notyMessage = {
                    layout: 'bottom',
                    theme: 'lightTheme',
                    type: 'warning',
                    text: message,
                    dismissQueue: true,
                    modal: true,
                    buttons: buttonsArr,
                    animation: {
                        open: {
                            height: 'toggle'
                        },
                        close: {
                            height: 'toggle'
                        },
                        easing: 'swing',
                        speed: 500
                    },
                    timeout: false
                };

                $.notyRenderer.init( notyMessage );
            }
        };
    } );

    return $.noty;
} );
