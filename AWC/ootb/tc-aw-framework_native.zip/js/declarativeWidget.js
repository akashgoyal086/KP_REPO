//@<COPYRIGHT>@
//==================================================
//Copyright 2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 awInclude,
 define,
 window
 */

/**
 * @module js/declarativeWidget
 */
define(
    [ 'app', 'angular', 'jquery', 'js/awDui', 'js/panelContentService' ],
    function( app, ngModule, $, dui, panelContentServiceModule ) {
        'use strict';

        /**
         * Defines the declarativeWidget controller.
         *
         * @member declarativeWidgetController
         * @memberof NgControllers
         */
        app.controller( 'declarativeWidgetController', [ '$scope', 'panelViewModelService',
            function( $scope, panelViewModelService ) {
                // Define the panel controller
                var self = this;

                self.updateViewModel = function( dataObject ) {
                    $scope.$evalAsync( function() {
                        panelViewModelService.updateViewModel( dataObject );
                    } );
                };

                self.setContext = function( dataObject ) {
                    $scope.$evalAsync( function() {
                        $scope.context = dataObject;
                    } );
                };

                self.getViewModel = function( path ) {
                    return panelViewModelService.getViewModelObject( path );
                };
            } ] );

        var exports = {};

        /**
         * Initialize ('bootstrap') the angular system and create an angular controller on a new 'child' of the given
         * 'parent' element.
         *
         * @param {Element} parentElement - The DOM element the controller and 'inner' HTML content will be added to.
         *            <P>
         *            Note: All existing 'child' elements of this 'parent' will be removed.
         *
         * @param {cmdId} cmdId - Command identifier
         */
        exports.insertHtmlWidget = function( parentElement, cmdId ) {

            /**
             * Create an 'outer' <DIV> (to hold the given 'inner' HTML).
             * <P>
             * Remove any existing 'children' of the given 'parent'
             * <P>
             * Add this new element as a 'child' of the given 'parent'
             */
            try {
                var contrElement = ngModule
                    .element( '<div class="aw-jswidgets-htmlWidget aw-layout-flexColumn" ng-controller="declarativeWidgetController"/>' );

                var injector = ngModule.element( document ).injector();

                //Build time should bundle all the template HTMLs into the cache like we do for Ng Directives
                injector.invoke( [
                    '$templateCache',
                    '$http',
                    'panelContentService',
                    'panelViewModelService',
                    function( $templateCache, $http, panelContentService, panelViewModelService ) {

                        // Look up the panel content for the given command Id
                        var panelContent = panelContentService.getPanelContent( cmdId );

                        // Populating the panel View Model
                        panelViewModelService.populateViewModelProperties( panelContent.viewModel ).then(
                            function( data ) {

                                // Injecting the View into the DOM
                                var innerHtmlURL = panelContent.view;
                                var strHTML = $templateCache.get( innerHtmlURL );

                                if( strHTML ) {
                                    contrElement.html( strHTML );

                                    $( parentElement ).empty();
                                    $( parentElement ).append( contrElement );

                                    awInclude( parentElement, contrElement );

                                } else {
                                    $http.get( innerHtmlURL ).success( function( response ) {
                                        strHTML = response;

                                        if( strHTML ) {
                                            //Cache for future requests to the same URL
                                            $templateCache.put( innerHtmlURL, strHTML );
                                        }
                                        contrElement.html( strHTML );
                                        $( parentElement ).empty();
                                        $( parentElement ).append( contrElement );

                                        awInclude( parentElement, contrElement );

                                    } );
                                }
                            } );

                    } ] );

            } catch( e ) {
                console.log( "insertHtmlWidget::exception " + e );
            }
        };

        /**
         * Update the 'scope' object of the related controller.
         *
         * @param {Element} parentElement - The element above the element the controller was created on.
         *
         * @param {module:js/NgProperty~UIPropertyOverlayJS} jsObject - Overlay object that will be updated in the
         *            context of the scope
         */
        exports.updateViewModel = function( parentElement, jsObject ) {
            var ctrlElement = ngModule.element( parentElement.querySelector( '.aw-jswidgets-htmlWidget' ) );

            if( ctrlElement !== null ) {
                var ngController = ngModule.element( ctrlElement ).controller();

                if( ngController ) {
                    ngController.updateViewModel( jsObject );
                }

            } else {
                console.log( "Unable to relocate angular controller on 'parent' element" );
            }
        };

        /**
         * Called when the hosting GWT XRTHtmlPanelView is 'hidden'. This method will call $destroy on the AngularJS
         * 'scope' associated with the ng-controller.
         * <P>
         * Note: *** No further use of this controller is allowed (or wise) ***
         *
         * @param {Element} parentElement - The element above the element the controller was created on.
         */
        exports.unLoadHtmlWidget = function( parentElement ) {
            var ctrlElement = ngModule.element( parentElement.querySelector( '.aw-jswidgets-htmlWidget' ) );

            if( ctrlElement ) {
                var ngScope = ngModule.element( ctrlElement ).scope();

                if( ngScope ) {
                    ngScope.$destroy();
                }
            }
        };

        /**
         * Note: Return the ViewModel element
         *
         * @param {Element}
         *            parentElement - The element above the element the controller was created on.
         * @param {String} path - the path on the view model
         */
        exports.getViewModel = function( parentElement, path ) {

            var ctrlElement = ngModule.element( parentElement.querySelector( '.aw-jswidgets-htmlWidget' ) );

            if( ctrlElement !== null ) {
                var ngController = ngModule.element( ctrlElement ).controller();
                return ngController.getViewModel( path );
            }

            return null;
        };

        return exports;
        // End RequireJS Define
    } );