//@<COPYRIGHT>@
//==================================================
//Copyright 2016.
//Siemens Product Lifecycle Management Software Inc.
//All Rights Reserved.
//==================================================
//@<COPYRIGHT>@

/*global
 define,
 document,
 isBootstrapDebugEnabled,
 awInclude
 */

/* TODO : refer to backlog stories B-21114
 * Need to move the common/shared JS logic to a shared require module.
 */

/**
 * @module js/NgUIMatrix - ui-grid implementation for Matrix view.
 */
define(
    ['app', 'angular', 'jquery', 'ui.grid'],
    function (app, ngModule, $) {
        'use strict';


        //This is check for CSS link  which is used by several modules .
        //Condition for checking if the CSS style link is already added then do not add again.
        var cssCheck = $("head:first > link").filter("[href='" + app.getBaseUrlPath() + "/lib/uigrid/ui-grid.min.css']").length;
        if (cssCheck === 0) {
            /**
             * Include the CSS for 'ui-grid' module.
             */
            var link = document.createElement("link");

            link.type = "text/css";
            link.rel = "stylesheet";
            link.href = app.getBaseUrlPath() + "/lib/uigrid/ui-grid.min.css";

            document.getElementsByTagName("head")[0].appendChild(link);
        }


        var exports = {};

        /**
         * Defines the Matrix controller
         *
         * @constructor awMatrixController
         *
         * @memberof NgControllers
         */
        app.controller('awMatrixController', [
            '$scope',
            '$timeout',
            'uiGridConstants',
            function ($scope, $timeout, uiGridConstants) {
                var self = {};
                self = this;
                self.whatamI = "awMatrixController"; //debug aid

                // rudimentary factory method to create a rowMaster instance
                // the rowMaster is what the grid uses for lookup to the data.   Dependency on referencing the data.
                var rowMasterFactory = function (rowDescriptors, visible) {
                    var rowMaster = {};
                    rowMaster.descriptor = rowDescriptors;
                    rowMaster.isVisible = visible;
                    rowMaster.descriptor.id = rowDescriptors.id;
                    // function to get the content for the display of this row.
                    rowMaster.getRowHeader = function () {
                        if (rowMaster.descriptor.rowHeaderTemplate) {
                            return  rowMaster.descriptor.rowHeaderTemplate;
                        }
                        else if (self.containerVM.api && self.containerVM.api.getRowHeaderTemplate) {
                            return self.containerVM.api.getRowHeaderTemplate(rowMaster.descriptor);
                        }
                        return rowMaster.descriptor.displayName;
                    };
                    rowMaster.rowDisplay = function () {
                        // return the data for display in column 0 (row header)
                        return rowMaster.descriptor.displayName;
                    };
                    // this is the cell data retrieval function call.
                    // it gets called from the uiGrid to get the cell value for
                    // specific row, col coordinate.   For the matrix case, this gets directed back
                    // up to the containerVM for resolution.
                    rowMaster.getValueForColumn = function (colKey) {
                        var rowKey = rowMaster.descriptor.id;
                        if (self.containerVM.api && self.containerVM.api.getCellValue) {
                            return self.containerVM.api.getCellValue(rowKey, colKey);
                        }
                        return ""; // null or empty object?
                    };

                    //this is to highlight row  based on row header selection
                    rowMaster.onRowHeaderClick = function (rowId, event) {
                        rowHeaderSelection(rowId, event);
                    };

                    return rowMaster;
                };


                // static first grid column which holds the row headers
                var firstColumn = {
                    // placeholder - this is the first column which holds the "row" names, no title or column level interaction.
                    name: "",
                    field: "rowDisplay()",
                    cellTemplate: '<div title={{row.entity.descriptor.displayName}} __rowid={{row.entity.descriptor.id}} aw-matrix-click-row-header class="ui-grid-cell-contents" >' +
                       '<aw-matrix-row-header context={{row.entity.descriptor.id}}/></div>',
                    displayName: '', // empty
                    pinnedLeft: true,
                    enableSelection: false,
                    enableCellSelection: false,
                    enableColumnMenu: false, // hides all the column header stuff in this field - should be blank.
                    enableSorting: false,
                    minWidth: 100,
                    maxWidth: 200
                };

                // default column defs - single row header to start with
                $scope.columnDefinitions = [firstColumn];



                // generate a column master instance to represent the column of data.
                var columnMatrixMasterFactory = function (cInfo, visible) {
                    var columnMaster = {};
                    // could use this visible flag to control UI visibility
                    columnMaster.isVisible = visible;
                    columnMaster.data = cInfo;
                    columnMaster.key = cInfo.id;  // need unique lookup id per column
                    columnMaster.displayName = cInfo.displayName;

                    return columnMaster;
                };


                // utility function to create the columnMaster object per column info.
                var generateColumnMastersForInfo = function (columnInfos) {
                    var columnMasterList = [];
                    // generate column master bound to each data object.
                    if (columnInfos && columnInfos.length) {
                        for (var idx = 0; idx < columnInfos.length; idx = idx + 1) {
                            var cm = columnMatrixMasterFactory(columnInfos[idx], true);
                            columnMasterList.push(cm);
                        }
                    }
                    return columnMasterList;
                };


                var getColumnHeaderTemplate = function (colDescriptor) {

                    var colSafeUid = colDescriptor.id;
                    var tempStr = '{{ ' + colDescriptor.columnHeaderTemplate ? colDescriptor.columnHeaderTemplate:
                        self.containerVM.api.columnHeaderTemplate ? self.containerVM.api.columnHeaderTemplate(colDescriptor): +
                            '<div class="aw-jswidgets-matrixHeader">' + colDescriptor.displayName + '</div> }}';

                    var response = '<div title="' + colDescriptor.displayName + '" class="aw-jswidgets-matrixHeader" aw-matrix-click-col __colid = "' +
                        colSafeUid + '">' + tempStr + '<div>';
                    return response;

                };


                // exposed function that triggers column generation for the grid.
                var generateMatrixColumns = function (containerVM, modCols) {
                    // create column master which is sort of the main binding target for uiGrid column
                    var masterList = generateColumnMastersForInfo(modCols);
                    columnMasterList = masterList;

                    // now create the list of uiGrid columnDef instances that the grid will render.
                    for (var idx = 0; idx < masterList.length; idx = idx + 1) {
                        var clMaster = masterList[idx];
                        var colSafeUid = clMaster.data.id;
                        var cdef = {};
                        cdef.name = clMaster.key;
                        cdef.field = 'getValueForColumn("' + colSafeUid + '")';
                        cdef.displayName = clMaster.displayName;
                        cdef.headerCellTemplate = getColumnHeaderTemplate(clMaster.data);
                        cdef.cellTemplate = getCellTemplate(colSafeUid);
                        cdef.cellClass = function (grid, row, col) {
                            var rowid = row.entity.descriptor.id;
                            var colid = col.name;
                            if (rowid === colid)
                            {
                                return 'aw-matrix-novalue';
                            }
                        };
                        cdef.width = "40";
                        cdef.minWidth = '40';
                        cdef.enablePinning = false;
                        cdef.enableSorting = false;

                        cdef.onCtrlClick = function (rowId, colId, event) {
                            $scope.select = true;
                            $scope.needReset = true;
                            ctrlSelect(rowId, colId, event);
                        };
                        cdef.onColClick = function (colId, event) {
                            colHeaderSelection(colId, event);
                        };
                        $scope.columnDefinitions.push(cdef);
                    }
                    return  $scope.columnDefinitions;
                };


                var getCellTemplate = function (colId) {
                    var cellElt = '<div __colid="' + colId + '" __rowid= {{row.entity.descriptor.id}}' +
                    ' class ="ui-grid-cell-contents" aw-matrix-click-cell >{{COL_FIELD}}</div>';
                    return cellElt;
                };



                //contains css class as string
                var cssForSelectedCol = 'ui-grid-matrix-header-cell-selected';
                var cssForSelectedRow = 'ui-grid-matrix-header-cell-selected';
                var cssForUnselection = 'ui-grid-matrix-header-cell-unselected';


                //function for header selection this is only to highlight the section under column head
                var colHeaderSelection = function (colId, event) {
                    var colSelected = event.currentTarget;
                    var colHeaderDiv = $(colSelected).parent();
                    var gridHtml = self.gridApi.grid.element[0];

                    var getFocusedCells = $(gridHtml).find('div').filter('[class*="ui-grid-cell-focus"]');
                    var isCellFocused = getFocusedCells.hasClass('ui-grid-cell-focus');


                    $scope.isColHeadSelected = true;

                    var filter = "[__colid='" + colId + "']";
                    var cellDivs = $("div").find(filter);

                    var isSelected = $(colHeaderDiv).hasClass(cssForSelectedCol);
                    if (isSelected)
                    {
                        if (isCellFocused)
                        {
                            resetSelected(gridHtml, true);
                        }
                        colHeaderDiv.removeClass(cssForSelectedCol);
                        cellDivs.removeClass(cssForSelectedCol);
                    }
                    else
                    {
                        resetSelected(gridHtml, true);
                        colHeaderDiv.addClass(cssForSelectedCol);
                        cellDivs.addClass(cssForSelectedCol);
                    }
                };

                //function for header selection this is only to highlight the section under row head
                var rowHeaderSelection = function (rowId, event)
                {
                    var rowSelected = event.currentTarget;
                    var rowHeaderDiv = $(rowSelected).parent().parent();
                    var gridHtml = self.gridApi.grid.element[0];

                    var filter = "[__rowid='" + rowId + "']";
                    var cellDivs = $("div").find(filter);

                    $scope.isRowHeadSelected = true;

                    var isSelected = $(rowHeaderDiv).hasClass(cssForSelectedRow);
                    if (isSelected)
                    {
                        resetSelected(gridHtml, true);
                    }
                    else
                    {
                        resetSelected(gridHtml, true);
                        rowHeaderDiv.addClass(cssForSelectedRow);
                        cellDivs.addClass(cssForSelectedRow);
                        $scope.isColHeadSelected = false;
                    }
                };

                //function to handle multiselect (ctrl+click) in matrix
                var ctrlSelect = function (rowId, colId, event) {

                    var cellSelected = event.currentTarget;

                    //toggles the cell selection for multiselect ctrl+click
                    $(cellSelected).toggleClass("ui-grid-cell-focus");

                    //if cell is unselected using ctrl+click then set flag to false
                    if (!$(cellSelected).hasClass("ui-grid-cell-focus"))
                    {
                        $scope.select = false;
                        if (rowId && colId) {
                            self.containerVM.events.handleCellNavigation(colId, rowId, false);
                        }
                    }
                    else
                    {
                        if (rowId && colId) {
                            self.containerVM.events.handleCellNavigation(colId, rowId, true);
                        }
                    }

                    var top = $(cellSelected).offsetParent().offsetParent().offsetParent().offsetParent().get(0);

                    var colHead = $(top).find("div").filter('[__colid="' + colId + '"]').get(0);
                    var rowHead = $(top).find("aw-matrix-row-header").filter('[context="' + rowId + '"]').get(0);

                    var colParentLocator = $(colHead).parent();
                    var rowParentLocator = $(rowHead).parent().parent();

                    var colCellsLocator = $(top).find("div").filter('[__colid="' + colId + '"]');
                    var rowCellsLocator = $(top).find("div").filter('[__rowid="' + rowId + '"]');

                    var isColCellSelected = colCellsLocator.hasClass("ui-grid-cell-focus");
                    var isRowCellSelected = rowCellsLocator.hasClass("ui-grid-cell-focus");

                    if ($scope.isColHeadSelected)
                    {
                        resetSelected(top, false);
                        $scope.isColHeadSelected = false;
                    }

                    if ($scope.isRowHeadSelected)
                    {
                        resetSelected(top, true);
                        $scope.isRowHeadSelected = false;
                    }

                    //if multiple cells are selected under a column then keep column head as selected
                    if (isColCellSelected)
                    {
                        $(colParentLocator).addClass(cssForSelectedCol).removeClass(cssForUnselection);
                    }
                    else {
                        $(colParentLocator).removeClass(cssForSelectedCol).addClass(cssForUnselection);
                    }

                    //if multiple cells are selected under a row then keep row head as selected
                    if (isRowCellSelected) {
                        $(rowParentLocator).addClass(cssForSelectedRow);
                    }
                    else
                    {
                        $(rowParentLocator).removeClass(cssForSelectedRow).removeClass(cssForUnselection);
                    }

                    //Handle unselection if no cell is selected
                    if (!isRowCellSelected && !isRowCellSelected)
                    {
                        self.containerVM.events.handleCellNavigation(colId, rowId, false);
                    }

                };


                // these become the backing store for the column definitions.
                var columnMasterList = [];

                // created list of rowMasters (for grid binding)
                var rowMasterMatrix = [];


                var noOldRc = function (newColHead, newRowHead, newColId, newRowId)
                {
                    $(newColHead).addClass(cssForSelectedCol).removeClass(cssForUnselection);
                    $(newRowHead).addClass(cssForSelectedRow).removeClass(cssForUnselection);
                    self.containerVM.events.handleCellNavigation(newColId, newRowId, true);
                };

                var selectNewColAndOldRow = function (newColHead, oldColHead, oldRowHead, newColId, oldRowId) {
                    $(newColHead).addClass(cssForSelectedCol).removeClass(cssForUnselection);
                    $(oldColHead).removeClass(cssForSelectedCol).addClass(cssForUnselection);
                    $(oldRowHead).addClass(cssForSelectedRow).removeClass(cssForUnselection);
                    self.containerVM.events.handleCellNavigation(newColId, oldRowId, true);
                };

                var selectNewRowAndOldCol = function (newRowHead, oldRowHead, oldColHead, oldColId, newRowId) {
                    $(newRowHead).addClass(cssForSelectedRow).removeClass(cssForUnselection);
                    $(oldRowHead).removeClass(cssForSelectedRow).addClass(cssForUnselection);
                    $(oldColHead).addClass(cssForSelectedCol).removeClass(cssForUnselection);
                    self.containerVM.events.handleCellNavigation(oldColId, newRowId, true);
                };

                var selectNewRowAndNewCol = function (newColHead, newRowHead, oldColHead, oldRowHead, newColId, newRowId) {
                    $(oldColHead).removeClass(cssForSelectedCol).addClass(cssForUnselection);
                    $(oldRowHead).removeClass(cssForSelectedRow).addClass(cssForUnselection);
                    $(newColHead).addClass(cssForSelectedCol).removeClass(cssForUnselection);
                    $(newRowHead).addClass(cssForSelectedRow).removeClass(cssForUnselection);
                    self.containerVM.events.handleCellNavigation(newColId, newRowId, true);
                };

                var resetSelected = function (gridHtml, removeCellFocus) {
                    var gridElement = $(gridHtml).offsetParent();
                    var selectedCol = $(gridElement).find('div').filter('[class*="' + cssForSelectedCol + '"]');
                    var selectedRow = $(gridElement).find('div').filter('[class*="' + cssForSelectedRow + '"]');

                    selectedRow.removeClass(cssForSelectedRow);
                    selectedCol.removeClass(cssForSelectedCol);
                    if (removeCellFocus)
                    {
                        var getFocusedCells = $(gridElement).find('div').filter('[class*="ui-grid-cell-focus"]');
                        getFocusedCells.removeClass("ui-grid-cell-focus");
                    }
                };

                // uiGrid settings/configuration
                var gridOptions = {
                    //enableSorting: true, // skip the header sort interaction
                    enableColumnMenus: false, // no menus
                    enableRowHeaderSelection: false,
                    data: rowMasterMatrix,
                    columnDefs: $scope.columnDefinitions,
                    minRowsToShow: 75,
                    modifierKeysToMultiSelectCells: true,
                    onRegisterApi: function (gridApi) {
                        self.gridApi = gridApi;

                        //cell Navigation for selection of the cell based user click on cell
                        if (gridApi.cellNav)
                        {
                            gridApi.cellNav.on.navigate(gridApi.grid.appScope, function (newRowCol, oldRowCol) {

                                //cell Navigation logic for selecting column and row headers based on cell focused
                                var top = gridApi.grid.element[0];

                                var newColId = newRowCol.col.name;
                                var newRowId = newRowCol.row.entity.descriptor.id;

                                var ncolFilter = '[__colid="' + newColId + '"]';
                                var nrowFilter = '[context="' + newRowId + '"]';
                                var newCol = $(top).find("div").filter(ncolFilter).get(0);
                                var newRow = $(top).find("aw-matrix-row-header").filter(nrowFilter).get(0);

                                var newColHead = $(newCol).parent();
                                var newRowHead = $(newRow).parent().parent();

                                if ($scope.isColHeadSelected)
                                {
                                    resetSelected(top, false);
                                    $scope.isColHeadSelected = false;
                                }

                                //if there is no previous selection
                                if (!oldRowCol)
                                {
                                    noOldRc(newColHead, newRowHead, newColId, newRowId);
                                }

                                //if current selection is not multiselect
                                if (!$scope.select)
                                {
                                    /**if last selection was multiselect and new selection is single select then reset all
                                 selection except if row header is selected **/
                                    if ($scope.needReset && !$scope.isRowHeadSelected)
                                    {
                                        resetSelected(top, false);
                                    }
                                    //if Row header is selected then do not execute cell nav(skipping the execution as row header selection fires cell Nav event as well)
                                    if ((newColId === "") && ($scope.isRowHeadSelected))
                                    {
                                        return;
                                    }
                                    else
                                    {
                                        if ($scope.isRowHeadSelected)
                                        {
                                            resetSelected(top, true);
                                            $scope.isRowHeadSelected = false;
                                        }
                                    }

                                    $scope.needReset = false;
                                    //if old selection exists
                                    if (oldRowCol)
                                    {
                                        var oldColId = oldRowCol.col.name;
                                        var oldRowId = oldRowCol.row.entity.descriptor.id;

                                        var ocolFilter = '[__colid="' + oldColId + '"]';
                                        var orowFilter = '[context="' + oldRowId + '"]';

                                        var oldCol = $(top).find("div").filter(ocolFilter).get(0);
                                        var oldRow = $(top).find("aw-matrix-row-header").filter(orowFilter).get(0);

                                        var oldColHead = $(oldCol).parent();
                                        var oldRowHead = $(oldRow).parent().parent();
                                        //if new selection is different cell
                                        if (newRowCol !== oldRowCol)
                                        {

                                            if (newRowCol.row === oldRowCol.row && newRowCol.col !== oldRowCol.col)
                                            {
                                                /**if the new cell is selected under new column header but row is same
                                                 * then select new column header and unselect old column header
                                                 */
                                                selectNewColAndOldRow(newColHead, oldColHead, oldRowHead, newColId, oldRowId);
                                            }
                                            else if (newRowCol.row !== oldRowCol.row && newRowCol.col === oldRowCol.col)
                                            {
                                                /**if the new cell is selected under new row header but column is same
                                                 * then select new row header and unselect old row header
                                                 */
                                                selectNewRowAndOldCol(newRowHead, oldRowHead, oldColHead, oldColId, newRowId);
                                            }
                                            else
                                            {
                                                /**if the new cell is selected under new row header and new column
                                                 * then select new row and column header and unselect old row and
                                                 * column header
                                                 */
                                                selectNewRowAndNewCol(newColHead, newRowHead, oldColHead, oldRowHead, newColId, newRowId);
                                            }

                                        }
                                    }
                                }
                                $scope.select = false;
                            });
                        }
                    }
                }; // end gridOptions

                $scope.gridMatrixOptions = gridOptions;

                // reference to the gridOptions object (bound to ui grid via scope)
                self.gridOpts = gridOptions;

                $scope.hideTheWidget = false; // normally show the grid

                /**
                 * @memberof NgControllers.awMatrixController
                 *
                 * @param {Object}
                 *            containerVM - the containerVM
                 */
                self.setContainerVM = function (containerVM) {
                    // keep a reference to the containerVM
                    self.containerVM = containerVM;
                    containerVM.gridOptions = self.gridOpts;
                    $scope.$evalAsync(function () {
                        // ensure we update to the latest VM data
                        $scope.updateRowInfoDefs(containerVM);
                        $scope.updateColumnInfoDefs(containerVM);
                    }); // evalAsync

                };


                /**
                 * Trigger an update of the rowDescriptors from the VM list.
                 * In order to allow for empty XRT Object sets, if there is no object data (dataPage),
                 * then we won't display the rows.
                 *
                 * @memberof NgControllers.awMatrixController
                 *
                 * @param {Object}
                 *            containerVM - the containerVM
                 */
                $scope.updateRowInfoDefs = function (containerVM) {
                    var rowDescriptors = containerVM.rowDescriptors;

                    if (rowDescriptors && rowDescriptors.length > 0) {
                        // empty existing
                        rowMasterMatrix.length = 0;

                        // render grid if row object is available
                        $scope.hideTheWidget = false; // render the grid
                        for (var idx = 0; idx < rowDescriptors.length; idx++) {
                            rowMasterMatrix.push(rowMasterFactory(rowDescriptors[idx], true));
                        }
                    }
                };

                /**
                 * Trigger an update of the column info from the VM list.  This represents the columns
                 * of display data.
                 *
                 * @member of NgControllers.awMatrixController
                 *
                 * @param {object} containerVM An object container for column and row data
                 */
                $scope.updateColumnInfoDefs = function (containerVM) {
                    var modCols = containerVM.colDescriptors;

                    if (modCols && modCols.length > 0) {

                        var columns = generateMatrixColumns(containerVM, modCols);
                        // update the instances (Columns) for the matrix case.
                        if (containerVM.gridOptions) {
                            containerVM.gridOptions.columnDefs = columns;
                        }
                    }
                };
            }
        ]);


        /**
         * define a directive that is used to obtain content for the row header (column 0)
         *
         */
        app.directive('awMatrixRowHeader', function () {
            return {
                link: function (scope, elt, attrs) {
                    // column definition and data context for the row
                    var rowData = scope.row.entity;
                    var content = rowData.getRowHeader();
                    if (!content) {
                        content = '<p>no callback</p>';
                    }
                    elt.html(content);
                    var parentDiv = elt.parent().parent();

                    parentDiv.bind('mouseover', function () {
                        parentDiv.addClass("ui-grid-row-header-cell-over");
                    });

                    parentDiv.bind('mouseleave', function () {
                        parentDiv.removeClass("ui-grid-row-header-cell-over");
                    });
                }
            };
        });


        /**
         * define a directive that is used for click event on column header
         *
         */
        app.directive('awMatrixClickCol', function () {
            return {
                link: function (scope, element, attrs)
                {
                    element.bind("click", function (e) {
                        var colData = scope.col.colDef;
                        var colId = $(element).attr("__colid");
                        colData.onColClick(colId, e);
                    });
                }
            };
        });


        /**
         * define a directive that is used for click event on row header
         *
         */
        app.directive('awMatrixClickRowHeader', function () {
            return {
                link: function (scope, element, attrs)
                {
                    element.bind("click", function (e) {
                        var rowData = scope.row.entity;
                        var rowId = $(element).attr("__rowid");
                        rowData.onRowHeaderClick(rowId, e);
                    });
                }
            };
        });


        /**
         * define a directive that is used for click event on cell
         *
         */
        app.directive('awMatrixClickCell', function () {
            return {
                link: function (scope, element, attrs)
                {
                    element.bind("click", function (e) {
                        if (e.ctrlKey) {
                            var colData = scope.col.colDef;
                            var colId = $(element).attr("__colid");
                            var rowId = $(element).attr("__rowid");
                            colData.onCtrlClick(rowId, colId, e);
                        }
                    });
                }
            };
        });


        /**
         * utility function to get the scope reference (if set) on the controller under the parent element.
         */
        var getScopeForParent = function (parentElement) {
            var scope = null;

            // assumes that the first child of parent is the controller element
            if (parentElement && parentElement.firstChild) {
                scope = ngModule.element(parentElement.firstChild).scope();
            }
            return scope;
        };

        /**
         * insertMatrixGrid ('bootstrap') the angular system and create an angular controller on a new 'child' of the given
         * 'parent' element.
         *
         * @param {Element}
         *            parentElement - The DOM element the controller and 'inner' HTML content will be added to.
         *            <P>
         *            Note: All existing 'child' elements of this 'parent' will be removed.
         *
         *
         * @param {Object}
         *            containerVM - Matrix container View Model
         *            <P>
         *            Note: This object will have the 'rootScopeElement' property set on this object with the new
         *            AngularJS Element created to hold the compiled given 'innerHtml' and attached as a child to the
         *            given 'parentElement'.
         */
        exports.insertMatrixGrid = function (parentElement, containerVM) {
            /**
             * Create an 'outer' <DIV> (to hold the given 'inner' HTML) and create the angular controller on it.
             * <P>
             * Remove any existing 'children' of the given 'parent'
             * <P>
             * Add this new element as a 'child' of the given 'parent'
             */
            var ctrlElement = ngModule
                .element('<div class="aw-jswidgets-grid aw-jswidgets-matrixContainer" ng-controller="awMatrixController"/>');

            // add the required ui-grid directives for Matrix widget behavior.
            var inner = '<div  id="grid" ng-hide="hideTheWidget" ui-grid="gridMatrixOptions" ui-grid-resize-columns ui-grid-pinning ui-grid-cellNav ui-grid-auto-resize/>';
            ctrlElement.html(inner);

            $(parentElement).empty();
            $(parentElement).append(ctrlElement);

            var ctrlFn = awInclude(parentElement, ctrlElement);
            if (ctrlFn) {
                ctrlFn.setContainerVM(containerVM);
            }
        };


        /**
         * Update the row info definitions - these are the Matrix rows
         *
         * @param {Element}
         *            parentElement - The element above the element the controller was created on.
         * @param {Object}
         *            containerVM - Matrix container View Model
         */
        exports.forceupdateRowInfoDefs = function (parentElement, containerVM) {
            var ngScope = getScopeForParent(parentElement);
            if (ngScope && !ngScope.$$destroyed) {
                ngScope.updateRowInfoDefs(containerVM);
            }
        };


        /**
         * Update the column info definitions - these are the Matrix columns
         *
         * @param {Element}
         *            parentElement - The element above the element the controller was created on.
         * @param {Object}
         *            containerVM - Matrix container View Model
         */
        exports.forceupdateColumnInfoDefs = function (parentElement, containerVM) {
            var ngScope = getScopeForParent(parentElement);
            if (ngScope && !ngScope.$$destroyed) {
                ngScope.updateColumnInfoDefs(containerVM);
            }
        };

        return exports;

        // End RequireJS Define
    });